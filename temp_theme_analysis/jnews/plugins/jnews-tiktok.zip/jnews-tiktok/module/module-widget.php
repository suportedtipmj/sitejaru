<?php

class JNews_Widget_Tiktok_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}
