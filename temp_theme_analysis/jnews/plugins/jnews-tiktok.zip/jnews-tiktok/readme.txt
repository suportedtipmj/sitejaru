Change Log :

== 11.0.1 ==
- [IMPROVEMENT] Update Tiktok API

== 11.0.0 ==
- [IMPROVEMENT] Compatible with JNews v11.0.0

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- First Release
