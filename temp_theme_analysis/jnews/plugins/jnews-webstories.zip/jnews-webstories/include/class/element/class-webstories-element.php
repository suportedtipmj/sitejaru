<?php
/**
 * @author : Jegtheme
 */

namespace JNews\WEBSTORIES\Element;

use JNews\WEBSTORIES\Module\Webstories_Module;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Webstories_Element
 */
class Webstories_Element {

	/**
	 * Instance of Webstories_Module
	 *
	 * @var Donation_Module
	 */
	private static $instance;

	/**
	 * Webstories_Module constructor.
	 */
	public function __construct() {
		Webstories_Module::instance();
	}

	/**
	 * Return class instance
	 *
	 * @return Database
	 */
	public static function instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}
}
