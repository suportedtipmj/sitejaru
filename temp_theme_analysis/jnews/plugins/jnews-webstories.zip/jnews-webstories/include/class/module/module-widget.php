<?php

class JNews_Element_Webstories_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}
