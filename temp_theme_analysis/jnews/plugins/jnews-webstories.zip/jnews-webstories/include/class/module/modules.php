<?php
/**
 * @author Jegtheme
 */

return array(
	array(
		'name'   => 'JNews_Element_Webstories',
		'alias'  => 'webstories_element',
		'type'   => 'webstories',
		'image'  => '',
		'widget' => true,
		'view'   => 'include/class/element/class-element-webstories-view.php',
		'option' => 'include/class/element/class-element-webstories-option.php',
	),
);
