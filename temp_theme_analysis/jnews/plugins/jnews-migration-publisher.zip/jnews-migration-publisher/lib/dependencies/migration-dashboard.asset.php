<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks', 'wp-i18n', 'wp-polyfill'), 'version' => '881824a69c44fefea263');
