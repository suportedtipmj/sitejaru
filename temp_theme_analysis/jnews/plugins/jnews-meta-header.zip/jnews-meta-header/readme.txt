Change Log :

== 11.0.0 ==
- [IMPROVEMENT] Compatible with JNews v11.0.0

== 10.0.3 ==
- [BUG] Fix gettext issue

== 10.0.2 ==
- [BUG] Fix conflict with FluentForms plugin

== 10.0.1 ==
- [BUG] Fix SERP publish time issue

== 10.0.0 ==
- [IMPROVEMENT] Compatible with JNews v10.0.0

== 9.0.1 ==
- [BUG] Fix PHP 5.6 issue

== 9.0.0 ==
- [IMPROVEMENT] Compatible with JNews v9.0.0

== 8.0.0 ==
- [IMPROVEMENT] Compatible with JNews v8.0.0

== 7.0.0 ==
- [IMPROVEMENT] Compatible with JNews v7.0.0

== 6.0.0 ==
- [IMPROVEMENT] Compatible with JNews v6.0.0

== 5.0.1 ==
- [BUG] Fix post content issue

== 5.0.0 ==
- [IMPROVEMENT] Compatible with JNews v5.0.0

== 4.0.0 ==
- [IMPROVEMENT] Compatible with JNews v4.0.0

== 3.0.1 ==
- [BUG] Fix social meta header metabox doesn't load on the backend

== 3.0.0 ==
- [IMPROVEMENT] Compatible with JNews v3.0.0

== 2.0.1 ==
- [BUG] Fix missing meta og:image

== 2.0.0 ==
- [IMPROVEMENT] Compatible with JNews v2.0.0

== 1.0.0 ==
- First Release
