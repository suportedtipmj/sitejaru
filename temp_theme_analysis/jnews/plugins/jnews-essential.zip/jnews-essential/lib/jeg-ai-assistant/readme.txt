=== 1.2.1 ===
- [BUG] Fix compatibility issue with WordPress version 6.2
- [BUG] Resolved issue that caused errors on PHP versions below 7.3 due to an extra comma.

=== 1.2.0 ===
- [IMPROVEMENT] Support new GPT 3.5 models

=== 1.1.0 ===
- [IMPROVEMENT] Support classic editor
- [IMPROVEMENT] Better API requests
- [BUG] Fix issue with post content generator consistently producing errors.

=== 1.0.0 ===
- Initial Release
