<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks', 'wp-i18n', 'wp-polyfill'), 'version' => 'b0242d0c8fef9a22596a');
