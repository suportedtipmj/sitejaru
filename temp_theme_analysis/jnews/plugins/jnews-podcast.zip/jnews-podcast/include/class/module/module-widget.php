<?php
/**
 * @author Jegtheme
 */

/**
 * Class JNews_Podcast_Blockpodcast1_Widget
 */
class JNews_Podcast_Blockpodcast1_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast2_Widget
 */
class JNews_Podcast_Blockpodcast2_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast3_Widget
 */
class JNews_Podcast_Blockpodcast3_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast4_Widget
 */
class JNews_Podcast_Blockpodcast4_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Blockepisode1_Widget
 */
class JNews_Podcast_Blockepisode1_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Blockepisode2_Widget
 */
class JNews_Podcast_Blockepisode2_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Category_Widget
 */
class JNews_Podcast_Category_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Episodelist_Widget
 */
class JNews_Podcast_Episodelist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

/**
 * Class JNews_Podcast_Episodedetail_Widget
 */
class JNews_Podcast_Episodedetail_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}
