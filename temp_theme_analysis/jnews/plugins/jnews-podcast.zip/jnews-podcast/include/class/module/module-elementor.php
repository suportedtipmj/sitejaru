<?php
/**
 * @author Jegtheme
 */

/**
 * Class JNews_Podcast_Blockpodcast1_Elementor
 */
class JNews_Podcast_Blockpodcast1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast2_Elementor
 */
class JNews_Podcast_Blockpodcast2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast3_Elementor
 */
class JNews_Podcast_Blockpodcast3_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Blockpodcast4_Elementor
 */
class JNews_Podcast_Blockpodcast4_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Blockepisode1_Elementor
 */
class JNews_Podcast_Blockepisode1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Blockepisode2_Elementor
 */
class JNews_Podcast_Blockepisode2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Category_Elementor
 */
class JNews_Podcast_Category_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Episodelist_Elementor
 */
class JNews_Podcast_Episodelist_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}

/**
 * Class JNews_Podcast_Episodedetail_Elementor
 */
class JNews_Podcast_Episodedetail_Elementor extends \JNews\Elementor\ModuleElementorAbstract {
}
