<?php

namespace JNews\Paywall\Gateways\Stripe\Lib\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface Exception_Interface extends JNews\Paywall\Gateways\Stripe\Lib\Exception\Exception_Interface
{

}
