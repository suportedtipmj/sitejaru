/******/ (function() { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/axios/index.js":
/*!*************************************!*\
  !*** ./node_modules/axios/index.js ***!
  \*************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./lib/axios */ "./node_modules/axios/lib/axios.js");

/***/ }),

/***/ "./node_modules/axios/lib/adapters/xhr.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/adapters/xhr.js ***!
  \************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var settle = __webpack_require__(/*! ./../core/settle */ "./node_modules/axios/lib/core/settle.js");
var cookies = __webpack_require__(/*! ./../helpers/cookies */ "./node_modules/axios/lib/helpers/cookies.js");
var buildURL = __webpack_require__(/*! ./../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var buildFullPath = __webpack_require__(/*! ../core/buildFullPath */ "./node_modules/axios/lib/core/buildFullPath.js");
var parseHeaders = __webpack_require__(/*! ./../helpers/parseHeaders */ "./node_modules/axios/lib/helpers/parseHeaders.js");
var isURLSameOrigin = __webpack_require__(/*! ./../helpers/isURLSameOrigin */ "./node_modules/axios/lib/helpers/isURLSameOrigin.js");
var createError = __webpack_require__(/*! ../core/createError */ "./node_modules/axios/lib/core/createError.js");

module.exports = function xhrAdapter(config) {
  return new Promise(function dispatchXhrRequest(resolve, reject) {
    var requestData = config.data;
    var requestHeaders = config.headers;
    var responseType = config.responseType;

    if (utils.isFormData(requestData)) {
      delete requestHeaders['Content-Type']; // Let the browser set it
    }

    var request = new XMLHttpRequest();

    // HTTP basic authentication
    if (config.auth) {
      var username = config.auth.username || '';
      var password = config.auth.password ? unescape(encodeURIComponent(config.auth.password)) : '';
      requestHeaders.Authorization = 'Basic ' + btoa(username + ':' + password);
    }

    var fullPath = buildFullPath(config.baseURL, config.url);
    request.open(config.method.toUpperCase(), buildURL(fullPath, config.params, config.paramsSerializer), true);

    // Set the request timeout in MS
    request.timeout = config.timeout;

    function onloadend() {
      if (!request) {
        return;
      }
      // Prepare the response
      var responseHeaders = 'getAllResponseHeaders' in request ? parseHeaders(request.getAllResponseHeaders()) : null;
      var responseData = !responseType || responseType === 'text' ||  responseType === 'json' ?
        request.responseText : request.response;
      var response = {
        data: responseData,
        status: request.status,
        statusText: request.statusText,
        headers: responseHeaders,
        config: config,
        request: request
      };

      settle(resolve, reject, response);

      // Clean up request
      request = null;
    }

    if ('onloadend' in request) {
      // Use onloadend if available
      request.onloadend = onloadend;
    } else {
      // Listen for ready state to emulate onloadend
      request.onreadystatechange = function handleLoad() {
        if (!request || request.readyState !== 4) {
          return;
        }

        // The request errored out and we didn't get a response, this will be
        // handled by onerror instead
        // With one exception: request that using file: protocol, most browsers
        // will return status as 0 even though it's a successful request
        if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf('file:') === 0)) {
          return;
        }
        // readystate handler is calling before onerror or ontimeout handlers,
        // so we should call onloadend on the next 'tick'
        setTimeout(onloadend);
      };
    }

    // Handle browser request cancellation (as opposed to a manual cancellation)
    request.onabort = function handleAbort() {
      if (!request) {
        return;
      }

      reject(createError('Request aborted', config, 'ECONNABORTED', request));

      // Clean up request
      request = null;
    };

    // Handle low level network errors
    request.onerror = function handleError() {
      // Real errors are hidden from us by the browser
      // onerror should only fire if it's a network error
      reject(createError('Network Error', config, null, request));

      // Clean up request
      request = null;
    };

    // Handle timeout
    request.ontimeout = function handleTimeout() {
      var timeoutErrorMessage = 'timeout of ' + config.timeout + 'ms exceeded';
      if (config.timeoutErrorMessage) {
        timeoutErrorMessage = config.timeoutErrorMessage;
      }
      reject(createError(
        timeoutErrorMessage,
        config,
        config.transitional && config.transitional.clarifyTimeoutError ? 'ETIMEDOUT' : 'ECONNABORTED',
        request));

      // Clean up request
      request = null;
    };

    // Add xsrf header
    // This is only done if running in a standard browser environment.
    // Specifically not if we're in a web worker, or react-native.
    if (utils.isStandardBrowserEnv()) {
      // Add xsrf header
      var xsrfValue = (config.withCredentials || isURLSameOrigin(fullPath)) && config.xsrfCookieName ?
        cookies.read(config.xsrfCookieName) :
        undefined;

      if (xsrfValue) {
        requestHeaders[config.xsrfHeaderName] = xsrfValue;
      }
    }

    // Add headers to the request
    if ('setRequestHeader' in request) {
      utils.forEach(requestHeaders, function setRequestHeader(val, key) {
        if (typeof requestData === 'undefined' && key.toLowerCase() === 'content-type') {
          // Remove Content-Type if data is undefined
          delete requestHeaders[key];
        } else {
          // Otherwise add header to the request
          request.setRequestHeader(key, val);
        }
      });
    }

    // Add withCredentials to request if needed
    if (!utils.isUndefined(config.withCredentials)) {
      request.withCredentials = !!config.withCredentials;
    }

    // Add responseType to request if needed
    if (responseType && responseType !== 'json') {
      request.responseType = config.responseType;
    }

    // Handle progress if needed
    if (typeof config.onDownloadProgress === 'function') {
      request.addEventListener('progress', config.onDownloadProgress);
    }

    // Not all browsers support upload events
    if (typeof config.onUploadProgress === 'function' && request.upload) {
      request.upload.addEventListener('progress', config.onUploadProgress);
    }

    if (config.cancelToken) {
      // Handle cancellation
      config.cancelToken.promise.then(function onCanceled(cancel) {
        if (!request) {
          return;
        }

        request.abort();
        reject(cancel);
        // Clean up request
        request = null;
      });
    }

    if (!requestData) {
      requestData = null;
    }

    // Send the request
    request.send(requestData);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/axios.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/axios.js ***!
  \*****************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");
var Axios = __webpack_require__(/*! ./core/Axios */ "./node_modules/axios/lib/core/Axios.js");
var mergeConfig = __webpack_require__(/*! ./core/mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var defaults = __webpack_require__(/*! ./defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 * @return {Axios} A new instance of Axios
 */
function createInstance(defaultConfig) {
  var context = new Axios(defaultConfig);
  var instance = bind(Axios.prototype.request, context);

  // Copy axios.prototype to instance
  utils.extend(instance, Axios.prototype, context);

  // Copy context to instance
  utils.extend(instance, context);

  return instance;
}

// Create the default instance to be exported
var axios = createInstance(defaults);

// Expose Axios class to allow class inheritance
axios.Axios = Axios;

// Factory for creating new instances
axios.create = function create(instanceConfig) {
  return createInstance(mergeConfig(axios.defaults, instanceConfig));
};

// Expose Cancel & CancelToken
axios.Cancel = __webpack_require__(/*! ./cancel/Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");
axios.CancelToken = __webpack_require__(/*! ./cancel/CancelToken */ "./node_modules/axios/lib/cancel/CancelToken.js");
axios.isCancel = __webpack_require__(/*! ./cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");

// Expose all/spread
axios.all = function all(promises) {
  return Promise.all(promises);
};
axios.spread = __webpack_require__(/*! ./helpers/spread */ "./node_modules/axios/lib/helpers/spread.js");

// Expose isAxiosError
axios.isAxiosError = __webpack_require__(/*! ./helpers/isAxiosError */ "./node_modules/axios/lib/helpers/isAxiosError.js");

module.exports = axios;

// Allow use of default import syntax in TypeScript
module.exports["default"] = axios;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/Cancel.js":
/*!*************************************************!*\
  !*** ./node_modules/axios/lib/cancel/Cancel.js ***!
  \*************************************************/
/***/ (function(module) {

"use strict";


/**
 * A `Cancel` is an object that is thrown when an operation is canceled.
 *
 * @class
 * @param {string=} message The message.
 */
function Cancel(message) {
  this.message = message;
}

Cancel.prototype.toString = function toString() {
  return 'Cancel' + (this.message ? ': ' + this.message : '');
};

Cancel.prototype.__CANCEL__ = true;

module.exports = Cancel;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/CancelToken.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/cancel/CancelToken.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var Cancel = __webpack_require__(/*! ./Cancel */ "./node_modules/axios/lib/cancel/Cancel.js");

/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @class
 * @param {Function} executor The executor function.
 */
function CancelToken(executor) {
  if (typeof executor !== 'function') {
    throw new TypeError('executor must be a function.');
  }

  var resolvePromise;
  this.promise = new Promise(function promiseExecutor(resolve) {
    resolvePromise = resolve;
  });

  var token = this;
  executor(function cancel(message) {
    if (token.reason) {
      // Cancellation has already been requested
      return;
    }

    token.reason = new Cancel(message);
    resolvePromise(token.reason);
  });
}

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
CancelToken.prototype.throwIfRequested = function throwIfRequested() {
  if (this.reason) {
    throw this.reason;
  }
};

/**
 * Returns an object that contains a new `CancelToken` and a function that, when called,
 * cancels the `CancelToken`.
 */
CancelToken.source = function source() {
  var cancel;
  var token = new CancelToken(function executor(c) {
    cancel = c;
  });
  return {
    token: token,
    cancel: cancel
  };
};

module.exports = CancelToken;


/***/ }),

/***/ "./node_modules/axios/lib/cancel/isCancel.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/cancel/isCancel.js ***!
  \***************************************************/
/***/ (function(module) {

"use strict";


module.exports = function isCancel(value) {
  return !!(value && value.__CANCEL__);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/Axios.js":
/*!**********************************************!*\
  !*** ./node_modules/axios/lib/core/Axios.js ***!
  \**********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var buildURL = __webpack_require__(/*! ../helpers/buildURL */ "./node_modules/axios/lib/helpers/buildURL.js");
var InterceptorManager = __webpack_require__(/*! ./InterceptorManager */ "./node_modules/axios/lib/core/InterceptorManager.js");
var dispatchRequest = __webpack_require__(/*! ./dispatchRequest */ "./node_modules/axios/lib/core/dispatchRequest.js");
var mergeConfig = __webpack_require__(/*! ./mergeConfig */ "./node_modules/axios/lib/core/mergeConfig.js");
var validator = __webpack_require__(/*! ../helpers/validator */ "./node_modules/axios/lib/helpers/validator.js");

var validators = validator.validators;
/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 */
function Axios(instanceConfig) {
  this.defaults = instanceConfig;
  this.interceptors = {
    request: new InterceptorManager(),
    response: new InterceptorManager()
  };
}

/**
 * Dispatch a request
 *
 * @param {Object} config The config specific for this request (merged with this.defaults)
 */
Axios.prototype.request = function request(config) {
  /*eslint no-param-reassign:0*/
  // Allow for axios('example/url'[, config]) a la fetch API
  if (typeof config === 'string') {
    config = arguments[1] || {};
    config.url = arguments[0];
  } else {
    config = config || {};
  }

  config = mergeConfig(this.defaults, config);

  // Set config.method
  if (config.method) {
    config.method = config.method.toLowerCase();
  } else if (this.defaults.method) {
    config.method = this.defaults.method.toLowerCase();
  } else {
    config.method = 'get';
  }

  var transitional = config.transitional;

  if (transitional !== undefined) {
    validator.assertOptions(transitional, {
      silentJSONParsing: validators.transitional(validators.boolean, '1.0.0'),
      forcedJSONParsing: validators.transitional(validators.boolean, '1.0.0'),
      clarifyTimeoutError: validators.transitional(validators.boolean, '1.0.0')
    }, false);
  }

  // filter out skipped interceptors
  var requestInterceptorChain = [];
  var synchronousRequestInterceptors = true;
  this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
    if (typeof interceptor.runWhen === 'function' && interceptor.runWhen(config) === false) {
      return;
    }

    synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;

    requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
  });

  var responseInterceptorChain = [];
  this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
    responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
  });

  var promise;

  if (!synchronousRequestInterceptors) {
    var chain = [dispatchRequest, undefined];

    Array.prototype.unshift.apply(chain, requestInterceptorChain);
    chain = chain.concat(responseInterceptorChain);

    promise = Promise.resolve(config);
    while (chain.length) {
      promise = promise.then(chain.shift(), chain.shift());
    }

    return promise;
  }


  var newConfig = config;
  while (requestInterceptorChain.length) {
    var onFulfilled = requestInterceptorChain.shift();
    var onRejected = requestInterceptorChain.shift();
    try {
      newConfig = onFulfilled(newConfig);
    } catch (error) {
      onRejected(error);
      break;
    }
  }

  try {
    promise = dispatchRequest(newConfig);
  } catch (error) {
    return Promise.reject(error);
  }

  while (responseInterceptorChain.length) {
    promise = promise.then(responseInterceptorChain.shift(), responseInterceptorChain.shift());
  }

  return promise;
};

Axios.prototype.getUri = function getUri(config) {
  config = mergeConfig(this.defaults, config);
  return buildURL(config.url, config.params, config.paramsSerializer).replace(/^\?/, '');
};

// Provide aliases for supported request methods
utils.forEach(['delete', 'get', 'head', 'options'], function forEachMethodNoData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, config) {
    return this.request(mergeConfig(config || {}, {
      method: method,
      url: url,
      data: (config || {}).data
    }));
  };
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  /*eslint func-names:0*/
  Axios.prototype[method] = function(url, data, config) {
    return this.request(mergeConfig(config || {}, {
      method: method,
      url: url,
      data: data
    }));
  };
});

module.exports = Axios;


/***/ }),

/***/ "./node_modules/axios/lib/core/InterceptorManager.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/core/InterceptorManager.js ***!
  \***********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function InterceptorManager() {
  this.handlers = [];
}

/**
 * Add a new interceptor to the stack
 *
 * @param {Function} fulfilled The function to handle `then` for a `Promise`
 * @param {Function} rejected The function to handle `reject` for a `Promise`
 *
 * @return {Number} An ID used to remove interceptor later
 */
InterceptorManager.prototype.use = function use(fulfilled, rejected, options) {
  this.handlers.push({
    fulfilled: fulfilled,
    rejected: rejected,
    synchronous: options ? options.synchronous : false,
    runWhen: options ? options.runWhen : null
  });
  return this.handlers.length - 1;
};

/**
 * Remove an interceptor from the stack
 *
 * @param {Number} id The ID that was returned by `use`
 */
InterceptorManager.prototype.eject = function eject(id) {
  if (this.handlers[id]) {
    this.handlers[id] = null;
  }
};

/**
 * Iterate over all the registered interceptors
 *
 * This method is particularly useful for skipping over any
 * interceptors that may have become `null` calling `eject`.
 *
 * @param {Function} fn The function to call for each interceptor
 */
InterceptorManager.prototype.forEach = function forEach(fn) {
  utils.forEach(this.handlers, function forEachHandler(h) {
    if (h !== null) {
      fn(h);
    }
  });
};

module.exports = InterceptorManager;


/***/ }),

/***/ "./node_modules/axios/lib/core/buildFullPath.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/buildFullPath.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var isAbsoluteURL = __webpack_require__(/*! ../helpers/isAbsoluteURL */ "./node_modules/axios/lib/helpers/isAbsoluteURL.js");
var combineURLs = __webpack_require__(/*! ../helpers/combineURLs */ "./node_modules/axios/lib/helpers/combineURLs.js");

/**
 * Creates a new URL by combining the baseURL with the requestedURL,
 * only when the requestedURL is not already an absolute URL.
 * If the requestURL is absolute, this function returns the requestedURL untouched.
 *
 * @param {string} baseURL The base URL
 * @param {string} requestedURL Absolute or relative URL to combine
 * @returns {string} The combined full path
 */
module.exports = function buildFullPath(baseURL, requestedURL) {
  if (baseURL && !isAbsoluteURL(requestedURL)) {
    return combineURLs(baseURL, requestedURL);
  }
  return requestedURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/createError.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/createError.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var enhanceError = __webpack_require__(/*! ./enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The created error.
 */
module.exports = function createError(message, config, code, request, response) {
  var error = new Error(message);
  return enhanceError(error, config, code, request, response);
};


/***/ }),

/***/ "./node_modules/axios/lib/core/dispatchRequest.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/core/dispatchRequest.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var transformData = __webpack_require__(/*! ./transformData */ "./node_modules/axios/lib/core/transformData.js");
var isCancel = __webpack_require__(/*! ../cancel/isCancel */ "./node_modules/axios/lib/cancel/isCancel.js");
var defaults = __webpack_require__(/*! ../defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Throws a `Cancel` if cancellation has been requested.
 */
function throwIfCancellationRequested(config) {
  if (config.cancelToken) {
    config.cancelToken.throwIfRequested();
  }
}

/**
 * Dispatch a request to the server using the configured adapter.
 *
 * @param {object} config The config that is to be used for the request
 * @returns {Promise} The Promise to be fulfilled
 */
module.exports = function dispatchRequest(config) {
  throwIfCancellationRequested(config);

  // Ensure headers exist
  config.headers = config.headers || {};

  // Transform request data
  config.data = transformData.call(
    config,
    config.data,
    config.headers,
    config.transformRequest
  );

  // Flatten headers
  config.headers = utils.merge(
    config.headers.common || {},
    config.headers[config.method] || {},
    config.headers
  );

  utils.forEach(
    ['delete', 'get', 'head', 'post', 'put', 'patch', 'common'],
    function cleanHeaderConfig(method) {
      delete config.headers[method];
    }
  );

  var adapter = config.adapter || defaults.adapter;

  return adapter(config).then(function onAdapterResolution(response) {
    throwIfCancellationRequested(config);

    // Transform response data
    response.data = transformData.call(
      config,
      response.data,
      response.headers,
      config.transformResponse
    );

    return response;
  }, function onAdapterRejection(reason) {
    if (!isCancel(reason)) {
      throwIfCancellationRequested(config);

      // Transform response data
      if (reason && reason.response) {
        reason.response.data = transformData.call(
          config,
          reason.response.data,
          reason.response.headers,
          config.transformResponse
        );
      }
    }

    return Promise.reject(reason);
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/core/enhanceError.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/core/enhanceError.js ***!
  \*****************************************************/
/***/ (function(module) {

"use strict";


/**
 * Update an Error with the specified config, error code, and response.
 *
 * @param {Error} error The error to update.
 * @param {Object} config The config.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 * @returns {Error} The error.
 */
module.exports = function enhanceError(error, config, code, request, response) {
  error.config = config;
  if (code) {
    error.code = code;
  }

  error.request = request;
  error.response = response;
  error.isAxiosError = true;

  error.toJSON = function toJSON() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code
    };
  };
  return error;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/mergeConfig.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/core/mergeConfig.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

/**
 * Config-specific merge-function which creates a new config-object
 * by merging two configuration objects together.
 *
 * @param {Object} config1
 * @param {Object} config2
 * @returns {Object} New object resulting from merging config2 to config1
 */
module.exports = function mergeConfig(config1, config2) {
  // eslint-disable-next-line no-param-reassign
  config2 = config2 || {};
  var config = {};

  var valueFromConfig2Keys = ['url', 'method', 'data'];
  var mergeDeepPropertiesKeys = ['headers', 'auth', 'proxy', 'params'];
  var defaultToConfig2Keys = [
    'baseURL', 'transformRequest', 'transformResponse', 'paramsSerializer',
    'timeout', 'timeoutMessage', 'withCredentials', 'adapter', 'responseType', 'xsrfCookieName',
    'xsrfHeaderName', 'onUploadProgress', 'onDownloadProgress', 'decompress',
    'maxContentLength', 'maxBodyLength', 'maxRedirects', 'transport', 'httpAgent',
    'httpsAgent', 'cancelToken', 'socketPath', 'responseEncoding'
  ];
  var directMergeKeys = ['validateStatus'];

  function getMergedValue(target, source) {
    if (utils.isPlainObject(target) && utils.isPlainObject(source)) {
      return utils.merge(target, source);
    } else if (utils.isPlainObject(source)) {
      return utils.merge({}, source);
    } else if (utils.isArray(source)) {
      return source.slice();
    }
    return source;
  }

  function mergeDeepProperties(prop) {
    if (!utils.isUndefined(config2[prop])) {
      config[prop] = getMergedValue(config1[prop], config2[prop]);
    } else if (!utils.isUndefined(config1[prop])) {
      config[prop] = getMergedValue(undefined, config1[prop]);
    }
  }

  utils.forEach(valueFromConfig2Keys, function valueFromConfig2(prop) {
    if (!utils.isUndefined(config2[prop])) {
      config[prop] = getMergedValue(undefined, config2[prop]);
    }
  });

  utils.forEach(mergeDeepPropertiesKeys, mergeDeepProperties);

  utils.forEach(defaultToConfig2Keys, function defaultToConfig2(prop) {
    if (!utils.isUndefined(config2[prop])) {
      config[prop] = getMergedValue(undefined, config2[prop]);
    } else if (!utils.isUndefined(config1[prop])) {
      config[prop] = getMergedValue(undefined, config1[prop]);
    }
  });

  utils.forEach(directMergeKeys, function merge(prop) {
    if (prop in config2) {
      config[prop] = getMergedValue(config1[prop], config2[prop]);
    } else if (prop in config1) {
      config[prop] = getMergedValue(undefined, config1[prop]);
    }
  });

  var axiosKeys = valueFromConfig2Keys
    .concat(mergeDeepPropertiesKeys)
    .concat(defaultToConfig2Keys)
    .concat(directMergeKeys);

  var otherKeys = Object
    .keys(config1)
    .concat(Object.keys(config2))
    .filter(function filterAxiosKeys(key) {
      return axiosKeys.indexOf(key) === -1;
    });

  utils.forEach(otherKeys, mergeDeepProperties);

  return config;
};


/***/ }),

/***/ "./node_modules/axios/lib/core/settle.js":
/*!***********************************************!*\
  !*** ./node_modules/axios/lib/core/settle.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var createError = __webpack_require__(/*! ./createError */ "./node_modules/axios/lib/core/createError.js");

/**
 * Resolve or reject a Promise based on response status.
 *
 * @param {Function} resolve A function that resolves the promise.
 * @param {Function} reject A function that rejects the promise.
 * @param {object} response The response.
 */
module.exports = function settle(resolve, reject, response) {
  var validateStatus = response.config.validateStatus;
  if (!response.status || !validateStatus || validateStatus(response.status)) {
    resolve(response);
  } else {
    reject(createError(
      'Request failed with status code ' + response.status,
      response.config,
      null,
      response.request,
      response
    ));
  }
};


/***/ }),

/***/ "./node_modules/axios/lib/core/transformData.js":
/*!******************************************************!*\
  !*** ./node_modules/axios/lib/core/transformData.js ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");
var defaults = __webpack_require__(/*! ./../defaults */ "./node_modules/axios/lib/defaults.js");

/**
 * Transform the data for a request or a response
 *
 * @param {Object|String} data The data to be transformed
 * @param {Array} headers The headers for the request or response
 * @param {Array|Function} fns A single function or Array of functions
 * @returns {*} The resulting transformed data
 */
module.exports = function transformData(data, headers, fns) {
  var context = this || defaults;
  /*eslint no-param-reassign:0*/
  utils.forEach(fns, function transform(fn) {
    data = fn.call(context, data, headers);
  });

  return data;
};


/***/ }),

/***/ "./node_modules/axios/lib/defaults.js":
/*!********************************************!*\
  !*** ./node_modules/axios/lib/defaults.js ***!
  \********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./utils */ "./node_modules/axios/lib/utils.js");
var normalizeHeaderName = __webpack_require__(/*! ./helpers/normalizeHeaderName */ "./node_modules/axios/lib/helpers/normalizeHeaderName.js");
var enhanceError = __webpack_require__(/*! ./core/enhanceError */ "./node_modules/axios/lib/core/enhanceError.js");

var DEFAULT_CONTENT_TYPE = {
  'Content-Type': 'application/x-www-form-urlencoded'
};

function setContentTypeIfUnset(headers, value) {
  if (!utils.isUndefined(headers) && utils.isUndefined(headers['Content-Type'])) {
    headers['Content-Type'] = value;
  }
}

function getDefaultAdapter() {
  var adapter;
  if (typeof XMLHttpRequest !== 'undefined') {
    // For browsers use XHR adapter
    adapter = __webpack_require__(/*! ./adapters/xhr */ "./node_modules/axios/lib/adapters/xhr.js");
  } else if (typeof process !== 'undefined' && Object.prototype.toString.call(process) === '[object process]') {
    // For node use HTTP adapter
    adapter = __webpack_require__(/*! ./adapters/http */ "./node_modules/axios/lib/adapters/xhr.js");
  }
  return adapter;
}

function stringifySafely(rawValue, parser, encoder) {
  if (utils.isString(rawValue)) {
    try {
      (parser || JSON.parse)(rawValue);
      return utils.trim(rawValue);
    } catch (e) {
      if (e.name !== 'SyntaxError') {
        throw e;
      }
    }
  }

  return (encoder || JSON.stringify)(rawValue);
}

var defaults = {

  transitional: {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false
  },

  adapter: getDefaultAdapter(),

  transformRequest: [function transformRequest(data, headers) {
    normalizeHeaderName(headers, 'Accept');
    normalizeHeaderName(headers, 'Content-Type');

    if (utils.isFormData(data) ||
      utils.isArrayBuffer(data) ||
      utils.isBuffer(data) ||
      utils.isStream(data) ||
      utils.isFile(data) ||
      utils.isBlob(data)
    ) {
      return data;
    }
    if (utils.isArrayBufferView(data)) {
      return data.buffer;
    }
    if (utils.isURLSearchParams(data)) {
      setContentTypeIfUnset(headers, 'application/x-www-form-urlencoded;charset=utf-8');
      return data.toString();
    }
    if (utils.isObject(data) || (headers && headers['Content-Type'] === 'application/json')) {
      setContentTypeIfUnset(headers, 'application/json');
      return stringifySafely(data);
    }
    return data;
  }],

  transformResponse: [function transformResponse(data) {
    var transitional = this.transitional;
    var silentJSONParsing = transitional && transitional.silentJSONParsing;
    var forcedJSONParsing = transitional && transitional.forcedJSONParsing;
    var strictJSONParsing = !silentJSONParsing && this.responseType === 'json';

    if (strictJSONParsing || (forcedJSONParsing && utils.isString(data) && data.length)) {
      try {
        return JSON.parse(data);
      } catch (e) {
        if (strictJSONParsing) {
          if (e.name === 'SyntaxError') {
            throw enhanceError(e, this, 'E_JSON_PARSE');
          }
          throw e;
        }
      }
    }

    return data;
  }],

  /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */
  timeout: 0,

  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',

  maxContentLength: -1,
  maxBodyLength: -1,

  validateStatus: function validateStatus(status) {
    return status >= 200 && status < 300;
  }
};

defaults.headers = {
  common: {
    'Accept': 'application/json, text/plain, */*'
  }
};

utils.forEach(['delete', 'get', 'head'], function forEachMethodNoData(method) {
  defaults.headers[method] = {};
});

utils.forEach(['post', 'put', 'patch'], function forEachMethodWithData(method) {
  defaults.headers[method] = utils.merge(DEFAULT_CONTENT_TYPE);
});

module.exports = defaults;


/***/ }),

/***/ "./node_modules/axios/lib/helpers/bind.js":
/*!************************************************!*\
  !*** ./node_modules/axios/lib/helpers/bind.js ***!
  \************************************************/
/***/ (function(module) {

"use strict";


module.exports = function bind(fn, thisArg) {
  return function wrap() {
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }
    return fn.apply(thisArg, args);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/buildURL.js":
/*!****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/buildURL.js ***!
  \****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

function encode(val) {
  return encodeURIComponent(val).
    replace(/%3A/gi, ':').
    replace(/%24/g, '$').
    replace(/%2C/gi, ',').
    replace(/%20/g, '+').
    replace(/%5B/gi, '[').
    replace(/%5D/gi, ']');
}

/**
 * Build a URL by appending params to the end
 *
 * @param {string} url The base of the url (e.g., http://www.google.com)
 * @param {object} [params] The params to be appended
 * @returns {string} The formatted url
 */
module.exports = function buildURL(url, params, paramsSerializer) {
  /*eslint no-param-reassign:0*/
  if (!params) {
    return url;
  }

  var serializedParams;
  if (paramsSerializer) {
    serializedParams = paramsSerializer(params);
  } else if (utils.isURLSearchParams(params)) {
    serializedParams = params.toString();
  } else {
    var parts = [];

    utils.forEach(params, function serialize(val, key) {
      if (val === null || typeof val === 'undefined') {
        return;
      }

      if (utils.isArray(val)) {
        key = key + '[]';
      } else {
        val = [val];
      }

      utils.forEach(val, function parseValue(v) {
        if (utils.isDate(v)) {
          v = v.toISOString();
        } else if (utils.isObject(v)) {
          v = JSON.stringify(v);
        }
        parts.push(encode(key) + '=' + encode(v));
      });
    });

    serializedParams = parts.join('&');
  }

  if (serializedParams) {
    var hashmarkIndex = url.indexOf('#');
    if (hashmarkIndex !== -1) {
      url = url.slice(0, hashmarkIndex);
    }

    url += (url.indexOf('?') === -1 ? '?' : '&') + serializedParams;
  }

  return url;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/combineURLs.js":
/*!*******************************************************!*\
  !*** ./node_modules/axios/lib/helpers/combineURLs.js ***!
  \*******************************************************/
/***/ (function(module) {

"use strict";


/**
 * Creates a new URL by combining the specified URLs
 *
 * @param {string} baseURL The base URL
 * @param {string} relativeURL The relative URL
 * @returns {string} The combined URL
 */
module.exports = function combineURLs(baseURL, relativeURL) {
  return relativeURL
    ? baseURL.replace(/\/+$/, '') + '/' + relativeURL.replace(/^\/+/, '')
    : baseURL;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/cookies.js":
/*!***************************************************!*\
  !*** ./node_modules/axios/lib/helpers/cookies.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs support document.cookie
    (function standardBrowserEnv() {
      return {
        write: function write(name, value, expires, path, domain, secure) {
          var cookie = [];
          cookie.push(name + '=' + encodeURIComponent(value));

          if (utils.isNumber(expires)) {
            cookie.push('expires=' + new Date(expires).toGMTString());
          }

          if (utils.isString(path)) {
            cookie.push('path=' + path);
          }

          if (utils.isString(domain)) {
            cookie.push('domain=' + domain);
          }

          if (secure === true) {
            cookie.push('secure');
          }

          document.cookie = cookie.join('; ');
        },

        read: function read(name) {
          var match = document.cookie.match(new RegExp('(^|;\\s*)(' + name + ')=([^;]*)'));
          return (match ? decodeURIComponent(match[3]) : null);
        },

        remove: function remove(name) {
          this.write(name, '', Date.now() - 86400000);
        }
      };
    })() :

  // Non standard browser env (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return {
        write: function write() {},
        read: function read() { return null; },
        remove: function remove() {}
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAbsoluteURL.js":
/*!*********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAbsoluteURL.js ***!
  \*********************************************************/
/***/ (function(module) {

"use strict";


/**
 * Determines whether the specified URL is absolute
 *
 * @param {string} url The URL to test
 * @returns {boolean} True if the specified URL is absolute, otherwise false
 */
module.exports = function isAbsoluteURL(url) {
  // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
  // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
  // by any combination of letters, digits, plus, period, or hyphen.
  return /^([a-z][a-z\d\+\-\.]*:)?\/\//i.test(url);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isAxiosError.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isAxiosError.js ***!
  \********************************************************/
/***/ (function(module) {

"use strict";


/**
 * Determines whether the payload is an error thrown by Axios
 *
 * @param {*} payload The value to test
 * @returns {boolean} True if the payload is an error thrown by Axios, otherwise false
 */
module.exports = function isAxiosError(payload) {
  return (typeof payload === 'object') && (payload.isAxiosError === true);
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/isURLSameOrigin.js":
/*!***********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/isURLSameOrigin.js ***!
  \***********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

module.exports = (
  utils.isStandardBrowserEnv() ?

  // Standard browser envs have full support of the APIs needed to test
  // whether the request URL is of the same origin as current location.
    (function standardBrowserEnv() {
      var msie = /(msie|trident)/i.test(navigator.userAgent);
      var urlParsingNode = document.createElement('a');
      var originURL;

      /**
    * Parse a URL to discover it's components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */
      function resolveURL(url) {
        var href = url;

        if (msie) {
        // IE needs attribute set twice to normalize properties
          urlParsingNode.setAttribute('href', href);
          href = urlParsingNode.href;
        }

        urlParsingNode.setAttribute('href', href);

        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
          href: urlParsingNode.href,
          protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, '') : '',
          host: urlParsingNode.host,
          search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, '') : '',
          hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, '') : '',
          hostname: urlParsingNode.hostname,
          port: urlParsingNode.port,
          pathname: (urlParsingNode.pathname.charAt(0) === '/') ?
            urlParsingNode.pathname :
            '/' + urlParsingNode.pathname
        };
      }

      originURL = resolveURL(window.location.href);

      /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */
      return function isURLSameOrigin(requestURL) {
        var parsed = (utils.isString(requestURL)) ? resolveURL(requestURL) : requestURL;
        return (parsed.protocol === originURL.protocol &&
            parsed.host === originURL.host);
      };
    })() :

  // Non standard browser envs (web workers, react-native) lack needed support.
    (function nonStandardBrowserEnv() {
      return function isURLSameOrigin() {
        return true;
      };
    })()
);


/***/ }),

/***/ "./node_modules/axios/lib/helpers/normalizeHeaderName.js":
/*!***************************************************************!*\
  !*** ./node_modules/axios/lib/helpers/normalizeHeaderName.js ***!
  \***************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ../utils */ "./node_modules/axios/lib/utils.js");

module.exports = function normalizeHeaderName(headers, normalizedName) {
  utils.forEach(headers, function processHeader(value, name) {
    if (name !== normalizedName && name.toUpperCase() === normalizedName.toUpperCase()) {
      headers[normalizedName] = value;
      delete headers[name];
    }
  });
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/parseHeaders.js":
/*!********************************************************!*\
  !*** ./node_modules/axios/lib/helpers/parseHeaders.js ***!
  \********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(/*! ./../utils */ "./node_modules/axios/lib/utils.js");

// Headers whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
var ignoreDuplicateOf = [
  'age', 'authorization', 'content-length', 'content-type', 'etag',
  'expires', 'from', 'host', 'if-modified-since', 'if-unmodified-since',
  'last-modified', 'location', 'max-forwards', 'proxy-authorization',
  'referer', 'retry-after', 'user-agent'
];

/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} headers Headers needing to be parsed
 * @returns {Object} Headers parsed into an object
 */
module.exports = function parseHeaders(headers) {
  var parsed = {};
  var key;
  var val;
  var i;

  if (!headers) { return parsed; }

  utils.forEach(headers.split('\n'), function parser(line) {
    i = line.indexOf(':');
    key = utils.trim(line.substr(0, i)).toLowerCase();
    val = utils.trim(line.substr(i + 1));

    if (key) {
      if (parsed[key] && ignoreDuplicateOf.indexOf(key) >= 0) {
        return;
      }
      if (key === 'set-cookie') {
        parsed[key] = (parsed[key] ? parsed[key] : []).concat([val]);
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ', ' + val : val;
      }
    }
  });

  return parsed;
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/spread.js":
/*!**************************************************!*\
  !*** ./node_modules/axios/lib/helpers/spread.js ***!
  \**************************************************/
/***/ (function(module) {

"use strict";


/**
 * Syntactic sugar for invoking a function and expanding an array for arguments.
 *
 * Common use case would be to use `Function.prototype.apply`.
 *
 *  ```js
 *  function f(x, y, z) {}
 *  var args = [1, 2, 3];
 *  f.apply(null, args);
 *  ```
 *
 * With `spread` this example can be re-written.
 *
 *  ```js
 *  spread(function(x, y, z) {})([1, 2, 3]);
 *  ```
 *
 * @param {Function} callback
 * @returns {Function}
 */
module.exports = function spread(callback) {
  return function wrap(arr) {
    return callback.apply(null, arr);
  };
};


/***/ }),

/***/ "./node_modules/axios/lib/helpers/validator.js":
/*!*****************************************************!*\
  !*** ./node_modules/axios/lib/helpers/validator.js ***!
  \*****************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var pkg = __webpack_require__(/*! ./../../package.json */ "./node_modules/axios/package.json");

var validators = {};

// eslint-disable-next-line func-names
['object', 'boolean', 'number', 'function', 'string', 'symbol'].forEach(function(type, i) {
  validators[type] = function validator(thing) {
    return typeof thing === type || 'a' + (i < 1 ? 'n ' : ' ') + type;
  };
});

var deprecatedWarnings = {};
var currentVerArr = pkg.version.split('.');

/**
 * Compare package versions
 * @param {string} version
 * @param {string?} thanVersion
 * @returns {boolean}
 */
function isOlderVersion(version, thanVersion) {
  var pkgVersionArr = thanVersion ? thanVersion.split('.') : currentVerArr;
  var destVer = version.split('.');
  for (var i = 0; i < 3; i++) {
    if (pkgVersionArr[i] > destVer[i]) {
      return true;
    } else if (pkgVersionArr[i] < destVer[i]) {
      return false;
    }
  }
  return false;
}

/**
 * Transitional option validator
 * @param {function|boolean?} validator
 * @param {string?} version
 * @param {string} message
 * @returns {function}
 */
validators.transitional = function transitional(validator, version, message) {
  var isDeprecated = version && isOlderVersion(version);

  function formatMessage(opt, desc) {
    return '[Axios v' + pkg.version + '] Transitional option \'' + opt + '\'' + desc + (message ? '. ' + message : '');
  }

  // eslint-disable-next-line func-names
  return function(value, opt, opts) {
    if (validator === false) {
      throw new Error(formatMessage(opt, ' has been removed in ' + version));
    }

    if (isDeprecated && !deprecatedWarnings[opt]) {
      deprecatedWarnings[opt] = true;
      // eslint-disable-next-line no-console
      console.warn(
        formatMessage(
          opt,
          ' has been deprecated since v' + version + ' and will be removed in the near future'
        )
      );
    }

    return validator ? validator(value, opt, opts) : true;
  };
};

/**
 * Assert object's properties type
 * @param {object} options
 * @param {object} schema
 * @param {boolean?} allowUnknown
 */

function assertOptions(options, schema, allowUnknown) {
  if (typeof options !== 'object') {
    throw new TypeError('options must be an object');
  }
  var keys = Object.keys(options);
  var i = keys.length;
  while (i-- > 0) {
    var opt = keys[i];
    var validator = schema[opt];
    if (validator) {
      var value = options[opt];
      var result = value === undefined || validator(value, opt, options);
      if (result !== true) {
        throw new TypeError('option ' + opt + ' must be ' + result);
      }
      continue;
    }
    if (allowUnknown !== true) {
      throw Error('Unknown option ' + opt);
    }
  }
}

module.exports = {
  isOlderVersion: isOlderVersion,
  assertOptions: assertOptions,
  validators: validators
};


/***/ }),

/***/ "./node_modules/axios/lib/utils.js":
/*!*****************************************!*\
  !*** ./node_modules/axios/lib/utils.js ***!
  \*****************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


var bind = __webpack_require__(/*! ./helpers/bind */ "./node_modules/axios/lib/helpers/bind.js");

// utils is a library of generic helper functions non-specific to axios

var toString = Object.prototype.toString;

/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Array, otherwise false
 */
function isArray(val) {
  return toString.call(val) === '[object Array]';
}

/**
 * Determine if a value is undefined
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if the value is undefined, otherwise false
 */
function isUndefined(val) {
  return typeof val === 'undefined';
}

/**
 * Determine if a value is a Buffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Buffer, otherwise false
 */
function isBuffer(val) {
  return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor)
    && typeof val.constructor.isBuffer === 'function' && val.constructor.isBuffer(val);
}

/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */
function isArrayBuffer(val) {
  return toString.call(val) === '[object ArrayBuffer]';
}

/**
 * Determine if a value is a FormData
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an FormData, otherwise false
 */
function isFormData(val) {
  return (typeof FormData !== 'undefined') && (val instanceof FormData);
}

/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */
function isArrayBufferView(val) {
  var result;
  if ((typeof ArrayBuffer !== 'undefined') && (ArrayBuffer.isView)) {
    result = ArrayBuffer.isView(val);
  } else {
    result = (val) && (val.buffer) && (val.buffer instanceof ArrayBuffer);
  }
  return result;
}

/**
 * Determine if a value is a String
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a String, otherwise false
 */
function isString(val) {
  return typeof val === 'string';
}

/**
 * Determine if a value is a Number
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Number, otherwise false
 */
function isNumber(val) {
  return typeof val === 'number';
}

/**
 * Determine if a value is an Object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is an Object, otherwise false
 */
function isObject(val) {
  return val !== null && typeof val === 'object';
}

/**
 * Determine if a value is a plain Object
 *
 * @param {Object} val The value to test
 * @return {boolean} True if value is a plain Object, otherwise false
 */
function isPlainObject(val) {
  if (toString.call(val) !== '[object Object]') {
    return false;
  }

  var prototype = Object.getPrototypeOf(val);
  return prototype === null || prototype === Object.prototype;
}

/**
 * Determine if a value is a Date
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Date, otherwise false
 */
function isDate(val) {
  return toString.call(val) === '[object Date]';
}

/**
 * Determine if a value is a File
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a File, otherwise false
 */
function isFile(val) {
  return toString.call(val) === '[object File]';
}

/**
 * Determine if a value is a Blob
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Blob, otherwise false
 */
function isBlob(val) {
  return toString.call(val) === '[object Blob]';
}

/**
 * Determine if a value is a Function
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */
function isFunction(val) {
  return toString.call(val) === '[object Function]';
}

/**
 * Determine if a value is a Stream
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a Stream, otherwise false
 */
function isStream(val) {
  return isObject(val) && isFunction(val.pipe);
}

/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {Object} val The value to test
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */
function isURLSearchParams(val) {
  return typeof URLSearchParams !== 'undefined' && val instanceof URLSearchParams;
}

/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 * @returns {String} The String freed of excess whitespace
 */
function trim(str) {
  return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g, '');
}

/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 */
function isStandardBrowserEnv() {
  if (typeof navigator !== 'undefined' && (navigator.product === 'ReactNative' ||
                                           navigator.product === 'NativeScript' ||
                                           navigator.product === 'NS')) {
    return false;
  }
  return (
    typeof window !== 'undefined' &&
    typeof document !== 'undefined'
  );
}

/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 */
function forEach(obj, fn) {
  // Don't bother if no value provided
  if (obj === null || typeof obj === 'undefined') {
    return;
  }

  // Force an array if not already something iterable
  if (typeof obj !== 'object') {
    /*eslint no-param-reassign:0*/
    obj = [obj];
  }

  if (isArray(obj)) {
    // Iterate over array values
    for (var i = 0, l = obj.length; i < l; i++) {
      fn.call(null, obj[i], i, obj);
    }
  } else {
    // Iterate over object keys
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        fn.call(null, obj[key], key, obj);
      }
    }
  }
}

/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 * @returns {Object} Result of all merge properties
 */
function merge(/* obj1, obj2, obj3, ... */) {
  var result = {};
  function assignValue(val, key) {
    if (isPlainObject(result[key]) && isPlainObject(val)) {
      result[key] = merge(result[key], val);
    } else if (isPlainObject(val)) {
      result[key] = merge({}, val);
    } else if (isArray(val)) {
      result[key] = val.slice();
    } else {
      result[key] = val;
    }
  }

  for (var i = 0, l = arguments.length; i < l; i++) {
    forEach(arguments[i], assignValue);
  }
  return result;
}

/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 * @return {Object} The resulting value of object a
 */
function extend(a, b, thisArg) {
  forEach(b, function assignValue(val, key) {
    if (thisArg && typeof val === 'function') {
      a[key] = bind(val, thisArg);
    } else {
      a[key] = val;
    }
  });
  return a;
}

/**
 * Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
 *
 * @param {string} content with BOM
 * @return {string} content value without BOM
 */
function stripBOM(content) {
  if (content.charCodeAt(0) === 0xFEFF) {
    content = content.slice(1);
  }
  return content;
}

module.exports = {
  isArray: isArray,
  isArrayBuffer: isArrayBuffer,
  isBuffer: isBuffer,
  isFormData: isFormData,
  isArrayBufferView: isArrayBufferView,
  isString: isString,
  isNumber: isNumber,
  isObject: isObject,
  isPlainObject: isPlainObject,
  isUndefined: isUndefined,
  isDate: isDate,
  isFile: isFile,
  isBlob: isBlob,
  isFunction: isFunction,
  isStream: isStream,
  isURLSearchParams: isURLSearchParams,
  isStandardBrowserEnv: isStandardBrowserEnv,
  forEach: forEach,
  merge: merge,
  extend: extend,
  trim: trim,
  stripBOM: stripBOM
};


/***/ }),

/***/ "./src/jnews/src/config.js":
/*!*********************************!*\
  !*** ./src/jnews/src/config.js ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JNewsServerURL": function() { return /* binding */ JNewsServerURL; },
/* harmony export */   "JegthemeServerURL": function() { return /* binding */ JegthemeServerURL; },
/* harmony export */   "adminURL": function() { return /* binding */ adminURL; },
/* harmony export */   "currentTime": function() { return /* binding */ currentTime; },
/* harmony export */   "domainURL": function() { return /* binding */ domainURL; },
/* harmony export */   "endpointAPI": function() { return /* binding */ endpointAPI; },
/* harmony export */   "licenseData": function() { return /* binding */ licenseData; },
/* harmony export */   "menus": function() { return /* binding */ menus; },
/* harmony export */   "nonceAPI": function() { return /* binding */ nonceAPI; },
/* harmony export */   "themeInfo": function() { return /* binding */ themeInfo; },
/* harmony export */   "themeURL": function() { return /* binding */ themeURL; },
/* harmony export */   "userId": function() { return /* binding */ userId; }
/* harmony export */ });
var _window$JNewsDashboar = window['JNewsDashboard'],
    themeInfo = _window$JNewsDashboar.themeInfo,
    menus = _window$JNewsDashboar.menus,
    licenseData = _window$JNewsDashboar.licenseData,
    userId = _window$JNewsDashboar.userId,
    currentTime = _window$JNewsDashboar.currentTime,
    nonceAPI = _window$JNewsDashboar.nonceAPI,
    endpointAPI = _window$JNewsDashboar.endpointAPI,
    themeURL = _window$JNewsDashboar.themeURL,
    adminURL = _window$JNewsDashboar.adminURL,
    domainURL = _window$JNewsDashboar.domainURL,
    JegthemeServerURL = _window$JNewsDashboar.JegthemeServerURL,
    JNewsServerURL = _window$JNewsDashboar.JNewsServerURL;


/***/ }),

/***/ "./src/jnews/src/content/content-wrapper.js":
/*!**************************************************!*\
  !*** ./src/jnews/src/content/content-wrapper.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _page_dashboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./page/dashboard-page */ "./src/jnews/src/content/page/dashboard-page.js");
/* harmony import */ var _page_import_demo_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./page/import-demo-page */ "./src/jnews/src/content/page/import-demo-page.js");
/* harmony import */ var _page_install_plugin_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./page/install-plugin-page */ "./src/jnews/src/content/page/install-plugin-page.js");
/* harmony import */ var _page_system_status_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./page/system-status-page */ "./src/jnews/src/content/page/system-status-page.js");
/* harmony import */ var _page_video_documentation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./page/video-documentation */ "./src/jnews/src/content/page/video-documentation.js");
/* harmony import */ var _page_empty_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./page/empty-page */ "./src/jnews/src/content/page/empty-page.js");
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var _page_not_found_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./page/not-found-page */ "./src/jnews/src/content/page/not-found-page.js");
/* harmony import */ var _page_performance_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./page/performance-page */ "./src/jnews/src/content/page/performance-page.js");
/* harmony import */ var _page_performance_performance_context__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./page/performance/performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");













/**
 * Blank Page Content
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var BlankPage = function BlankPage(props) {
  window.open(props.page.url, '_blank');
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_1__["default"], props, /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: props.page.url,
    target: "_blank",
    "data-key": "jnews&path=jnews_plugin"
  }, sprintf((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Open %s', '__text_domain__'), (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_9__["default"])(props.page.title))))));
};
/**
 * Content Switch
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var ContentSwitch = function ContentSwitch(props) {
  if (props.activePage) {
    switch (props.activePage.slug) {
      case 'jnews':
        return /*#__PURE__*/React.createElement(_page_dashboard_page__WEBPACK_IMPORTED_MODULE_3__["default"], {
          page: props.activePage,
          onNavItemClick: props.onNavItemClick
        });
        break;

      case 'jnews&path=jnews_import':
        return /*#__PURE__*/React.createElement(_page_import_demo_page__WEBPACK_IMPORTED_MODULE_4__["default"], {
          page: props.activePage
        });
        break;

      case 'jnews&path=jnews_plugin':
        return /*#__PURE__*/React.createElement(_page_install_plugin_page__WEBPACK_IMPORTED_MODULE_5__["default"], {
          page: props.activePage,
          loading: props.loading,
          onProcess: props.onProcess
        });
        break;

      case 'jnews&path=jnews_system':
        return /*#__PURE__*/React.createElement(_page_system_status_page__WEBPACK_IMPORTED_MODULE_6__["default"], {
          page: props.activePage
        });
        break;

      case 'jnews&path=jnews_performance':
        return /*#__PURE__*/React.createElement(_page_performance_performance_context__WEBPACK_IMPORTED_MODULE_12__.PerformanceContextProvider, null, /*#__PURE__*/React.createElement(_page_performance_page__WEBPACK_IMPORTED_MODULE_11__["default"], {
          page: props.activePage
        }));
        break;

      case 'jnews&path=jnews_documentation':
        return /*#__PURE__*/React.createElement(_page_video_documentation__WEBPACK_IMPORTED_MODULE_7__["default"], {
          page: props.activePage
        });
        break;

      default:
        if (props.activePage.url) {
          return /*#__PURE__*/React.createElement(BlankPage, {
            page: props.activePage
          });
        } else {
          return /*#__PURE__*/React.createElement(_page_empty_page__WEBPACK_IMPORTED_MODULE_8__["default"], {
            page: props.activePage,
            loading: props.loading,
            onProcess: props.onProcess
          });
        }

        break;
    }
  } else {
    return /*#__PURE__*/React.createElement(_page_not_found_page__WEBPACK_IMPORTED_MODULE_10__["default"], null);
  }
};
/**
 * Content wrapper component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var ContentWrapper = function ContentWrapper(props) {
  var pageList = {};
  var activePage = props.activePage,
      loading = props.loading,
      onProcess = props.onProcess,
      menus = props.menus;

  var registerPageList = function registerPageList(menus) {
    menus.map(function (menu) {
      pageList[menu.name] = {
        slug: menu.name,
        title: menu.title,
        url: menu.url
      };

      if (menu.menus) {
        registerPageList(menu.menus);
      }
    });
  };

  registerPageList(menus);
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-content"
  }, Object.keys(pageList).length > 0 && /*#__PURE__*/React.createElement(ContentSwitch, {
    activePage: pageList[activePage],
    loading: loading,
    onProcess: onProcess,
    onNavItemClick: props.onNavItemClick
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (ContentWrapper);

/***/ }),

/***/ "./src/jnews/src/content/content.js":
/*!******************************************!*\
  !*** ./src/jnews/src/content/content.js ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Content
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var Content = function Content(props) {
  var loading = props.loading,
      onProcess = props.onProcess;
  var slug = props.page.slug.replace('jnews&path=', '');
  var classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()('dashboard-content', 'content-' + slug);
  var is_migration = slug.indexOf('jnews_migration') > -1;

  if (is_migration) {
    var classMigration = slug.replace('_' + slug.replace('jnews_migration_', ''), '');
    classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()('dashboard-content', 'content-' + classMigration);
    slug = classMigration;
  }

  return (0,_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__.applyFilters)('content-' + slug, /*#__PURE__*/React.createElement("div", {
    className: classes
  }, props.children), {
    classes: classes,
    slug: props.page.slug.replace('jnews&path=', ''),
    loading: loading,
    onProcess: onProcess
  });
};

/* harmony default export */ __webpack_exports__["default"] = (Content);

/***/ }),

/***/ "./src/jnews/src/content/modal-error-handler.js":
/*!******************************************************!*\
  !*** ./src/jnews/src/content/modal-error-handler.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Error Handler
 *
 * @param {String|Boolean} message
 */

var errorHandler = function errorHandler(_ref) {
  var setPopupData = _ref.setPopupData,
      popupData = _ref.popupData,
      message = _ref.message;

  var update = function update() {
    var data = popupData;
    data.modalType = ['popup-warning', 'error-message'];
    data.header = {
      modalType: 'warning',
      icon: 'warning',
      showCloseButton: false,
      headerText: popupData.header.headerText ? popupData.header.headerText : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Failed!', '__text_domain__')
    };
    data.errorMessage = message;
    data.footer = {
      footerType: 'dashboard-action',
      children: function children(_ref2) {
        var closePopup = _ref2.closePopup;
        return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement("a", {
          className: "dashboard-button",
          onClick: closePopup
        }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('OK', '__text_domain__')));
      }
    };
    setPopupData(data);
  };

  update();
};

/* harmony default export */ __webpack_exports__["default"] = (errorHandler);

/***/ }),

/***/ "./src/jnews/src/content/modal-error.js":
/*!**********************************************!*\
  !*** ./src/jnews/src/content/modal-error.js ***!
  \**********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modal */ "./src/jnews/src/content/modal.js");



/**
 * Close confirmation component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ModalError = function ModalError(props) {
  var popupData = props.popupData,
      openModalError = props.openModalError,
      setOpenModalError = props.setOpenModalError;
  return /*#__PURE__*/React.createElement(_modal__WEBPACK_IMPORTED_MODULE_2__["default"], (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    open: openModalError,
    setOpen: setOpenModalError
  }, popupData), /*#__PURE__*/React.createElement("p", null, popupData.errorMessage));
};

/* harmony default export */ __webpack_exports__["default"] = (ModalError);

/***/ }),

/***/ "./src/jnews/src/content/modal.js":
/*!****************************************!*\
  !*** ./src/jnews/src/content/modal.js ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _util_esc_listener__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../util/esc-listener */ "./src/jnews/src/util/esc-listener.js");
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");





function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}







/**
 * Modal Header
 *
 * @param {object} param0
 * @returns {JSX.Element}
 */

var ModalHeader = function ModalHeader(_ref) {
  var modalType = _ref.modalType,
      icon = _ref.icon,
      _ref$showCloseButton = _ref.showCloseButton,
      showCloseButton = _ref$showCloseButton === void 0 ? true : _ref$showCloseButton,
      headerText = _ref.headerText,
      closePopup = _ref.closePopup;

  switch (modalType) {
    case 'success':
      modalType = 'success';
      break;

    case 'warning':
      modalType = 'warning';
      break;

    case 'notice':
      modalType = 'notice';
      break;

    default:
    case 'info':
      modalType = 'info';
      break;
  }

  switch (icon) {
    case 'check':
      icon = 'check';
      break;

    case 'notice':
      icon = 'notice';
      break;

    case 'info':
      icon = 'info';
      break;

    default:
    case 'question':
      icon = 'question';
      break;
  }

  var CloseButton = function CloseButton() {
    return /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__["default"], {
      icon: "close",
      closeButton: true,
      onClick: function onClick() {
        return closePopup();
      }
    });
  };

  return (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(function () {
    return /*#__PURE__*/React.createElement("div", {
      className: "jnews-popup-header"
    }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__["default"], {
      icon: icon,
      fillCircle: true,
      type: modalType
    }), showCloseButton && /*#__PURE__*/React.createElement(CloseButton, null), /*#__PURE__*/React.createElement("h3", null, headerText));
  }, [modalType, showCloseButton, headerText]);
};
/**
 * Modal Footer
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var ModalFooter = function ModalFooter(props) {
  var footerType = props.footerType,
      children = props.children,
      closePopup = props.closePopup;
  var footerClass = classnames__WEBPACK_IMPORTED_MODULE_7___default()('jnews-popup-footer', footerType);
  return /*#__PURE__*/React.createElement("div", {
    className: footerClass
  }, children && children({
    closePopup: closePopup
  }));
};
/**
 * Modal Content
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var ModalContent = function ModalContent(props) {
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-popup-content"
  }, props.children);
};
/**
 * Modal
 *
 * @param {object} param0
 * @returns {JSX.Element}
 */


var Modal = function Modal(_ref2) {
  var header = _ref2.header,
      footer = _ref2.footer,
      modalType = _ref2.modalType,
      refreshContent = _ref2.refreshContent,
      closablePopup = _ref2.closablePopup,
      children = _ref2.children,
      setOpen = _ref2.setOpen,
      open = _ref2.open;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_useState, 2),
      fade = _useState2[0],
      setFade = _useState2[1];

  var refreshPage = function refreshPage() {
    document.location.reload(true);
  };

  var closePopup = function closePopup() {
    if (closablePopup) {
      if (refreshContent) {
        refreshPage();
      } else {
        setFade(true);
        setTimeout(function () {
          setFade(false);
          setOpen(false);
        }, 200);
      }
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (open) {
      umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()('body').addClass('jnews-dashboard-popup-body');
    } else {
      umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()('body').removeClass('jnews-dashboard-popup-body');
    }
  }, [open]);

  var headerData = _objectSpread({}, header);

  var footerData = _objectSpread({}, footer);

  var popupClass = classnames__WEBPACK_IMPORTED_MODULE_7___default()('jnews-dashboard-popup', (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(modalType));
  return open && /*#__PURE__*/(0,react_dom__WEBPACK_IMPORTED_MODULE_5__.createPortal)( /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_7___default()('jnews-dashboard-popup-overlay', {
      open: open,
      fade: fade
    }),
    onClick: function onClick() {
      return closePopup();
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_7___default()(popupClass, {
      open: open,
      fade: fade
    })
  }, /*#__PURE__*/React.createElement(_util_esc_listener__WEBPACK_IMPORTED_MODULE_8__["default"], {
    execute: closePopup
  }), /*#__PURE__*/React.createElement(ModalHeader, (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, headerData, {
    closePopup: closePopup
  })), /*#__PURE__*/React.createElement(ModalContent, null, children), /*#__PURE__*/React.createElement(ModalFooter, (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, footerData, {
    closePopup: closePopup
  })))), document.getElementsByTagName('body')[0]);
};

/* harmony default export */ __webpack_exports__["default"] = (Modal);

/***/ }),

/***/ "./src/jnews/src/content/page/dashboard-page.js":
/*!******************************************************!*\
  !*** ./src/jnews/src/content/page/dashboard-page.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dashboard/dashboard-panel */ "./src/jnews/src/content/page/dashboard/dashboard-panel.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_6__);







/**
 * License Content
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var LicenseContent = function LicenseContent(props) {
  var navigationItemOnClick = function navigationItemOnClick(event) {
    event.preventDefault();
    props.onNavItemClick(umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()(event.currentTarget).data('key'));
  };

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement("p", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_3__["default"])(props.text)), (!props.validated || props.migration) && /*#__PURE__*/React.createElement(_dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__["default"], {
    additionalClasses: "jnews-activate-license-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "activate-license"
  }, /*#__PURE__*/React.createElement("a", {
    href: props.url,
    className: "dashboard-button button-hero"
  }, props.button)), /*#__PURE__*/React.createElement("p", {
    className: "description"
  }, props.description)), props.validated && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement(_dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__["default"], {
    additionalClasses: "panel-box greeting"
  }, /*#__PURE__*/React.createElement("div", {
    className: "jnews-greeting-cover"
  }, /*#__PURE__*/React.createElement("img", {
    src: "//assets.jnews.io/img/tf/thankyou.png",
    loading: "lazy"
  })), /*#__PURE__*/React.createElement("div", {
    className: "jnews-greeting-welcome"
  }, /*#__PURE__*/React.createElement("h3", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Thank you for choosing JNews', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_3__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('We would like to thank you for purchasing JNews! Before you get started, please be sure to always check out <a href="%s">Documentation</a>', '__text_domain__'), '//support.jegtheme.com/theme/jnews/'))), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('We provide video guidance on every page to help you understand how to use this theme.', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('We outline all kinds of good information, and provide you with all the details you need to use JNews.', '__text_domain__')))), /*#__PURE__*/React.createElement(_dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__["default"], {
    additionalClasses: "panel-box features"
  }, /*#__PURE__*/React.createElement("div", {
    className: "item-feature"
  }, /*#__PURE__*/React.createElement("div", {
    className: "feature"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "box-item-title"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa fa-plug"
  }), " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Supported Plugin', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('We provide list of all plugins that supported JNews. However, you are not limited to only install plugin from this list. To speed up your website performance please choose only necessary plugin.', '__text_domain__')), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: "#",
    "data-key": "jnews&path=jnews_plugin",
    onClick: navigationItemOnClick
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Install Plugins', '__text_domain__'))))), /*#__PURE__*/React.createElement("div", {
    className: "item-feature"
  }, /*#__PURE__*/React.createElement("div", {
    className: "feature"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "box-item-title"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa fa-cubes"
  }), " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Install Demo', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Installing demo and style as easy as one click. Our import system will also backup widget & customizer setting. Also, will restore both widget and customizer setting during uninstallation.', '__text_domain__')), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: "#",
    "data-key": "jnews&path=jnews_import",
    onClick: navigationItemOnClick
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Install Demo', '__text_domain__'))))), /*#__PURE__*/React.createElement("div", {
    className: "item-feature"
  }, /*#__PURE__*/React.createElement("div", {
    className: "feature"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "box-item-title"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa fa-life-buoy"
  }), " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Any Questions?', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)("Our online documentation is an incredible resource for learning how to use JNews. But if you still have any question, please don't hesitate to ask through our dedicated support forum.", '__text_domain__')), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: "//support.jegtheme.com/forums/forum/jnews/"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Documentation & Support', '__text_domain__'))))))));
};
/**
 * Content Dashboard
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var DashboardPage = function DashboardPage(props) {
  var _window$JNewsDashboar = window['JNewsDashboard'],
      themeInfo = _window$JNewsDashboar.themeInfo,
      licenseData = _window$JNewsDashboar.licenseData;
  var licenseContent = {
    text: licenseData.validated ? (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Congratulations! JNews is <span>activated</span> and ready to use. Get ready to create awesome news, magazine, or blog site using this theme. Read below for additional information. We hope you enjoy it!', '__text_domain__') : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Please activate the license of JNews theme to get automatic theme update, official support service and all benefits from JNews.', '__text_domain__'),
    url: licenseData.url,
    button: licenseData.migration ? (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Migrate JNews License', '__text_domain__') : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Activate JNews License', '__text_domain__'),
    description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Tips: You must be logged into the same Themeforest account that purchased JNews. If you already logged in, look in the top menu bar to ensure it is the right account.', '__text_domain__'),
    migration: licenseData.migration,
    validated: licenseData.validated
  };
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_4__["default"], props, /*#__PURE__*/React.createElement("h1", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_3__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Welcome to <strong>%s</strong>', '__text_domain__'), themeInfo.name)), /*#__PURE__*/React.createElement("span", {
    className: "theme-version"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Version %s', '__text_domain__'), themeInfo.version))), /*#__PURE__*/React.createElement(LicenseContent, (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({}, licenseContent, {
    onNavItemClick: props.onNavItemClick
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardPage);

/***/ }),

/***/ "./src/jnews/src/content/page/dashboard/dashboard-panel.js":
/*!*****************************************************************!*\
  !*** ./src/jnews/src/content/page/dashboard/dashboard-panel.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Dashboard panel
 * 
 * @param {object} props 
 * @returns {JSX.Element}
 */

var DashboardPanel = function DashboardPanel(props) {
  var additionalClasses = props.additionalClasses,
      children = props.children;
  var classes = classnames__WEBPACK_IMPORTED_MODULE_0___default()('jnews-dashboard-panel', additionalClasses);
  return /*#__PURE__*/React.createElement("div", {
    className: classes
  }, children);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardPanel);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/demo-item.js":
/*!******************************************************!*\
  !*** ./src/jnews/src/content/page/demo/demo-item.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");






var DemoCover = function DemoCover(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      loaded = _useState2[0],
      setLoaded = _useState2[1];

  var imageRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
  var classes = classnames__WEBPACK_IMPORTED_MODULE_2___default()('box-item-cover', {
    loaded: loaded
  });

  var DemoImage = function DemoImage() {
    return /*#__PURE__*/React.createElement("img", {
      ref: imageRef,
      src: props.image,
      alt: props.name,
      onLoad: function onLoad(e) {
        return setLoaded(true);
      },
      loading: "lazy"
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    setLoaded(false);
    if (imageRef.current.complete) setLoaded(true);
  }, [props.image]);
  return /*#__PURE__*/React.createElement("div", {
    className: classes
  }, /*#__PURE__*/React.createElement("div", {
    className: "box-item-overlay",
    "data-key": props.id
  }, props.id === props.installed_style && /*#__PURE__*/React.createElement("div", {
    className: "box-item-installed-notice"
  }, /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Installed', '__text_domain__')))), /*#__PURE__*/React.createElement(DemoImage, null));
};
/**
 * Demo Item
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var DemoItem = function DemoItem(props) {
  var action = props.id === props.installed_style ? 'uninstall' : props.id.indexOf('coming-soon') === -1 ? 'import' : 'coming-soon';
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-box-item item-demo",
    action: action
  }, /*#__PURE__*/React.createElement("div", {
    className: "item-wrapper"
  }, /*#__PURE__*/React.createElement(DemoCover, props), /*#__PURE__*/React.createElement("div", {
    className: "box-item-info"
  }, /*#__PURE__*/React.createElement("h3", null, props.name), props.id.indexOf('coming-soon') === -1 && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "dashboard-action"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper import"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button import",
    "data-id": props.id,
    onClick: props.onClickImportDemo
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Import', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper uninstall"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button uninstall",
    "data-id": props.id,
    onClick: props.onClickUninstallDemo
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Uninstall', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper preview"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button preview",
    target: "_blank",
    href: props.demo,
    rel: "noreferrer"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Preview', '__text_domain__'), /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_4__["default"], {
    icon: "external-link"
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "overlay"
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (DemoItem);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/demos.js":
/*!**************************************************!*\
  !*** ./src/jnews/src/content/page/demo/demos.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Demos
 * 
 * @param {object} props 
 * @returns {JSX.Element} 
 */
var Demos = function Demos(props) {
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-items demo-items"
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (Demos);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/import-demo-content.js":
/*!****************************************************************!*\
  !*** ./src/jnews/src/content/page/demo/import-demo-content.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../config */ "./src/jnews/src/config.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var compare_versions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! compare-versions */ "./node_modules/compare-versions/index.mjs");
/* harmony import */ var _demos__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./demos */ "./src/jnews/src/content/page/demo/demos.js");
/* harmony import */ var _demo_item__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./demo-item */ "./src/jnews/src/content/page/demo/demo-item.js");
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");
/* harmony import */ var _modal_error_handler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../modal-error-handler */ "./src/jnews/src/content/modal-error-handler.js");
/* harmony import */ var _util_pagination_pagination__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../util/pagination/pagination */ "./src/jnews/src/util/pagination/pagination.js");
/* harmony import */ var _util_library__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../../util/library */ "./src/jnews/src/util/library.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}













/**
 * Update popup data on uninstall demo
 *
 * @param {object} props
 */

var onUninstallDemo = function onUninstallDemo(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      setOpenUninstallConfirmation = props.setOpenUninstallConfirmation,
      setOpenPopupProgress = props.setOpenPopupProgress,
      selectedDemo = props.selectedDemo,
      demos = props.demos;

  var stepLine = function stepLine() {
    var value = 0;

    if (popupData["import"].steps) {
      value = popupData["import"].step_index / popupData["import"].steps.length * 100;
    }

    return /*#__PURE__*/React.createElement("span", {
      style: {
        width: value + '%'
      }
    });
  };

  var stepStatus = function stepStatus() {
    var value = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Preparing Data', '__text_domain__');

    if (popupData["import"].steps) {
      value = popupData["import"].step_status;
    }

    return /*#__PURE__*/React.createElement("span", {
      className: "status"
    }, value);
  };

  setOpenUninstallConfirmation(false);

  var update = function update() {
    var data = popupData;
    data.refreshContent = false;
    data.closablePopup = false;
    data.modalType = ['popup-info', 'uninstall-progress'];
    data.header = {
      modalType: 'info',
      icon: 'info',
      showCloseButton: false,
      headerText: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstalling Demo', '__text_domain__')
    };
    data.footer = {
      footerType: 'jnews-report',
      children: function children() {
        return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, stepStatus(), /*#__PURE__*/React.createElement("span", {
          className: "complete"
        }, popupData["import"].steps && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("span", null, popupData["import"].step_index, "/", popupData["import"].steps.length), ' ' + (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Completed', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
          className: "line"
        }, stepLine()));
      }
    };

    data.children = function () {
      return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("div", {
        className: "jnews-popup-info"
      }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__["default"], {
        icon: "notice-circle"
      }), /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Please do not refresh or close the page while uninstalling demo is in progress.', '__text_domain__'))), /*#__PURE__*/React.createElement("p", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_8__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstalling “<strong>%s</strong>” in progress...', '__text_domain__'), demos[selectedDemo].name))));
    };

    onUpdatePopupData(data);
  };

  update();
  setOpenPopupProgress(true);
};
/**
 * Update popup data on import demo
 *
 * @param {object} props
 */


var onImportDemo = function onImportDemo(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      setOpenImportConfirmation = props.setOpenImportConfirmation,
      setOpenPopupProgress = props.setOpenPopupProgress,
      selectedDemo = props.selectedDemo,
      demos = props.demos;

  if (demos[selectedDemo].install_theme_version) {
    var themeVersion = _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.parentVersion ? _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.parentVersion : _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.version;

    if ((0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.validate)(themeVersion)) {
      if (!(0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.compare)(themeVersion, demos[selectedDemo].install_theme_version, '>=')) {
        return;
      }
    }
  }

  var stepLine = function stepLine() {
    var value = 0;

    if (popupData["import"].steps) {
      value = popupData["import"].step_index / popupData["import"].steps.length * 100;
    }

    return /*#__PURE__*/React.createElement("span", {
      style: {
        width: value + '%'
      }
    });
  };

  var stepStatus = function stepStatus() {
    var value = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Preparing Data', '__text_domain__');

    if (popupData["import"].steps) {
      value = popupData["import"].step_status;
    }

    return /*#__PURE__*/React.createElement("span", {
      className: "status"
    }, value);
  };

  setOpenImportConfirmation(false);

  var update = function update() {
    var data = popupData;
    data.refreshContent = false;
    data.closablePopup = false;
    data.modalType = ['popup-info', 'install-progress'];
    data.header = {
      modalType: 'info',
      icon: 'info',
      showCloseButton: false,
      headerText: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Importing Demo', '__text_domain__')
    };
    data.footer = {
      footerType: 'jnews-report',
      children: function children() {
        return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, stepStatus(), /*#__PURE__*/React.createElement("span", {
          className: "complete"
        }, popupData["import"].steps && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("span", null, popupData["import"].step_index, "/", popupData["import"].steps.length), ' ' + (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Completed', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
          className: "line"
        }, stepLine()));
      }
    };

    data.children = function () {
      return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("div", {
        className: "jnews-popup-info"
      }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_9__["default"], {
        icon: "notice-circle"
      }), /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Please do not refresh or close the page while importing data is in progress.', '__text_domain__'))), /*#__PURE__*/React.createElement("p", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_8__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Importing “<strong>%s</strong>” in progress...', '__text_domain__'), demos[selectedDemo].name))));
    };

    onUpdatePopupData(data);
  };

  update();
  setOpenPopupProgress(true);
};
/**
 * Import Demo Content Component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var ImportDemoContent = function ImportDemoContent(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      setOpenImportConfirmation = props.setOpenImportConfirmation,
      setOpenUninstallConfirmation = props.setOpenUninstallConfirmation,
      setOpenModalError = props.setOpenModalError;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
    'coming-soon-1': {
      id: 'coming-soon-1',
      image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png',
      name: 'Coming Soon',
      demo: '#',
      group: ['coming-soon']
    },
    'coming-soon-2': {
      id: 'coming-soon-2',
      image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png',
      name: 'Coming Soon',
      demo: '#',
      'category-slug': ['coming-soon'],
      group: ['coming-soon']
    },
    'coming-soon-3': {
      id: 'coming-soon-3',
      image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png',
      name: 'Coming Soon',
      demo: '#',
      'category-slug': ['coming-soon'],
      group: ['coming-soon']
    }
  }),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      demos = _useState2[0],
      setDemos = _useState2[1];

  var purchase_code = _config__WEBPACK_IMPORTED_MODULE_3__.licenseData.purchase_code,
      validated = _config__WEBPACK_IMPORTED_MODULE_3__.licenseData.validated;

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(10),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      totalShowItem = _useState4[0],
      setTotalShowItem = _useState4[1];
  /**
   * Update popup data on click import demo
   *
   * @param {event} event
   */


  var onClickImportDemo = function onClickImportDemo(event) {
    var slug = event.currentTarget.dataset.id;
    var demo = demos[slug];

    if (validated || 'default' === slug) {
      var update = function update() {
        var data = popupData;
        data["import"].demo = demo;
        data.refreshContent = false;
        data.closablePopup = true;
        data.modalType = ['popup-notice', 'import-confirmation'];
        data.header = {
          modalType: 'notice',
          icon: 'notice',
          headerText: demo.name
        };
        data.footer = {
          footerType: 'dashboard-action',
          children: function children(_ref) {
            var closePopup = _ref.closePopup;
            return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("a", {
              onClick: function onClick() {
                onImportDemo(_objectSpread(_objectSpread(_objectSpread({}, props), {
                  selectedDemo: slug
                }), {}, {
                  demos: demos
                }));
              },
              className: "dashboard-button import"
            }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Demo', '__text_domain__')), /*#__PURE__*/React.createElement("a", {
              className: "dashboard-button cancel",
              onClick: closePopup
            }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Cancel', '__text_domain__')));
          }
        };
        onUpdatePopupData(data);
      };

      update();
      setOpenImportConfirmation(true);
    } else {
      var _update = function _update() {
        var data = popupData;
        data.header.headerText = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Warning!', '__text_domain__');
        (0,_modal_error_handler__WEBPACK_IMPORTED_MODULE_10__["default"])({
          popupData: data,
          message: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Please activate your copy of JNews to unlock this demo', '__text_domain__'),
          setPopupData: onUpdatePopupData
        });
      };

      _update();

      setOpenModalError(true);
    }
  };
  /**
   * Update popup data on click uninstall demo
   *
   * @param {event} event
   */


  var onClickUninstallDemo = function onClickUninstallDemo(event) {
    var slug = event.currentTarget.dataset.id;
    var demo = demos[slug];

    var update = function update() {
      var data = popupData;
      data["import"].demo = demo;
      data.refreshContent = false;
      data.closablePopup = true;
      data.modalType = ['popup-warning', 'uninstall-confirmation'];
      data.header = {
        modalType: 'warning',
        icon: 'warning',
        showCloseButton: false,
        headerText: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Warning', '__text_domain__')
      };
      data.footer = {
        footerType: 'dashboard-action',
        children: function children(_ref2) {
          var closePopup = _ref2.closePopup;
          return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("a", {
            onClick: function onClick() {
              return onUninstallDemo(_objectSpread(_objectSpread(_objectSpread({}, props), {
                selectedDemo: slug
              }), {}, {
                demos: demos
              }));
            },
            className: "dashboard-button uninstall"
          }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('OK', '__text_domain__')), /*#__PURE__*/React.createElement("a", {
            className: "dashboard-button cancel",
            onClick: closePopup
          }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Cancel', '__text_domain__')));
        }
      };
      onUpdatePopupData(data);
    };

    update();
    setOpenUninstallConfirmation(true);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    window.JNewsDashboard['loadedData'] = window.JNewsDashboard['loadedData'] || {};
    var loadedDataExist = window.JNewsDashboard['loadedData'];
    var loadedDataDemo = loadedDataExist ? loadedDataExist['demo'] : false;
    var themeVersion = _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.parentVersion ? _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.parentVersion : _config__WEBPACK_IMPORTED_MODULE_3__.themeInfo.version;

    if (!loadedDataExist || !loadedDataDemo) {
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_4__.getDemoList)({
        purchase_code: purchase_code,
        domain: _config__WEBPACK_IMPORTED_MODULE_3__.domainURL
      }).then(function (result) {
        loadedDataExist['demo'] = result;
        Object.keys(result).map(function (slug) {
          result[slug].name = (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_8__["default"])(result[slug].name);
          result[slug] = result[slug];

          if (result[slug].install_theme_version) {
            if (props.demoData.installed_style !== slug) {
              if ((0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.validate)(themeVersion)) {
                if (!(0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.compare)(themeVersion, result[slug].install_theme_version, '>=')) {
                  delete result[slug];
                }
              }
            }
          }
        });
        setDemos(JSON.parse(JSON.stringify(result).replace(/__domain__/gim, _config__WEBPACK_IMPORTED_MODULE_3__.domainURL)));
      });
    } else {
      if (loadedDataDemo) {
        var data = loadedDataDemo;
        Object.keys(data).map(function (slug) {
          data[slug].name = (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_8__["default"])(data[slug].name);
          data[slug] = data[slug];

          if (data[slug].install_theme_version) {
            if (props.demoData.installed_style !== slug) {
              if ((0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.validate)(themeVersion)) {
                if (!(0,compare_versions__WEBPACK_IMPORTED_MODULE_13__.compare)(themeVersion, data[slug].install_theme_version, '>=')) {
                  delete data[slug];
                }
              }
            }
          }
        });
        setDemos(JSON.parse(JSON.stringify(data).replace(/__domain__/gim, _config__WEBPACK_IMPORTED_MODULE_3__.domainURL)));
      }
    }
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var showWidth = function showWidth() {
      if ('undefined' !== typeof setTotalShowItem) {
        var screenWidth = (0,_util_library__WEBPACK_IMPORTED_MODULE_12__.windowWidth)();
        var showItem = 10;

        if (screenWidth > 1600) {
          showItem = 12;
        } else if (screenWidth >= 1440) {
          showItem = 10;
        } else if (screenWidth > 767) {
          showItem = 12;
        } else if (screenWidth >= 480) {
          showItem = 10;
        } else {
          showItem = 10;
        }

        if (totalShowItem !== showItem) {
          setTotalShowItem(showItem);
        }
      }
    };

    var resizeEvent = {
      resize: showWidth
    };
    showWidth();
    (0,_util_library__WEBPACK_IMPORTED_MODULE_12__.addEvents)(window, resizeEvent);
    return function () {
      return (0,_util_library__WEBPACK_IMPORTED_MODULE_12__.removeEvents)(window, resizeEvent);
    };
  });
  return (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(function () {
    return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("p", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_8__["default"])(props.text)), /*#__PURE__*/React.createElement(_util_pagination_pagination__WEBPACK_IMPORTED_MODULE_11__["default"], {
      pagedData: Object.keys(demos),
      pages: totalShowItem
    }, function (_ref3) {
      var pagedPaginations = _ref3.pagedPaginations,
          pageNow = _ref3.pageNow;

      if (pagedPaginations.length) {
        return /*#__PURE__*/React.createElement(_demos__WEBPACK_IMPORTED_MODULE_6__["default"], null, pagedPaginations[pageNow - 1].map(function (slug) {
          if (demos[slug]) {
            return /*#__PURE__*/React.createElement(_demo_item__WEBPACK_IMPORTED_MODULE_7__["default"], _objectSpread(_objectSpread({}, demos[slug]), {}, {
              installed_style: props.demoData.installed_style,
              onClickImportDemo: onClickImportDemo,
              onClickUninstallDemo: onClickUninstallDemo
            }));
          }
        }));
      }
    }));
  }, [demos, props.demoData.installed_style, totalShowItem]);
};

/* harmony default export */ __webpack_exports__["default"] = (ImportDemoContent);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/popup/close-confirmation.js":
/*!*********************************************************************!*\
  !*** ./src/jnews/src/content/page/demo/popup/close-confirmation.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../modal */ "./src/jnews/src/content/modal.js");



/**
 * Close confirmation component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var CloseConfirmation = function CloseConfirmation(props) {
  var popupData = props.popupData,
      openCloseConfirmation = props.openCloseConfirmation,
      setOpenCloseConfirmation = props.setOpenCloseConfirmation;

  var uninstalling = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Uninstall', '__text_domain__');

  var importing = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Import', '__text_domain__');

  return /*#__PURE__*/React.createElement(_modal__WEBPACK_IMPORTED_MODULE_2__["default"], (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    open: openCloseConfirmation,
    setOpen: setOpenCloseConfirmation
  }, popupData), /*#__PURE__*/React.createElement("p", null, sprintf((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('%s process success', '__text_domain__'), 'uninstall' === popupData["import"].type ? uninstalling : importing)));
};

/* harmony default export */ __webpack_exports__["default"] = (CloseConfirmation);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/popup/import-confirmation.js":
/*!**********************************************************************!*\
  !*** ./src/jnews/src/content/page/demo/popup/import-confirmation.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _control_control_checkbox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../control/control-checkbox */ "./src/jnews/src/control/control-checkbox.js");
/* harmony import */ var _control_control_radio_tab__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../control/control-radio-tab */ "./src/jnews/src/control/control-radio-tab.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../modal */ "./src/jnews/src/content/modal.js");
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");




function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}







/**
 * Import confirmation component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ImportConfirmation = function ImportConfirmation(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      openImportConfirmation = props.openImportConfirmation,
      setOpenImportConfirmation = props.setOpenImportConfirmation;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    install_plugin: true,
    include_content: true,
    builder_content: 'vc-content'
  }),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      values = _useState2[0],
      setValues = _useState2[1];

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    if (openImportConfirmation) {
      var update = function update() {
        var data = popupData;
        data["import"].type = 'import';
        data["import"].option = values;
        onUpdatePopupData(data);
      };

      update();
    }
  }, [openImportConfirmation, values]);
  /**
   * Update option import demo value
   *
   * @param {string} id
   * @param {*} value
   */

  var updateValue = function updateValue(id, value) {
    setValues(_objectSpread(_objectSpread({}, values), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])({}, id, value)));
  };
  /**
   * Builder content option
   *
   * @returns {JSX.Element}
   */


  var BuilderContent = function BuilderContent() {
    var dataImport = popupData["import"];
    var demo = dataImport.demo;
    var option = [],
        value;

    if (demo && demo.support) {
      if (demo.support.indexOf('elementor') > -1) {
        option.push({
          title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Elementor Only', '__text_domain__'),
          value: 'elementor-content',
          description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('We will only import all dummy pages that created with Elementor plugin.', '__text_domain__')
        });
        value = 'elementor-content';
      } else if (demo.support.indexOf('vc') > -1) {
        option.push({
          title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Visual Composer Only', '__text_domain__'),
          value: 'vc-content',
          description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('We will only import all dummy pages that created with WPBakery Page Builder (Visual Composer) plugin.', '__text_domain__')
        });
        value = 'vc-content';
      }
    } else {
      option = [{
        title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Visual Composer', '__text_domain__'),
        value: 'vc-content',
        description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('When you choose import Visual Composer Content, we will only import all dummy pages that created with WPBakery Page Builder (Visual Composer) plugin.', '__text_domain__')
      }, {
        title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Elementor', '__text_domain__'),
        value: 'elementor-content',
        description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('When you choose import Elementor Content, we will only import all dummy pages that created with Elementor plugin.', '__text_domain__')
      }];
      value = values.builder_content;
    }

    return values.include_content && /*#__PURE__*/React.createElement(_control_control_radio_tab__WEBPACK_IMPORTED_MODULE_5__["default"], {
      id: 'builder_content',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Builder Content', '__text_domain__'),
      options: option,
      globalValue: values['builder_content'],
      value: value,
      updateValue: updateValue
    });
  };

  return /*#__PURE__*/React.createElement(_modal__WEBPACK_IMPORTED_MODULE_7__["default"], (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    open: openImportConfirmation,
    setOpen: setOpenImportConfirmation
  }, popupData), /*#__PURE__*/React.createElement("div", {
    className: "jnews-popup-info"
  }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__["default"], {
    icon: "info-circle"
  }), /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Although we do not delete any content when importing the demo, we recommend you create your own backup before importing the demo.', '__text_domain__'))), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Choose how you want to import this demo:', '__text_domain__')), /*#__PURE__*/React.createElement("div", {
    className: "jnews-popup-option"
  }, /*#__PURE__*/React.createElement(_control_control_checkbox__WEBPACK_IMPORTED_MODULE_4__["default"], {
    id: 'install_plugin',
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Install Plugins', '__text_domain__'),
    description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('When you enable Install Plugins, we will install all plugins used in the demo to be imported', '__text_domain__'),
    value: values.install_plugin,
    updateValue: updateValue
  }), /*#__PURE__*/React.createElement(_control_control_checkbox__WEBPACK_IMPORTED_MODULE_4__["default"], {
    id: 'include_content',
    title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Include Content', '__text_domain__'),
    description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('When you enable Include Content, we will import demo content into your server. Content includes image, taxonomy, post & page (including landing page example), menu, widget, and customizer setting. We will also install required plugin to replicate the demo.', '__text_domain__'),
    value: values.include_content,
    updateValue: updateValue
  }), /*#__PURE__*/React.createElement(BuilderContent, null)));
};

/* harmony default export */ __webpack_exports__["default"] = (ImportConfirmation);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/popup/popup-progress.js":
/*!*****************************************************************!*\
  !*** ./src/jnews/src/content/page/demo/popup/popup-progress.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../modal */ "./src/jnews/src/content/modal.js");
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../../../config */ "./src/jnews/src/config.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _modal_error_handler__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../modal-error-handler */ "./src/jnews/src/content/modal-error-handler.js");





var _import, _uninstall, _progressText;

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}









var loadingText = '<span className="jnews-svg-wrapper jnews-svg-wrapper-no-margin"><i className="jnews-svg jnews-svg-loading spin"></i></span>';
var completeText = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)('<span>%s</span>', (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Completed', '__text_domain__'));
var progressText = (_progressText = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_progressText, "prepare", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Preparing Data', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_progressText, "prepareLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Preparing Data %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_progressText, "prepareSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Preparing Data %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_progressText, "import", (_import = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "plugin", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Required plugins', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "pluginLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Required Plugins %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "pluginSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Required Plugins %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "image", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Images', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "imageLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Images %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "imageSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Images %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "content", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Contents', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "contentLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Contents %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "contentSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Contents %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "style", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Install Global Style', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "styleLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Global Style %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_import, "styleSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Import Global Style %s', '__text_domain__'), completeText))), _import)), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_progressText, "uninstall", (_uninstall = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "plugin", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Required Plugins', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "pluginLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Required Plugins %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "pluginSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Required Plugins %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "image", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Images', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "imageLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Images %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "imageSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Images %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "content", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Contents', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "contentLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Contents %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "contentSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Contents %s', '__text_domain__'), completeText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "style", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Global Style', '__text_domain__')), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "styleLoading", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Global Style %s', '__text_domain__'), loadingText))), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_3__["default"])(_uninstall, "styleSuccess", (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_7__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Uninstall Global Style %s', '__text_domain__'), completeText))), _uninstall)), _progressText);
/**
 * Processing Step
 *
 * @param {array} steps
 * @param {string} action
 * @param {string} type
 * @param {object} data
 */

var stepProcess = function stepProcess(steps, action) {
  var type = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var data = arguments.length > 3 ? arguments[3] : undefined;
  var purchase_code = _config__WEBPACK_IMPORTED_MODULE_9__.licenseData.purchase_code;
  var setProgressStatus = data.setProgressStatus,
      onUpdatePopupData = data.onUpdatePopupData,
      setPrepare = data.setPrepare,
      setProgressPlugin = data.setProgressPlugin,
      setSteps = data.setSteps,
      popupData = data.popupData,
      setProgressImage = data.setProgressImage,
      setProgressContent = data.setProgressContent,
      setProgressStyle = data.setProgressStyle,
      onFinishDemo = data.onFinishDemo;
  var prepareFlag = ['backup', 'uninstall', 'prepare', 'check-step'];
  var pluginFlag = ['plugin', 'related-plugin'];
  var imageFlag = ['image'];
  var contentFlag = ['taxonomy', 'post', 'menu_location', 'menu', 'widget'];
  var styleFlag = ['customizer', 'style_only', 'elementor_setting'];
  var manageDemoParams = {
    id: popupData["import"].demo.id,
    action: action
  };
  /**
   * Update step list
   *
   * @param {array} newSteps
   */

  var updateStep = function updateStep(newSteps) {
    var update = function update() {
      var data = popupData;
      data["import"].steps = newSteps;
      onUpdatePopupData(data);
    };

    update();
    setSteps(newSteps);
  };
  /**
   * Update step progress
   *
   * @param {BigInteger|undefined} value
   */


  var updateProgress = function updateProgress(value) {
    var update = function update() {
      var data = popupData;

      if (0 === value) {
        data["import"].step_index = 0;
      } else {
        data["import"].step_index += 1;
      }

      onUpdatePopupData(data);
    };

    update();
  };
  /**
   * Update and merge plugin list with new plugin list
   *
   * @param {array} plugins
   */


  var updatePluginList = function updatePluginList(plugins) {
    var update = function update() {
      var data = popupData;
      data["import"].config.plugin = [].concat((0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(plugins), (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(data["import"].config.plugin));
      onUpdatePopupData(data);
    };

    update();
  };
  /**
   * Update progress status
   */


  var changeProgressStatus = function changeProgressStatus() {
    if (popupData["import"].step_index !== 0 && 'undefined' !== typeof popupData["import"].steps[popupData["import"].step_index - 1]) {
      var step = popupData["import"].steps[popupData["import"].step_index - 1].id;
      var currentStep = 'undefined' !== typeof popupData["import"].steps[popupData["import"].step_index] ? popupData["import"].steps[popupData["import"].step_index].id : ' ';

      if (prepareFlag.indexOf(step) !== -1 || prepareFlag.indexOf(currentStep) !== -1) {
        if (prepareFlag.indexOf(currentStep) !== -1) {
          setPrepare(progressText.prepareLoading);
        } else {
          setPrepare(progressText.prepareSuccess);
        }
      }

      if (pluginFlag.indexOf(step) !== -1 || pluginFlag.indexOf(currentStep) !== -1) {
        if (pluginFlag.indexOf(currentStep) !== -1) {
          setProgressPlugin(progressText[popupData["import"].type].pluginLoading);
        } else {
          setProgressPlugin(progressText[popupData["import"].type].pluginSuccess);
        }
      }

      if (imageFlag.indexOf(step) !== -1 || imageFlag.indexOf(currentStep) !== -1) {
        if (imageFlag.indexOf(currentStep) !== -1) {
          setProgressImage(progressText[popupData["import"].type].imageLoading);
        } else {
          setProgressImage(progressText[popupData["import"].type].imageSuccess);
        }
      }

      if (contentFlag.indexOf(step) !== -1 || contentFlag.indexOf(currentStep) !== -1) {
        if (contentFlag.indexOf(currentStep) !== -1) {
          setProgressContent(progressText[popupData["import"].type].contentLoading);
        } else {
          setProgressContent(progressText[popupData["import"].type].contentSuccess);
        }
      }

      if (styleFlag.indexOf(step) !== -1 || styleFlag.indexOf(currentStep) !== -1) {
        if (styleFlag.indexOf(currentStep) !== -1) {
          setProgressStyle(progressText[popupData["import"].type].styleLoading);
        } else {
          setProgressStyle(progressText[popupData["import"].type].styleSuccess);
        }
      }
    }

    var update = function update() {
      var data = popupData;
      data["import"].step_status = 'undefined' !== typeof popupData["import"].steps[popupData["import"].step_index] ? data["import"].steps[data["import"].step_index].text : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Finish', '__text_domain__');
      onFinishDemo('undefined' === typeof popupData["import"].steps[popupData["import"].step_index] ? popupData["import"].type : false);
      setProgressStatus(data["import"].step_status);
      onUpdatePopupData(data);
    };

    update();
  };
  /**
   * Update Demo Config from server
   *
   * @param {object} config
   */


  var setDemoConfig = function setDemoConfig(config) {
    var update = function update() {
      var data = popupData;
      data["import"].config = config;
      onUpdatePopupData(data);
    };

    update();
  };
  /**
   * Uninstall previous demo
   *
   * @param {array} item
   * @param {array} steps
   */


  var uninstallDemo = function uninstallDemo(item, steps) {
    if (item.length) {
      manageDemoParams.data = item[0];
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
        item.shift();
        uninstallDemo(item, steps);

        if (!item.length) {
          changeProgressStatus();
        }
      });
    } else {
      updateProgress();
      nextStep(steps[popupData["import"].step_index]);
    }
  };
  /**
   * Install plugins from demo config
   *
   * @param {array} plugins
   * @param {array} steps
   */


  var installPlugins = function installPlugins(plugins, steps) {
    if (plugins.length) {
      var _plugins$ = plugins[0],
          slug = _plugins$.slug,
          name = _plugins$.name,
          version = _plugins$.version,
          file = _plugins$.file,
          source = _plugins$.source,
          refresh = _plugins$.refresh;
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.checkPluginRemote)({
        source: source,
        slug: slug
      }).then(function (result) {
        var plugin_data = {};

        if (result) {
          if ('bundle' === result || 'server' === result) {
            plugin_data = {
              slug: slug,
              name: name,
              version: version,
              file: file,
              source: source,
              refresh: refresh,
              type: result
            };

            if ('server' === result) {
              var plugin_url = new URL(_config__WEBPACK_IMPORTED_MODULE_9__.JNewsServerURL + '/wp-json/' + 'jnews-server/v1/getJNewsData');
              plugin_url.searchParams.set('type', 'plugin');
              plugin_url.searchParams.set('name', source);
              plugin_url.searchParams.set('purchase_code', purchase_code);
              plugin_url.searchParams.set('domain', _config__WEBPACK_IMPORTED_MODULE_9__.domainURL);
              plugin_data.source = plugin_url;
            }
          } else {
            plugin_data = {
              slug: slug,
              name: name,
              version: version,
              file: file,
              refresh: refresh,
              type: result
            };
          }

          (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.managePlugin)({
            plugin: plugin_data,
            doing: 'activate'
          }).then(function (result) {
            plugins.shift();
            installPlugins(plugins, steps);

            if (!plugins.length) {
              changeProgressStatus();
            }
          });
        }
      });
    } else {
      updateProgress();
      nextStep(steps[popupData["import"].step_index]);
    }
  };
  /**
   * Import images from demo config
   *
   * @param {array} images
   * @param {array} steps
   */


  var importImages = function importImages(images, steps) {
    if (images.length) {
      var _data = {};
      _data[images[0][0]] = images[0][1];
      manageDemoParams.data = _data;
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
        if (result) {
          var update = function update() {
            var data = popupData;
            data["import"].config.image[images[0][0]] = result.data[images[0][0]];
            onUpdatePopupData(data);
          };

          update();
        }

        images.shift();
        importImages(images, steps);

        if (!images.length) {
          changeProgressStatus();
        }
      });
    } else {
      updateProgress();
      nextStep(steps[popupData["import"].step_index]);
    }
  };
  /**
   * Import posts from demo config
   *
   * @param {array} posts
   * @param {array} steps
   */


  var importPosts = function importPosts(posts, steps) {
    if (posts.length) {
      var _data2 = {},
          _type = posts[0][1]['post_type'],
          builder = popupData["import"].option.builder_content,
          content = '',
          vc_data = 'undefined' !== typeof posts[0][1]['content'] ? posts[0][1]['content'] : false,
          elementor_data = 'undefined' !== typeof posts[0][1]['metabox'] && 'undefined' !== typeof posts[0][1]['metabox']['_elementor_data'] && '' !== posts[0][1]['metabox']['_elementor_data'] ? posts[0][1]['metabox']['_elementor_data'] : false,
          isElementor = 'elementor-content' === builder && 'page' === _type,
          content_data = isElementor ? elementor_data : vc_data;
      content = isElementor ? elementor_data : vc_data;

      if (isElementor && !content_data) {
        content = vc_data;
      }

      if (checkPostContent(content)) {
        if ('elementor-content' === builder && 'page' === _type && content_data) {
          posts[0][1]['metabox']['_elementor_data'] = popupData["import"].config.content[content];
          posts[0][1]['content'] = '';
        } else {
          posts[0][1]['content'] = popupData["import"].config.content[content];
        }

        _data2[posts[0][0]] = posts[0][1];
        manageDemoParams.data = _data2;
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
          if (result) {
            var update = function update() {
              var data = popupData;
              data["import"].config.post[posts[0][0]] = result.data[posts[0][0]];
              onUpdatePopupData(data);
            };

            update();
          }

          posts.shift();
          importPosts(posts, steps);

          if (!posts.length) {
            changeProgressStatus();
          }
        });
      } else {
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.getDemoContent)({
          demo: popupData["import"].demo.id,
          content: content,
          purchase_code: purchase_code,
          domain: _config__WEBPACK_IMPORTED_MODULE_9__.domainURL
        }).then(function (result) {
          if (result || '' === result) {
            var update = function update() {
              var data = popupData;
              data["import"].config.content[content] = result;
              onUpdatePopupData(data);
            };

            update();
          } else {
            var _update = function _update() {
              var data = popupData;
              data["import"].config.content[content] = '';
              onUpdatePopupData(data);
            };

            _update();
          }

          importPosts(posts, steps);
        })["catch"](function (error) {
          var message = false;

          if (error) {
            message = error.message;
          }

          importErrorHandler(message);
        });
      }
    } else {
      updateProgress();
      nextStep(steps[popupData["import"].step_index]);
    }
  };
  /**
   * Check if post content exists
   *
   * @param {string} content
   * @returns {boolean}
   */


  var checkPostContent = function checkPostContent(content) {
    var hasContent = true;

    if ('undefined' === typeof popupData["import"].config.content) {
      var update = function update() {
        var data = popupData;
        data["import"].config.content = {};
        onUpdatePopupData(data);
      };

      update();
      hasContent = false;
    } else {
      if ('undefined' === typeof popupData["import"].config.content[content]) {
        hasContent = false;
      }
    }

    return hasContent;
  };
  /**
   * Import demo style
   *
   * @param {object} manageDemoParams
   * @param {array} steps
   */


  var importStyle = function importStyle(manageDemoParams, steps) {
    // check if style already have scheme
    if ('undefined' === typeof popupData["import"].config.customizer.mods['jnews_scheme_style']) {
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.getDemoScheme)({
        demo: popupData["import"].demo.id,
        purchase_code: purchase_code,
        domain: _config__WEBPACK_IMPORTED_MODULE_9__.domainURL
      }).then(function (result) {
        if (result) {
          var update = function update() {
            var data = popupData;
            data["import"].config.customizer.mods['jnews_scheme_style'] = result;
            onUpdatePopupData(data);
            manageDemoParams.demo = data["import"].config;
          };

          update();
        }

        (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
          if (result) {
            changeProgressStatus();
            updateProgress();
            nextStep(steps[popupData["import"].step_index]);
          }
        });
      })["catch"](function (error) {
        var message = false;

        if (error) {
          message = error.message;
        }

        importErrorHandler(message);
      });
    } else {
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
        if (result) {
          changeProgressStatus();
          updateProgress();
          nextStep(steps[popupData["import"].step_index]);
        }
      });
    }
  };
  /**
   * Run next step
   *
   * @param {object|undefined} step
   */


  var nextStep = function nextStep(step) {
    if ('undefined' !== typeof step) {
      runStep(step);
    } else {
      changeProgressStatus();
    }
  };
  /**
   * Run current step
   *
   * @param {object} step
   */


  var runStep = function runStep(step) {
    changeProgressStatus();
    manageDemoParams.step = step.id;
    manageDemoParams.option = popupData["import"].option;

    if ('check-step' !== step.id && 'prepare' !== step.id) {
      manageDemoParams.demo = popupData["import"].config;
    }

    switch (step.id) {
      case 'prepare':
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.getDemoConfig)({
          demo: popupData["import"].demo.id,
          purchase_code: purchase_code,
          domain: _config__WEBPACK_IMPORTED_MODULE_9__.domainURL,
          option: popupData["import"].option
        }).then(function (result) {
          if (result) {
            setDemoConfig(result);
            changeProgressStatus();
            updateProgress();
            nextStep(steps[popupData["import"].step_index]);
          }
        })["catch"](function (error) {
          var message = false;

          if (error) {
            message = error.message;
          }

          importErrorHandler(message);
        });
        break;

      case 'uninstall':
        var item = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(step.item);

        uninstallDemo(item, steps);
        break;

      case 'related-plugin':
        var plugins = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_2__["default"])(popupData["import"].config.plugin);

        installPlugins(plugins, steps);
        break;

      case 'image':
        var images = Object.keys(popupData["import"].config.image).map(function (slug) {
          return [slug, popupData["import"].config.image[slug]];
        });
        importImages(images, steps);
        break;

      case 'post':
        var posts = Object.keys(popupData["import"].config.post).map(function (slug) {
          return [slug, popupData["import"].config.post[slug]];
        });
        importPosts(posts, steps);
        break;

      case 'customizer':
      case 'style_only':
        importStyle(manageDemoParams, steps);
        break;

      default:
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_10__.manageDemo)(manageDemoParams).then(function (result) {
          var needUpdateProgress = true;
          var needChangeProgress = true;

          if (result) {
            if ('check-step' === step.id) {
              updateStep(result.data);
            }

            if ('plugin' === step.id) {
              needChangeProgress = false;
              updatePluginList(result.data);
            }

            if ('taxonomy' === step.id) {
              var update = function update() {
                var data = popupData;
                Object.keys(result.data).map(function (key) {
                  data["import"].config[key] = result.data[key];
                });
                onUpdatePopupData(data);
              };

              update();
            }

            if ('menu_location' === step.id) {
              var _update2 = function _update2() {
                var data = popupData;
                data["import"].config['menu_location'] = result.data;
                onUpdatePopupData(data);
              };

              _update2();
            }

            if (needChangeProgress) {
              changeProgressStatus();
            }

            if (needUpdateProgress) {
              updateProgress('check-step' === step.id ? 0 : undefined);
            }

            if ('check-step' !== step.id) {
              nextStep(steps[popupData["import"].step_index]);
            }
          }
        });
        break;
    }
  };
  /**
   * Error Handler
   *
   * @param {String|Boolean} message
   */


  var importErrorHandler = function importErrorHandler(message) {
    var data = popupData;
    data["import"].type = 'error';
    data.header.headerText = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Failed!', '__text_domain__');
    data.closablePopup = true;
    (0,_modal_error_handler__WEBPACK_IMPORTED_MODULE_11__["default"])({
      popupData: data,
      message: message,
      setPopupData: onUpdatePopupData
    });
    onFinishDemo('error');
  };

  if ('undefined' === typeof steps[popupData["import"].step_index - 1]) {
    nextStep(steps[popupData["import"].step_index]);
  }
};
/**
 * Import progress
 *
 * @param {object} data
 */


var importProgress = function importProgress(data) {
  var openPopupProgress = data.openPopupProgress,
      progressType = data.progressType,
      popupData = data.popupData,
      steps = data.steps,
      setSteps = data.setSteps,
      onUpdatePopupData = data.onUpdatePopupData,
      setProgressPlugin = data.setProgressPlugin,
      setProgressImage = data.setProgressImage,
      setProgressContent = data.setProgressContent,
      setProgressStyle = data.setProgressStyle,
      setProgressType = data.setProgressType;

  var update = function update() {
    var data = popupData;
    data["import"].steps = steps;
    onUpdatePopupData(data);
  };

  update();
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (openPopupProgress && steps) {
      window.onbeforeunload = function () {
        return (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('The demo you imported will be partially imported if you leave this page.', '__text_domain__');
      };

      setProgressType(popupData["import"].type);

      var _update3 = function _update3() {
        var data = popupData;
        data["import"].step_index = 0;
        onUpdatePopupData(data);
      };

      _update3();

      setSteps([{
        id: 'check-step',
        text: progressText.prepare
      }]);
    }
  }, [openPopupProgress]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (openPopupProgress && steps) {
      stepProcess(steps, popupData["import"].type, '', data);
    }
  }, [steps]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if ('' !== progressType) {
      setProgressPlugin(progressText[progressType].plugin);
      setProgressImage(progressText[progressType].image);
      setProgressContent(progressText[progressType].content);
      setProgressStyle(progressText[progressType].style);
    }
  }, [progressType]);
};
/**
 * Popup Progress Component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var PopupProgress = function PopupProgress(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      openPopupProgress = props.openPopupProgress,
      setOpenPopupProgress = props.setOpenPopupProgress,
      onFinishDemo = props.onFinishDemo;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(''),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      progressStatus = _useState2[0],
      setProgressStatus = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(''),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      progressType = _useState4[0],
      setProgressType = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(progressText.prepare),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      progressPrepare = _useState6[0],
      setPrepare = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(progressText['import'].plugin),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState7, 2),
      progressPlugin = _useState8[0],
      setProgressPlugin = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(progressText['import'].image),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState9, 2),
      progressImage = _useState10[0],
      setProgressImage = _useState10[1];

  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(progressText['import'].content),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState11, 2),
      progressContent = _useState12[0],
      setProgressContent = _useState12[1];

  var _useState13 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(progressText['import'].style),
      _useState14 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState13, 2),
      progressStyle = _useState14[0],
      setProgressStyle = _useState14[1];

  var _useState15 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]),
      _useState16 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState15, 2),
      steps = _useState16[0],
      setSteps = _useState16[1];

  var importData = {
    openPopupProgress: openPopupProgress,
    progressType: progressType,
    popupData: popupData,
    onUpdatePopupData: onUpdatePopupData,
    setProgressType: setProgressType,
    setPrepare: setPrepare,
    setProgressPlugin: setProgressPlugin,
    setProgressImage: setProgressImage,
    setProgressContent: setProgressContent,
    setProgressStyle: setProgressStyle,
    steps: steps,
    setSteps: setSteps,
    setProgressStatus: setProgressStatus,
    onFinishDemo: onFinishDemo
  };
  importProgress(_objectSpread({}, importData));
  return openPopupProgress && /*#__PURE__*/React.createElement(_modal__WEBPACK_IMPORTED_MODULE_6__["default"], (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    open: openPopupProgress,
    setOpen: setOpenPopupProgress
  }, popupData), ('import' === progressType || 'uninstall' === progressType) && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, popupData.children(), /*#__PURE__*/React.createElement("div", {
    className: "jnews-popup-progress"
  }, /*#__PURE__*/React.createElement("ul", null, 'import' === progressType && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, /*#__PURE__*/React.createElement("li", {
    "data-step": "prepare",
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      active: progressPrepare === progressText.prepareSuccess
    })
  }, progressPrepare), popupData["import"].option.install_plugin && /*#__PURE__*/React.createElement("li", {
    "data-step": "install-plugin",
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      active: progressPlugin === progressText[progressType].pluginSuccess
    })
  }, progressPlugin), popupData["import"].option.include_content && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, /*#__PURE__*/React.createElement("li", {
    "data-step": "".concat(progressType, "-image"),
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      active: progressImage === progressText[progressType].imageSuccess
    })
  }, progressImage), /*#__PURE__*/React.createElement("li", {
    "data-step": "".concat(progressType, "-content"),
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      active: progressContent === progressText[progressType].contentSuccess
    })
  }, progressContent)), /*#__PURE__*/React.createElement("li", {
    "data-step": "".concat(progressType, "-style"),
    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()({
      active: progressStyle === progressText[progressType].styleSuccess
    })
  }, progressStyle))))));
};

/* harmony default export */ __webpack_exports__["default"] = (PopupProgress);

/***/ }),

/***/ "./src/jnews/src/content/page/demo/popup/uninstall-confirmation.js":
/*!*************************************************************************!*\
  !*** ./src/jnews/src/content/page/demo/popup/uninstall-confirmation.js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../modal */ "./src/jnews/src/content/modal.js");





/**
 * Uninstall confirmation component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var UninstallConfirmation = function UninstallConfirmation(props) {
  var popupData = props.popupData,
      onUpdatePopupData = props.onUpdatePopupData,
      openUninstallConfirmation = props.openUninstallConfirmation,
      setOpenUninstallConfirmation = props.setOpenUninstallConfirmation;
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    if (openUninstallConfirmation) {
      var update = function update() {
        var data = popupData;
        data["import"].type = 'uninstall';
        (0,lodash__WEBPACK_IMPORTED_MODULE_2__.unset)(data["import"].option);
        onUpdatePopupData(data);
      };

      update();
    }
  }, [openUninstallConfirmation]);
  return /*#__PURE__*/React.createElement(_modal__WEBPACK_IMPORTED_MODULE_4__["default"], (0,_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__["default"])({
    open: openUninstallConfirmation,
    setOpen: setOpenUninstallConfirmation
  }, popupData), /*#__PURE__*/React.createElement("h3", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('Are you sure want to uninstall this demo?', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__.__)('This will remove dummy content and also all widgets you add on this demo. We highly recommend you to create backup before continue.', '__text_domain__')));
};

/* harmony default export */ __webpack_exports__["default"] = (UninstallConfirmation);

/***/ }),

/***/ "./src/jnews/src/content/page/documentation/video-block.js":
/*!*****************************************************************!*\
  !*** ./src/jnews/src/content/page/documentation/video-block.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_1__);


/**
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var VideoBlock = function VideoBlock(props) {
  var title = props.title,
      id = props.id,
      activeVideo = props.activeVideo,
      updateActiveVideo = props.updateActiveVideo;
  var itemClasses = classnames__WEBPACK_IMPORTED_MODULE_0___default()('video-item', {
    'video-active': activeVideo === id
  });
  /**
   * Video Block on click handler
   *
   * @param {Event} event
   */

  var videoBlockOnClick = function videoBlockOnClick(event) {
    event.preventDefault();
    updateActiveVideo(umbrellajs__WEBPACK_IMPORTED_MODULE_1___default()(event.currentTarget).data('video'));
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "video-item-wrapper"
  }, /*#__PURE__*/React.createElement("div", {
    className: itemClasses,
    "data-video": id,
    onClick: videoBlockOnClick
  }, /*#__PURE__*/React.createElement("div", {
    className: "video-play"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fa"
  })), /*#__PURE__*/React.createElement("span", null, title)));
};

/* harmony default export */ __webpack_exports__["default"] = (VideoBlock);

/***/ }),

/***/ "./src/jnews/src/content/page/documentation/youtube-iframe.js":
/*!********************************************************************!*\
  !*** ./src/jnews/src/content/page/documentation/youtube-iframe.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * YouTube Iframe
 * 
 * @param {object} props 
 * @returns {JSX.Element}
 */

var YouTubeIframe = function YouTubeIframe(props) {
  var id = props.id;
  var player;

  var loadVideo = function loadVideo() {
    // the Player object is created uniquely based on the id in props
    player = new window.YT.Player("youtube-player-".concat(id), {
      videoId: id,
      playerVars: {
        controls: 1,
        showinfo: 0,
        rel: 0,
        showsearch: 0,
        iv_load_policy: 3
      }
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (!window.YT) {
      // If not, load the script asynchronously
      var tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api'; // onYouTubeIframeAPIReady will load the video after the script is loaded

      window.onYouTubeIframeAPIReady = loadVideo;
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    } else {
      // If script is already there, load the video directly
      loadVideo();
    }
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "video-container-holder"
  }, /*#__PURE__*/React.createElement("div", {
    id: "youtube-player-".concat(id)
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (YouTubeIframe);

/***/ }),

/***/ "./src/jnews/src/content/page/empty-page.js":
/*!**************************************************!*\
  !*** ./src/jnews/src/content/page/empty-page.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");


/**
 * Empty page
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var EmptyPage = function EmptyPage(props) {
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_1__["default"], props));
};

/* harmony default export */ __webpack_exports__["default"] = (EmptyPage);

/***/ }),

/***/ "./src/jnews/src/content/page/import-demo-page.js":
/*!********************************************************!*\
  !*** ./src/jnews/src/content/page/import-demo-page.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _demo_import_demo_content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./demo/import-demo-content */ "./src/jnews/src/content/page/demo/import-demo-content.js");
/* harmony import */ var _demo_popup_import_confirmation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./demo/popup/import-confirmation */ "./src/jnews/src/content/page/demo/popup/import-confirmation.js");
/* harmony import */ var _demo_popup_uninstall_confirmation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./demo/popup/uninstall-confirmation */ "./src/jnews/src/content/page/demo/popup/uninstall-confirmation.js");
/* harmony import */ var _demo_popup_popup_progress__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./demo/popup/popup-progress */ "./src/jnews/src/content/page/demo/popup/popup-progress.js");
/* harmony import */ var _demo_popup_close_confirmation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./demo/popup/close-confirmation */ "./src/jnews/src/content/page/demo/popup/close-confirmation.js");
/* harmony import */ var _modal_error__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../modal-error */ "./src/jnews/src/content/modal-error.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}










/**
 * Import Demo Page Component
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ImportDemoPage = function ImportDemoPage(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      openImportConfirmation = _useState2[0],
      setOpenImportConfirmation = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      openPopupProgress = _useState4[0],
      setOpenPopupProgress = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      openUninstallConfirmation = _useState6[0],
      setOpenUninstallConfirmation = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState7, 2),
      openCloseConfirmation = _useState8[0],
      setOpenCloseConfirmation = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState9, 2),
      openModalError = _useState10[0],
      setOpenModalError = _useState10[1];

  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
    header: {},
    footer: {},
    modalType: '',
    closablePopup: true,
    refreshContent: false,
    "import": {}
  }),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState11, 2),
      popupData = _useState12[0],
      setPopupData = _useState12[1];
  /**
   * Set open close confirmation
   *
   * @param {boolean} finish
   */


  var onFinishDemo = function onFinishDemo(finish) {
    if (finish) {
      setTimeout(function () {
        setFinishDemo();
      }, 200);
    }
  };
  /**
   * Update popup data on finish demo
   *
   * @param {object} props
   */


  var setFinishDemo = function setFinishDemo() {
    window.onbeforeunload = null;

    if ('error' !== popupData["import"].type) {
      var update = function update() {
        var data = popupData;
        data.refreshContent = true;
        data.closablePopup = true;
        data.modalType = ['popup-success', 'finish-progress'];
        data.header = {
          modalType: 'success',
          icon: 'check',
          showCloseButton: false,
          headerText: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Congratulations!', '__text_domain__')
        };
        data.footer = {
          footerType: 'dashboard-action',
          children: function children(_ref) {
            var closePopup = _ref.closePopup;
            return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement("a", {
              className: "dashboard-button",
              onClick: closePopup
            }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('OK', '__text_domain__')));
          }
        };
        onUpdatePopupData(data, true);
      };

      update();
      setOpenCloseConfirmation(true);
    } else {
      setOpenModalError(true);
      setOpenCloseConfirmation(false);
    }

    setOpenImportConfirmation(false);
    setOpenUninstallConfirmation(false);
    setOpenPopupProgress(false);
  };
  /**
   * Set popup data on update popup data
   *
   * @param {object} popupData
   * @param {boolean} refresh
   */


  var onUpdatePopupData = function onUpdatePopupData(popupData) {
    var refresh = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    setPopupData(refresh ? _objectSpread({}, popupData) : popupData);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    if (!openImportConfirmation && !openPopupProgress && !openUninstallConfirmation && !openCloseConfirmation && !openModalError) {
      setPopupData({
        header: {},
        footer: {},
        modalType: '',
        refreshContent: false,
        closablePopup: true,
        "import": {}
      });
    }
  }, [openImportConfirmation, openPopupProgress, openUninstallConfirmation, openCloseConfirmation, openModalError]);
  var _window$JNewsDashboar = window['JNewsDashboard'],
      licenseData = _window$JNewsDashboar.licenseData,
      demoData = _window$JNewsDashboar.demoData;
  var importData = {
    demoData: demoData,
    text: licenseData.validated ? (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('The imported demo will show you about the website structure, theme setting, content structure, design template and etc. In this case, you will be more familiar working with JNews. The imported demo is also fully customizable. Feel free to play around with your own design. Read <a target="_blank" href="%s">here</a> for more information.', '__text_domain__'), 'http://support.jegtheme.com/documentation/import-content-style/') : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Please activate the license of JNews theme to unlock all import demo & style feature. Read <a target="_blank" href="%s">here</a> for more information.', '__text_domain__'), 'https://support.jegtheme.com/documentation/activate-license/'),
    url: licenseData.url,
    button: licenseData.migration ? (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Migrate JNews License', '__text_domain__') : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Activate JNews License', '__text_domain__'),
    description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Tips: You must be logged into the same Themeforest account that purchased JNews. If you already logged in, look in the top menu bar to ensure it is the right account.', '__text_domain__'),
    migration: licenseData.migration,
    validated: licenseData.validated
  };
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_4__["default"], props, /*#__PURE__*/React.createElement("h1", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Import Demo & Style', '__text_domain__')), /*#__PURE__*/React.createElement(_demo_import_demo_content__WEBPACK_IMPORTED_MODULE_5__["default"], _objectSpread(_objectSpread({}, importData), {}, {
    onUpdatePopupData: onUpdatePopupData,
    popupData: popupData,
    setOpenImportConfirmation: setOpenImportConfirmation,
    setOpenUninstallConfirmation: setOpenUninstallConfirmation,
    setOpenPopupProgress: setOpenPopupProgress,
    setOpenCloseConfirmation: setOpenCloseConfirmation,
    setOpenModalError: setOpenModalError
  }))), /*#__PURE__*/React.createElement(_demo_popup_popup_progress__WEBPACK_IMPORTED_MODULE_8__["default"], {
    openPopupProgress: openPopupProgress,
    setOpenPopupProgress: setOpenPopupProgress,
    popupData: popupData,
    onUpdatePopupData: onUpdatePopupData,
    onFinishDemo: onFinishDemo
  }), /*#__PURE__*/React.createElement(_demo_popup_import_confirmation__WEBPACK_IMPORTED_MODULE_6__["default"], {
    openImportConfirmation: openImportConfirmation,
    setOpenImportConfirmation: setOpenImportConfirmation,
    popupData: popupData,
    onUpdatePopupData: onUpdatePopupData
  }), /*#__PURE__*/React.createElement(_demo_popup_uninstall_confirmation__WEBPACK_IMPORTED_MODULE_7__["default"], {
    openUninstallConfirmation: openUninstallConfirmation,
    setOpenUninstallConfirmation: setOpenUninstallConfirmation,
    popupData: popupData,
    onUpdatePopupData: onUpdatePopupData
  }), /*#__PURE__*/React.createElement(_demo_popup_close_confirmation__WEBPACK_IMPORTED_MODULE_9__["default"], {
    openCloseConfirmation: openCloseConfirmation,
    setOpenCloseConfirmation: setOpenCloseConfirmation,
    popupData: popupData,
    onUpdatePopupData: onUpdatePopupData,
    setOpenImportConfirmation: setOpenImportConfirmation,
    setOpenUninstallConfirmation: setOpenUninstallConfirmation,
    setOpenPopupProgress: setOpenPopupProgress
  }), /*#__PURE__*/React.createElement(_modal_error__WEBPACK_IMPORTED_MODULE_10__["default"], {
    openModalError: openModalError,
    setOpenModalError: setOpenModalError,
    popupData: popupData
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (ImportDemoPage);

/***/ }),

/***/ "./src/jnews/src/content/page/install-plugin-page.js":
/*!***********************************************************!*\
  !*** ./src/jnews/src/content/page/install-plugin-page.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _side_content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../side-content */ "./src/jnews/src/content/side-content.js");
/* harmony import */ var _plugin_install_plugin_content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./plugin/install-plugin-content */ "./src/jnews/src/content/page/plugin/install-plugin-content.js");
/* harmony import */ var _plugin_plugin_categories__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./plugin/plugin-categories */ "./src/jnews/src/content/page/plugin/plugin-categories.js");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");
/* harmony import */ var _plugin_search_plugins__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./plugin/search-plugins */ "./src/jnews/src/content/page/plugin/search-plugins.js");
/* harmony import */ var _navigation_navigation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../navigation/navigation */ "./src/jnews/src/navigation/navigation.js");
/* harmony import */ var _plugin_plugin_bulk_action__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./plugin/plugin-bulk-action */ "./src/jnews/src/content/page/plugin/plugin-bulk-action.js");














var REQUIRE_RELOAD = ['jnews-essential', 'jnews-front-translation', 'jnews-migration-jmagz', 'jnews-migration-newspaper', 'jnews-migration-publisher', 'jnews-migration-jannah', 'jnews-migration-sahifa', 'jnews-migration-soledad', 'jnews-migration-newsmag'];
/**
 * Install Plugin Page
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var InstallPluginPage = function InstallPluginPage(props) {
  var _React$createElement;

  var pluginData = window['JNewsDashboard'].pluginData;
  var locationURL = new URL(window.location.href);
  var urlCategory = locationURL.searchParams.get('category');
  var timerRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      progressBar = _useState2[0],
      setProgressBar = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState3, 2),
      openModalError = _useState4[0],
      setOpenModalError = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    header: {},
    footer: {},
    modalType: '',
    closablePopup: true,
    refreshContent: false
  }),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState5, 2),
      popupData = _useState6[0],
      setPopupData = _useState6[1]; // Loading handler


  var loading = props.loading,
      onProcess = props.onProcess;

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState7, 2),
      localLoading = _useState8[0],
      onLocalProcess = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState9, 2),
      inAction = _useState10[0],
      setInAction = _useState10[1]; // notice handler


  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState11, 2),
      actionNotice = _useState12[0],
      onActionNotice = _useState12[1]; // bulk action handler


  var _useState13 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]),
      _useState14 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState13, 2),
      selectedPlugin = _useState14[0],
      setSelectedPlugin = _useState14[1];

  var _useState15 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState16 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState15, 2),
      openBulkActionList = _useState16[0],
      setOpenBulkActionList = _useState16[1];

  var _useState17 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)('default'),
      _useState18 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState17, 2),
      selectedBulkAction = _useState18[0],
      setSelectedBulkAction = _useState18[1]; // Filter


  var _useState19 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState20 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState19, 2),
      searchFilter = _useState20[0],
      setSearchFilter = _useState20[1];

  var _useState21 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(urlCategory ? urlCategory.split(',') : ['all']),
      _useState22 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState21, 2),
      activeCategories = _useState22[0],
      setActiveCategories = _useState22[1];

  var _useState23 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)('welcome'),
      _useState24 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState23, 2),
      activeGroups = _useState24[0],
      setActiveGroups = _useState24[1];

  var _useState25 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    all: {
      type: 'all',
      title: 'All',
      icon: 'plug-circle-transparent'
    },
    installed: {
      type: 'installed',
      title: 'Installed',
      icon: 'arrow-down-circle-transparent'
    },
    activated: {
      type: 'activated',
      title: 'Activated',
      icon: 'check-circle-transparent'
    },
    deactivated: {
      type: 'deactivated',
      title: 'Deactivated'
    },
    'require-update': {
      type: 'require-update',
      title: 'Update Available',
      icon: 'info-circle-transparent'
    }
  }),
      _useState26 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState25, 2),
      categories = _useState26[0],
      setCategories = _useState26[1]; // Plugins list


  var _useState27 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
    'coming-soon-1': {
      slug: 'coming-soon-1',
      detail: {
        image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png'
      },
      group: ['coming-soon'].concat((0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(activeCategories)),
      installed: true,
      require_update: true,
      activated: true,
      name: 'Coming Soon'
    },
    'coming-soon-2': {
      slug: 'coming-soon-2',
      detail: {
        image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png'
      },
      group: ['coming-soon'].concat((0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(activeCategories)),
      installed: true,
      require_update: true,
      activated: true,
      name: 'Coming Soon'
    },
    'coming-soon-3': {
      slug: 'coming-soon-3',
      detail: {
        image: 'https://jegtheme.com/asset/jnews/demo-thumbnail/placeholder.png'
      },
      group: ['coming-soon'].concat((0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(activeCategories)),
      installed: true,
      require_update: true,
      activated: true,
      name: 'Coming Soon'
    }
  }),
      _useState28 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState27, 2),
      plugins = _useState28[0],
      setPlugins = _useState28[1];

  var onSetActiveGroups = function onSetActiveGroups(value) {
    setSearchFilter(false);
    setActiveGroups(value);
  };

  var groupItems = Object.keys(categories).filter(function (slug) {
    if ('activated' === slug || 'installed' === slug || 'require-update' === slug || 'all' === slug) {
      return true;
    }

    return false;
  }).reduce(function (res, key) {
    return res[key] = categories[key], res;
  }, {});
  var groupItemMenus = Object.keys(groupItems).filter(function (slug) {
    var loadedDataExist = window.JNewsDashboard['loadedData'];
    var loadedDataPlugin = loadedDataExist ? loadedDataExist['plugin'] : false;

    if ('activated' === slug || 'installed' === slug || 'all' === slug) {
      return true;
    }

    if (loadedDataPlugin) {
      if ('require-update' === slug) {
        return true;
      }
    }

    return false;
  }).map(function (key) {
    return groupItems[key].badge ? {
      name: groupItems[key].type,
      title: groupItems[key].title,
      icon: groupItems[key].icon,
      badge: groupItems[key].badge
    } : {
      name: groupItems[key].type,
      title: groupItems[key].title,
      icon: groupItems[key].icon
    };
  });
  (0,_wordpress_hooks__WEBPACK_IMPORTED_MODULE_9__.addAction)('jnews.after.manage.plugin', 'jnews/action/after/manage/plugin', function (slug) {
    if (REQUIRE_RELOAD.indexOf(slug) > -1) {
      setTimeout(function () {
        window.location.reload();
      }, 500);
    }
  });
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_5__["default"], {
    page: {
      slug: 'inner'
    }
  }, /*#__PURE__*/React.createElement(_side_content__WEBPACK_IMPORTED_MODULE_6__["default"], null, /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-notice"
  }, /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-notice-header"
  }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_10__["default"], {
    icon: "notice-circle",
    fillCircle: false,
    type: "notice"
  }), /*#__PURE__*/React.createElement("h3", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__.__)('Install Plugin', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-notice-content"
  }, /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__.__)('Only install plugin that you need to make your website lighter & faster', '__text_domain__')))), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-side-content-inner"
  }, /*#__PURE__*/React.createElement(_plugin_search_plugins__WEBPACK_IMPORTED_MODULE_11__["default"], {
    loading: loading,
    searchFilter: searchFilter,
    setSearchFilter: setSearchFilter,
    localLoading: localLoading
  }), /*#__PURE__*/React.createElement(_plugin_plugin_categories__WEBPACK_IMPORTED_MODULE_8__["default"], {
    categories: categories,
    activeCategories: activeCategories,
    loading: loading,
    localLoading: localLoading,
    setActiveCategories: setActiveCategories,
    onProcess: onProcess,
    onLocalProcess: onLocalProcess
  }))), /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_5__["default"], props, /*#__PURE__*/React.createElement(_navigation_navigation__WEBPACK_IMPORTED_MODULE_12__["default"], {
    timerRef: timerRef,
    setCurrentMenu: onSetActiveGroups,
    currentMenu: activeGroups,
    loading: loading,
    menus: groupItemMenus,
    customClass: "split-right",
    rightMenu: function rightMenu() {
      return /*#__PURE__*/React.createElement(_plugin_plugin_bulk_action__WEBPACK_IMPORTED_MODULE_13__["default"], {
        setOpenBulkActionList: setOpenBulkActionList,
        setSelectedBulkAction: setSelectedBulkAction,
        onProcess: onProcess,
        onLocalProcess: onLocalProcess,
        setSelectedPlugin: setSelectedPlugin,
        setPlugins: setPlugins,
        setProgressBar: setProgressBar,
        setOpenModalError: setOpenModalError,
        setPopupData: setPopupData,
        onActionNotice: onActionNotice,
        setInAction: setInAction,
        setCategories: setCategories,
        pluginData: pluginData,
        openBulkActionList: openBulkActionList,
        loading: loading,
        localLoading: localLoading,
        selectedBulkAction: selectedBulkAction,
        selectedPlugin: selectedPlugin,
        plugins: plugins,
        progressBar: progressBar,
        openModalError: openModalError,
        popupData: popupData,
        inAction: inAction
      });
    }
  }), /*#__PURE__*/React.createElement(_plugin_install_plugin_content__WEBPACK_IMPORTED_MODULE_7__["default"], (_React$createElement = {
    searchFilter: searchFilter,
    activeCategories: activeCategories,
    activeGroups: activeGroups,
    loading: loading,
    localLoading: localLoading,
    actionNotice: actionNotice,
    selectedPlugin: selectedPlugin,
    plugins: plugins,
    progressBar: progressBar,
    openModalError: openModalError,
    popupData: popupData,
    onActionNotice: onActionNotice,
    setInAction: setInAction,
    setCategories: setCategories,
    onProcess: onProcess,
    onLocalProcess: onLocalProcess
  }, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "onActionNotice", onActionNotice), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "setSelectedPlugin", setSelectedPlugin), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "setPlugins", setPlugins), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "setProgressBar", setProgressBar), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "setOpenModalError", setOpenModalError), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "setPopupData", setPopupData), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_React$createElement, "inAction", inAction), _React$createElement)))));
};

/* harmony default export */ __webpack_exports__["default"] = (InstallPluginPage);

/***/ }),

/***/ "./src/jnews/src/content/page/not-found-page.js":
/*!******************************************************!*\
  !*** ./src/jnews/src/content/page/not-found-page.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Empty page
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var NotFound = function NotFound() {
  var classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()('dashboard-content', 'content-not-found');
  return /*#__PURE__*/React.createElement("div", {
    className: classes
  }, /*#__PURE__*/React.createElement("h1", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Page Not Found', '__text_domain__')));
};

/* harmony default export */ __webpack_exports__["default"] = (NotFound);

/***/ }),

/***/ "./src/jnews/src/content/page/performance-page.js":
/*!********************************************************!*\
  !*** ./src/jnews/src/content/page/performance-page.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dashboard/dashboard-panel */ "./src/jnews/src/content/page/dashboard/dashboard-panel.js");
/* harmony import */ var _navigation_navigation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../navigation/navigation */ "./src/jnews/src/navigation/navigation.js");
/* harmony import */ var _performance_performance_page_content__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./performance/performance-page-content */ "./src/jnews/src/content/page/performance/performance-page-content.js");
/* harmony import */ var _performance_performance_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./performance/performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}









var PerformancePage = function PerformancePage(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      isLoading = _useState2[0],
      setIsLoading = _useState2[1];

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_performance_performance_context__WEBPACK_IMPORTED_MODULE_8__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var timerRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null); // Loading handler

  var loading = props.loading,
      onProcess = props.onProcess; // Filter

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('optimization-plugin'),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      nextPage = _useState4[0],
      setNextPage = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)('mode'),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      activeGroups = _useState6[0],
      setActiveGroups = _useState6[1];

  var defaultMenu = {
    'mode': {
      type: 'mode',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Mode', '__text_domain__'),
      mode: ['easy', 'advance']
    },
    'optimization-plugin': {
      type: 'optimization-plugin',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Plugins', '__text_domain__'),
      mode: ['easy', 'advance']
    },
    'easy-plugin-options': {
      type: 'easy-plugin-options',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Optimization', '__text_domain__'),
      mode: ['easy']
    },
    'plugin-options': {
      type: 'plugin-options',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Plugin Options', '__text_domain__'),
      mode: ['advance']
    },
    'caching-options': {
      type: 'caching-options',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Caching', '__text_domain__'),
      mode: ['advance']
    },
    'core-web-vital': {
      type: 'core-web-vital',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Core Web Vital', '__text_domain__'),
      mode: ['advance']
    },
    'page-optimization': {
      type: 'page-optimization',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Page', '__text_domain__'),
      description: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Force normal load the lazyloaded image that considered as LCP (Largest Content paintful)', '__text_domain__'),
      mode: ['easy', 'advance']
    },
    'elements': {
      type: 'elements',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Element', '__text_domain__'),
      mode: ['easy', 'advance']
    },
    'feature-and-plugins': {
      type: 'feature-and-plugins',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Features', '__text_domain__'),
      mode: ['advance']
    },
    'server': {
      type: 'server',
      title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Server', '__text_domain__'),
      mode: ['advance']
    }
  };

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(defaultMenu),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState7, 2),
      categories = _useState8[0],
      setCategories = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState9, 2),
      groupItemMenus = _useState10[0],
      setGroupItemMenus = _useState10[1];

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    setPerformanceContext(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, {
        configs: window['JNewsDashboard'].PerformanceConfigs
      });
    });
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var items = {};

    if (performanceContext.mode) {
      Object.keys(defaultMenu).forEach(function (slug) {
        if (defaultMenu[slug].mode.includes(performanceContext.mode.mode.value)) {
          items[slug] = defaultMenu[slug];
        }
      });
      setCategories(items);
      var groupItems = Object.keys(items).filter(function (slug) {
        return true;
      }).reduce(function (res, key) {
        return res[key] = items[key], res;
      }, {});
      setGroupItemMenus(Object.keys(groupItems).filter(function (slug) {
        return true;
      }).map(function (key) {
        return {
          name: groupItems[key].type,
          title: groupItems[key].title,
          icon: groupItems[key].icon
        };
      }));
    }
  }, [performanceContext]);

  var onSetActiveGroups = function onSetActiveGroups(value) {
    setActiveGroups(value);
    var keys = Object.keys(categories),
        currentIndex = keys.indexOf(value),
        nextIndex = keys.length - 1 === currentIndex ? currentIndex : currentIndex + 1,
        //don't change to the next page on last page
    nextItem = keys[nextIndex];
    setNextPage(nextItem);
  };

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_4__["default"], props, /*#__PURE__*/React.createElement(_navigation_navigation__WEBPACK_IMPORTED_MODULE_6__["default"], {
    timerRef: timerRef,
    setCurrentMenu: onSetActiveGroups,
    currentMenu: activeGroups,
    loading: loading,
    menus: groupItemMenus,
    showItemNumber: true,
    showItemProgress: true
  }), /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-panel-wrapper"
  }, /*#__PURE__*/React.createElement(_dashboard_dashboard_panel__WEBPACK_IMPORTED_MODULE_5__["default"], {
    additionalClasses: "jnews-performance-wrap"
  }, /*#__PURE__*/React.createElement(_performance_performance_page_content__WEBPACK_IMPORTED_MODULE_7__["default"], {
    setCurrentMenu: onSetActiveGroups,
    activePage: categories[activeGroups],
    nextPage: nextPage,
    isLoading: isLoading,
    setIsLoading: setIsLoading,
    configs: performanceContext.configs
  })), isLoading && /*#__PURE__*/React.createElement("div", {
    className: "loading-overlay"
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformancePage);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/next-button.js":
/*!***************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/next-button.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



var NextButton = function NextButton(props) {
  var setCurrentMenu = props.setCurrentMenu,
      nextMenu = props.nextMenu,
      buttonTitle = props.buttonTitle,
      customFunction = props.customFunction,
      _props$changePage = props.changePage,
      changePage = _props$changePage === void 0 ? false : _props$changePage,
      _props$isLoading = props.isLoading,
      isLoading = _props$isLoading === void 0 ? false : _props$isLoading;

  var onButtonClicked = function onButtonClicked(e) {
    e.preventDefault();

    if ('function' === typeof customFunction) {
      customFunction();
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    if (changePage) {
      setCurrentMenu(nextMenu);
    }
  }, [changePage]);
  return /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: "#",
    onClick: function onClick(e) {
      onButtonClicked(e);
    }
  }, isLoading ? (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('saving...', '__text_domain__') : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)(buttonTitle, '__text_domain__')));
};

/* harmony default export */ __webpack_exports__["default"] = (NextButton);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-context.js":
/*!***********************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-context.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerformanceContext": function() { return /* binding */ PerformanceContext; },
/* harmony export */   "PerformanceContextProvider": function() { return /* binding */ PerformanceContextProvider; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var PerformanceContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
var PerformanceContextProvider = function PerformanceContextProvider(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      performanceContext = _useState2[0],
      setPerformanceContext = _useState2[1];

  return /*#__PURE__*/React.createElement(PerformanceContext.Provider, {
    value: {
      performanceContext: performanceContext,
      setPerformanceContext: setPerformanceContext
    }
  }, props.children);
};

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-easy-plugin.js":
/*!***************************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-easy-plugin.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PerformanceEasyPlugin = function PerformanceEasyPlugin(props) {
  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_5__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      nextPage = props.nextPage,
      performancePlugins = props.performancePlugins,
      setCurrentMenu = props.setCurrentMenu;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      changePage = _useState2[0],
      setChangePage = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      rendered = _useState4[0],
      setRendered = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({}),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      controls = _useState6[0],
      setControls = _useState6[1];

  var updateContext = function updateContext(key, options) {
    setPerformanceContext(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, key, options));
    });
  };

  var filterControls = function filterControls(items, type) {
    setControls(function (prevState) {
      if ('build' === type) {
        var optimized = {};
        var unOptimized = {};
        Object.keys(items).forEach(function (key) {
          var item = items[key];

          if (item.value) {
            optimized[key] = item;
          } else {
            unOptimized[key] = item;
          }
        });
        return {
          unOptimized: unOptimized,
          optimized: _objectSpread(_objectSpread({}, prevState.optimized), optimized)
        };
      }

      return {
        unOptimized: _objectSpread(_objectSpread({}, prevState.unOptimized), items),
        optimized: prevState.optimized
      };
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    //ToDo: need to optimize this, see you after gutenberg 
    //this use effect was made to synchonize value on advance mode "plugin options", "caching", "core web vital" with value on easy mode "Optimization"
    if (undefined === performanceContext.easyPluginOptions) {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_6__.easyPluginsOptions)({
        selectedPlugin: performancePlugins.optimization_plugin
      }).then(function (result) {
        updateContext('easyPluginOptions', result);
      });
    }

    if (undefined === performanceContext[performancePlugins.optimization_plugin]) {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_6__.getPerformanceOptions)({
        activepage: performancePlugins.optimization_plugin
      }).then(function (result) {
        updateContext(performancePlugins.optimization_plugin, result);
      });
    }

    if (undefined === performanceContext['caching-options']) {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_6__.getPerformanceOptions)({
        activepage: 'caching-options'
      }).then(function (result) {
        updateContext('caching-options', result);
      });
    }

    if (undefined === performanceContext['core-web-vital']) {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_6__.getPerformanceOptions)({
        activepage: 'core-web-vital'
      }).then(function (result) {
        updateContext('core-web-vital', result);
      });
    }

    if (!rendered && undefined !== performanceContext.easyPluginOptions && undefined !== performanceContext[performancePlugins.optimization_plugin] && undefined !== performanceContext['caching-options'] && undefined !== performanceContext['core-web-vital']) {
      setRendered(true); //make sure to render only once after all the required data fetched

      setIsLoading(false);
      /*
      * if there's is option on performanceContext optimization_plugin, that have "default" and "value" that not equal, set recommended_settings to false 
      * (why set it to false? because if there are any option that have "default" and "value" that not equal it mean it's not totaly optimize yet)
      */

      var pluginSettingFullOptimized = true;
      Object.keys(performanceContext[performancePlugins.optimization_plugin]).forEach(function (key) {
        var optimizationPluginOption = performanceContext[performancePlugins.optimization_plugin][key]; //use != not !== because default and value datatype not the same 

        if (optimizationPluginOption["default"] != optimizationPluginOption.value) {
          pluginSettingFullOptimized = false;
        }
      });
      performanceContext.easyPluginOptions.recommended_settings.value = pluginSettingFullOptimized;
      /*
      * if there's is option on performanceContext caching-options, that have "default" and "value" that not equal, set recommended_cache_settings to false 
      * (why set it to false? because if there are any option that have "default" and "value" that not equal it mean it's not totaly optimize yet)
      */

      var cachingFulloptimized = true;
      Object.keys(performanceContext['caching-options']).forEach(function (key) {
        var optimizationCachingOption = performanceContext['caching-options'][key]; //use != not !== because default and value datatype not the same 

        if (optimizationCachingOption["default"] != optimizationCachingOption.value) {
          cachingFulloptimized = false;
        }
      });
      performanceContext.easyPluginOptions.recommended_cache_settings.value = cachingFulloptimized;
      /*
      * if there's is option on performanceContext core-web-vital, that have "default" and "value" that not equal, set recommended_speed_settings to false 
      * (why set it to false? because if there are any option that have "default" and "value" that not equal it mean it's not totaly optimize yet)
      */

      var cwvFullOptimized = true;
      Object.keys(performanceContext['core-web-vital']).forEach(function (key) {
        var optimizationCWV = performanceContext['core-web-vital'][key]; //use != not !== because default and value datatype not the same 

        if (optimizationCWV["default"] != optimizationCWV.value) {
          cwvFullOptimized = false;
        }
      });
      performanceContext.easyPluginOptions.recommended_speed_settings.value = cwvFullOptimized;
      filterControls(performanceContext.easyPluginOptions, 'build');
    }
  }, [performanceContext, rendered]);

  var onNextButtonClicked = function onNextButtonClicked() {
    var pluginOptions = {};
    var unOptimized = controls.unOptimized;

    if (unOptimized.recommended_settings && unOptimized.recommended_settings.value) {
      Object.keys(performanceContext[performancePlugins.optimization_plugin]).forEach(function (key) {
        var option = performanceContext[performancePlugins.optimization_plugin][key];
        pluginOptions[key] = option;
        pluginOptions[key].value = option["default"];
      });
    }

    var cachingOptions = {};

    if (unOptimized.recommended_cache_settings && unOptimized.recommended_cache_settings.value) {
      Object.keys(performanceContext['caching-options']).forEach(function (key) {
        var option = performanceContext['caching-options'][key];
        cachingOptions[key] = option;
        cachingOptions[key].value = option["default"];
      });
    }

    var cwvOptions = {};

    if (unOptimized.recommended_speed_settings && unOptimized.recommended_speed_settings.value) {
      Object.keys(performanceContext['core-web-vital']).forEach(function (key) {
        var option = performanceContext['core-web-vital'][key];
        cwvOptions[key] = option;
        cwvOptions[key].value = option["default"];
      });
    }

    (0,_util_axios__WEBPACK_IMPORTED_MODULE_6__.updateEasyPluginOptions)({
      plugin: {
        key: performancePlugins.optimization_plugin,
        options: pluginOptions
      },
      caching: cachingOptions,
      cwv: cwvOptions
    }).then(function (result) {
      if (Object.keys(pluginOptions).length) {
        updateContext(performancePlugins.optimization_plugin, pluginOptions);
      }

      if (Object.keys(cachingOptions).length) {
        updateContext('caching-options', cachingOptions);
      }

      if (Object.keys(cwvOptions).length) {
        updateContext('core-web-vital', cwvOptions);
      }

      setChangePage(true);
    });
  };

  return isLoading ? /*#__PURE__*/React.createElement("div", null, "loading ...") : /*#__PURE__*/React.createElement("div", {
    className: "wizard-content-wrapper"
  }, controls.unOptimized && /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_7__["default"], {
    controls: controls.unOptimized,
    setControls: filterControls
  }), controls.optimized && Object.keys(controls.optimized).map(function (key) {
    var control = controls.optimized[key];
    return /*#__PURE__*/React.createElement("div", {
      key: key,
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "jnews-list-item-checked control-body"
    }, /*#__PURE__*/React.createElement("span", {
      className: "control-title"
    }, control.title), /*#__PURE__*/React.createElement("span", {
      className: "jnews-svg-wrapper"
    }, /*#__PURE__*/React.createElement("i", {
      className: "jnews-svg jnews-svg-check-circle-transparent"
    })))));
  }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_3__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: nextPage,
    buttonTitle: 'Next',
    customFunction: onNextButtonClicked,
    changePage: changePage
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceEasyPlugin);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-element.js":
/*!***********************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-element.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");






function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PerformanceElements = function PerformanceElements(props) {
  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_9__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_useState, 2),
      changePage = _useState2[0],
      setChangePage = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({}),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_3__["default"])(_useState3, 2),
      elements = _useState4[0],
      setElements = _useState4[1];

  var contentData = props.contentData,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading;

  var updateContext = function updateContext(elements) {
    setPerformanceContext(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, {
        elements: elements
      });
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(function () {
    if (undefined !== performanceContext.elements) {
      setIsLoading(false);
      setElements(performanceContext.elements);
    } else {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_8__.getJnewsElements)().then(function (elements) {
        updateContext(elements);
      });
    }
  }, [performanceContext]);

  var onFindRecommendationClicked = /*#__PURE__*/function () {
    var _ref = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().mark(function _callee(event) {
      var activePages, allActiveElement;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              event.preventDefault();
              activePages = {};

              if (!(undefined === performanceContext.imageLoad)) {
                _context.next = 7;
                break;
              }

              _context.next = 5;
              return (0,_util_axios__WEBPACK_IMPORTED_MODULE_8__.getActiveElements)().then(function (result) {
                activePages = result;
              });

            case 5:
              _context.next = 8;
              break;

            case 7:
              activePages = performanceContext.imageLoad;

            case 8:
              allActiveElement = [];
              Object.keys(activePages).forEach(function (key) {
                //get active elements on every published pages
                var activePage = activePages[key];

                if (activePage.elementor_data) {
                  //if page have elementor data
                  allActiveElement.push.apply(allActiveElement, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(elementorFindActiveElement(allActiveElement, activePage.elementor_data, [])));
                } else if (Object.keys(activePage.shortcode_array).length) {
                  //if page have shortocde
                  Object.keys(activePage.shortcode_array).forEach(function (key) {
                    !allActiveElement.includes(key) && allActiveElement.push(key);
                  });
                } else if (activePage.blocks.length) {
                  //if page have jnews gutenberg blocks
                  activePage.blocks.forEach(function (block) {
                    if (block.blockName && block.blockName.includes('jnews-gutenberg')) {
                      var blockName = block.blockName.replace('-gutenberg/block-', '_block_');
                      !allActiveElement.includes(blockName) && allActiveElement.push(blockName);
                    }
                  });
                }
              });
              setElements(function (prevState) {
                var recommendedElements = {};
                Object.keys(prevState).forEach(function (key) {
                  recommendedElements[key] = _objectSpread(_objectSpread({}, prevState[key]), {}, {
                    value: allActiveElement.includes(key.toLowerCase())
                  });
                });
                return recommendedElements;
              });

            case 11:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onFindRecommendationClicked(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var elementorFindActiveElement = function elementorFindActiveElement(allActiveElement, elements, list) {
    elements.forEach(function (widget) {
      if (widget.widgetType && !('section' === widget.elType && 'column' === widget.elType)) {
        var widgetType = widget.widgetType.replace('_elementor', '');
        !allActiveElement.includes(widgetType) && list.push(widgetType);
      }

      if (widget.elements) {
        elementorFindActiveElement(allActiveElement, widget.elements, list);
      }
    });
    return list;
  };

  var onNextButtonClicked = function onNextButtonClicked() {
    setIsLoading(true);
    (0,_util_axios__WEBPACK_IMPORTED_MODULE_8__.updateJNewsModules)({
      modules: Object.keys(elements).filter(function (key) {
        return elements[key].value && key;
      })
    }).then(function () {
      updateContext(elements);
      setChangePage(true);
      setIsLoading(false);
    });
  };

  return isLoading ? /*#__PURE__*/React.createElement("div", null, "loading ...") : /*#__PURE__*/React.createElement("div", {
    className: "wizard-content-wrapper"
  }, /*#__PURE__*/React.createElement("h3", null, contentData.title), /*#__PURE__*/React.createElement("button", {
    onClick: onFindRecommendationClicked
  }, " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__.__)('Find Recommendations', '__text_domain__')), /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_10__["default"], {
    controls: elements,
    setControls: setElements
  }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_6__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: nextPage,
    buttonTitle: 'Next',
    customFunction: onNextButtonClicked,
    changePage: changePage
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceElements);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-features-plugins.js":
/*!********************************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-features-plugins.js ***!
  \********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);





var PerformanceFeaturesPlugins = function PerformanceFeaturesPlugins(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      changePage = _useState2[0],
      setChangePage = _useState2[1];

  var contentData = props.contentData,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage;
  return /*#__PURE__*/React.createElement("div", {
    className: "wizard-content-wrapper"
  }, /*#__PURE__*/React.createElement("h3", null, contentData.title), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_2__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: nextPage,
    buttonTitle: 'Next',
    customFunction: function customFunction() {
      setChangePage(true);
    },
    changePage: changePage
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceFeaturesPlugins);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-image-load.js":
/*!**************************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-image-load.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PerformanceImageLoad = function PerformanceImageLoad(props) {
  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_7__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      changePage = _useState2[0],
      setChangePage = _useState2[1];

  var activePage = props.activePage,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      performancePlugins = props.performancePlugins;

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      nextButtonClicked = _useState4[0],
      setNextButtonClicked = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      processing = _useState6[0],
      setProcessing = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState7, 2),
      doUpdateTransient = _useState8[0],
      setDoUpdateTransient = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({}),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState9, 2),
      unfilteredControl = _useState10[0],
      setUnfilteredControl = _useState10[1];

  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({}),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState11, 2),
      controls = _useState12[0],
      setControls = _useState12[1];

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (undefined === performanceContext.imageLoad) {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.getPublishedPages)().then(function (result) {
        var performanceImageLoad = result.pages;
        var unCached = {};
        Object.keys(performanceImageLoad).forEach(function (key) {
          var page = performanceImageLoad[key];

          if (!page.report) {
            unCached[key] = page;
          }
        });
        setUnfilteredControl(performanceImageLoad);
        setProcessing({
          current: 0,
          total: Object.keys(unCached).length
        });
        gpsiTestRequest(unCached);
      });
    } else {
      filterControls(performanceContext.imageLoad);
    }
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (false === processing) {
      buildControl();
      setIsLoading(false);
      setPerformanceContext(function (prevState) {
        if (!nextButtonClicked) {
          return _objectSpread(_objectSpread({}, performanceContext), {}, {
            imageLoad: unfilteredControl
          });
        }

        delete prevState.imageLoad;
        return prevState;
      });

      if (doUpdateTransient) {
        var report = {};
        Object.keys(unfilteredControl).forEach(function (key) {
          var control = unfilteredControl[key];
          report[key] = {
            elementor_data: control.elementor_data,
            post_content: control.post_content,
            lcpLazyloaded: null !== control.report && control.report.lcpLazyloaded
          };
        });
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.updatePagespeedReportTransient)({
          report: report
        }).then(function () {
          if (nextButtonClicked) {
            setChangePage(true);
            setNextButtonClicked(false);
            setDoUpdateTransient(false);
          }
        });
      }
    }
  }, [processing, doUpdateTransient, unfilteredControl, nextButtonClicked]);

  var buildControl = function buildControl() {
    filterControls(Object.keys(unfilteredControl).map(function (key) {
      var page = unfilteredControl[key];
      page["default"] = page.report && page.report.lcpLazyloaded.score < 1 ? true : page.value;
      return page;
    }));
  };

  var gpsiTestRequest = function gpsiTestRequest(pages) {
    var processes = Object.keys(pages);

    if (processes.length > 0) {
      setProcessing(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, {
          current: prevState.current + 1
        });
      });
      var key = processes[0];

      if (undefined !== pages[key]) {
        setDoUpdateTransient(true);
        var page = pages[key]; //debug code
        // getPageSpeedReportTesting(page.permalink + '&key=' + performancePlugins.jnews_google_pagespeed_api_key).then(report => {
        //     delete pages[page.id]
        //     processes.shift()
        //     setUnfilteredControl(prevState=>{
        //         //update the lcplazyloaded report on the page
        //         return {...prevState, [page.id]: {...page, report: report.lighthouseResult ? {lcpLazyloaded: report.lighthouseResult.audits['lcp-lazy-loaded']} : null}}
        //     })
        //     gpsiTestRequest(pages)
        // }).catch(error=>{
        //     delete pages[page.id]
        //     processes.shift()
        //     setUnfilteredControl(prevState=>{
        //         //update the lcplazyloaded report on the page
        //         return {...prevState, [page.id]: {...page, report: null}}
        //     })
        //     gpsiTestRequest(pages)
        // })
        //production code

        (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.getPageSpeedReport)(page.permalink + '&key=' + performancePlugins.jnews_google_pagespeed_api_key).then(function (report) {
          delete pages[page.id];
          processes.shift();
          setUnfilteredControl(function (prevState) {
            //update the lcplazyloaded report on the page
            return _objectSpread(_objectSpread({}, prevState), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, page.id, _objectSpread(_objectSpread({}, page), {}, {
              report: report.lighthouseResult ? {
                lcpLazyloaded: report.lighthouseResult.audits['lcp-lazy-loaded']
              } : null
            })));
          });
          gpsiTestRequest(pages);
        })["catch"](function (error) {
          delete pages[page.id];
          processes.shift();
          setUnfilteredControl(function (prevState) {
            //update the lcplazyloaded report on the page
            return _objectSpread(_objectSpread({}, prevState), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, page.id, _objectSpread(_objectSpread({}, page), {}, {
              report: null
            })));
          });
          gpsiTestRequest(pages);
        });
      }
    } else {
      setProcessing(false);
    }
  };

  var findElementIdentifier = function findElementIdentifier(selector) {
    var separator = selector.indexOf(">") > -1 ? ">" : '>',
        classeses = selector.split(separator);
    var elementType = 'jnews-gutenberg',
        elementId = '';

    if (selector.indexOf('elementor') > -1) {
      elementType = 'elementor';
    } else if (selector.indexOf('shortcode') > -1) {
      elementType = 'shortcode';
    }

    classeses.forEach(function (itemClass) {
      if (itemClass.indexOf(elementType) > -1) {
        elementId = 'elementor' === elementType ? itemClass.trim().replace('div.' + elementType + '-', "") : itemClass.trim().replace('div.', "");
      }
    });
    return {
      type: elementType,
      id: elementId
    };
  };

  var onNextButtonClicked = function onNextButtonClicked() {
    var updatedControls = {};
    Object.keys(controls.lazyloaded).map(function (key) {
      var control = controls.lazyloaded[key];
      var post_content = false;
      var elementorData = false;
      var blocks = false;

      if (control.value) {
        //update element only if control value is true
        control.report['lcpLazyloaded'].details.items.map(function (lcpElement) {
          var elementIdentifier = findElementIdentifier(lcpElement.node.selector);

          if ('elementor' === elementIdentifier.type) {
            //elementor
            control.elementor_data.forEach(function (section, sectionIndex) {
              section.elements.forEach(function (column, columnIndex) {
                column.elements.forEach(function (item, itemIndex) {
                  if (elementIdentifier.id === item.id) {
                    elementorData = control.elementor_data;
                    elementorData[sectionIndex].elements[columnIndex].elements[itemIndex].settings.force_normal_image_load = "yes";
                  }
                });
              });
            });
          } else if ('shortcode' === elementIdentifier.type) {
            //wp bakery & jnews shortcode generator                   
            Object.keys(control.shortcode_array).forEach(function (key) {
              var controlShortcode = control.shortcode_array[key];

              if (elementIdentifier.id === controlShortcode.atts.shortcode_id && !controlShortcode.atts.force_normal_image_load) {
                post_content = control.post_content.replace('shortcode_id="' + elementIdentifier.id + '"', 'shortcode_id="' + elementIdentifier.id + '"' + ' force_normal_image_load="true"');
              }
            });
          } else if ('jnews-gutenberg' === elementIdentifier.type) {
            //jnews gutenberg
            control.blocks.every(function (block, index) {
              //find the first matching blocks
              if (elementIdentifier.id === block.blockName) {
                blocks = control.blocks;
                blocks[index].attrs.force_normal_image_load = true;
                return false;
              }
            });
          }
        });

        if (elementorData || post_content || blocks) {
          updatedControls[key] = {
            elementor_data: elementorData,
            post_content: post_content,
            blocks: blocks
          };
        }
      }
    });

    if (Object.keys(updatedControls).length) {
      //Update page content
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.updatePagesImageLoad)({
        pages: updatedControls
      }).then(function () {
        setIsLoading(true);

        var untestedPages = _objectSpread(_objectSpread(_objectSpread({}, controls.lazyloaded), controls.normalloaded), controls.testFailed);

        setProcessing({
          current: 0,
          total: Object.keys(untestedPages).length
        });
        gpsiTestRequest(untestedPages);
        setNextButtonClicked(true);
      });
    } else {
      //Change to the next page if next button clicked but no element to be normal loaded 
      setChangePage(true);
    }
  };

  var onFindRecommendationClicked = function onFindRecommendationClicked() {
    var recommendedOptions = {};
    Object.keys(controls.lazyloaded).map(function (key) {
      recommendedOptions[key] = _objectSpread(_objectSpread({}, controls.lazyloaded[key]), {}, {
        value: controls.lazyloaded[key]["default"]
      });
    });
    filterControls(recommendedOptions, 'find-recommendation');
  };

  var onRefreshPageClicked = function onRefreshPageClicked() {
    setIsLoading(true);

    var untestedPages = _objectSpread(_objectSpread(_objectSpread({}, controls.lazyloaded), controls.normalloaded), controls.testFailed);

    setProcessing({
      current: 0,
      total: Object.keys(untestedPages).length
    });
    gpsiTestRequest(untestedPages);
  };

  var filterControls = function filterControls(items, type) {
    setControls(function (prevState) {
      if ('find-recommendation' === type) {
        return {
          lazyloaded: _objectSpread(_objectSpread({}, prevState.lazyloaded), items),
          normalloaded: prevState.normalloaded,
          testFailed: prevState.testFailed
        };
      }

      var updatedLazyloaded = {};
      var updatedNormalloaded = {};
      var updatedTestFailed = {};
      Object.keys(items).forEach(function (key) {
        if (!items[key].report || !items[key].report.lcpLazyloaded) {
          updatedTestFailed[items[key].id] = items[key];
        } else if (items[key].report && null !== items[key].report.lcpLazyloaded.score && 1 > items[key].report.lcpLazyloaded.score) {
          updatedLazyloaded[items[key].id] = items[key];
        } else {
          updatedNormalloaded[items[key].id] = items[key];
        }
      });
      return {
        lazyloaded: updatedLazyloaded,
        normalloaded: _objectSpread(_objectSpread({}, prevState.normalloaded), updatedNormalloaded),
        testFailed: _objectSpread(_objectSpread({}, prevState.testFailed), updatedTestFailed)
      };
    });
  };

  return isLoading ? /*#__PURE__*/React.createElement("div", null, "loading... ", processing.total && "(".concat(processing.current, "/").concat(processing.total, ")")) : /*#__PURE__*/React.createElement("div", {
    className: "wizard-content-wrapper"
  }, /*#__PURE__*/React.createElement("h3", null, activePage.title), /*#__PURE__*/React.createElement("div", null, activePage.description), /*#__PURE__*/React.createElement("button", {
    onClick: onFindRecommendationClicked
  }, " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Find Recommendations', '__text_domain__')), /*#__PURE__*/React.createElement("button", {
    onClick: onRefreshPageClicked
  }, " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Refresh Page', '__text_domain__')), controls.lazyloaded && /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_6__["default"], {
    controls: controls.lazyloaded,
    setControls: filterControls
  }), controls.normalloaded && Object.keys(controls.normalloaded).map(function (key) {
    var page = controls.normalloaded[key];
    return /*#__PURE__*/React.createElement("div", {
      key: key,
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "jnews-list-item-checked control-body"
    }, /*#__PURE__*/React.createElement("span", {
      className: "control-title"
    }, page.title), /*#__PURE__*/React.createElement("span", {
      className: "jnews-svg-wrapper"
    }, /*#__PURE__*/React.createElement("i", {
      className: "jnews-svg jnews-svg-check-circle-transparent"
    })))));
  }), controls.testFailed && Object.keys(controls.testFailed).map(function (key) {
    var page = controls.testFailed[key];
    return /*#__PURE__*/React.createElement("div", {
      key: key,
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "control-wrapper control-checkbox"
    }, /*#__PURE__*/React.createElement("div", {
      className: "jnews-list-item-checked control-body"
    }, /*#__PURE__*/React.createElement("span", {
      className: "control-title"
    }, page.title), /*#__PURE__*/React.createElement("span", {
      className: "jnews-svg-wrapper"
    }, /*#__PURE__*/React.createElement("i", {
      className: "jnews-svg jnews-svg-circle-xmark"
    })))));
  }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_3__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: nextPage,
    buttonTitle: 'Next',
    customFunction: onNextButtonClicked,
    changePage: changePage
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceImageLoad);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-mode.js":
/*!********************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-mode.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PerformanceMode = function PerformanceMode(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({}),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      controls = _useState2[0],
      setControls = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      changePage = _useState4[0],
      setChangePage = _useState4[1];

  var setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      setLetsOptimize = props.setLetsOptimize;

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_6__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var updateContext = function updateContext(mode) {
    setPerformanceContext(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, {
        mode: mode
      });
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    if (undefined !== performanceContext.mode) {
      setIsLoading(false);
      setControls(performanceContext.mode);
    } else {
      setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.getPerformanceMode)().then(function (mode) {
        updateContext(mode);
      });
    }
  }, [performanceContext]);

  var onNextButtonClicked = function onNextButtonClicked() {
    var selectedMode = controls.mode.value;
    (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.updatePerformanceMode)({
      mode: selectedMode
    }).then(function () {
      updateContext(controls);
      setChangePage(true);
    });
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-performance-mode-wrapper"
  }, /*#__PURE__*/React.createElement("div", {
    className: "jnews-performance-mode-image-wrapper"
  }, /*#__PURE__*/React.createElement("img", {
    src: "//assets.jnews.io/img/tf/thankyou.png",
    loading: "lazy"
  })), /*#__PURE__*/React.createElement("div", {
    className: "jnews-performance-mode-options"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "jnews-performance-mode-title"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('JNews Performance Wizard', '__text_domain__')), /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_7__["default"], {
    controls: controls,
    setControls: setControls
  }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: 'optimization-plugin',
    buttonTitle: 'Start Optimization',
    customFunction: onNextButtonClicked,
    changePage: changePage
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceMode);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-optimization-plugin.js":
/*!***********************************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-optimization-plugin.js ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../config */ "./src/jnews/src/config.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _plugin_plugin_process__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../plugin/plugin-process */ "./src/jnews/src/content/page/plugin/plugin-process.js");
/* harmony import */ var _modal_error__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../modal-error */ "./src/jnews/src/content/modal-error.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");




function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}











var PerformanceOptimizationPlugin = function PerformanceOptimizationPlugin(props) {
  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_11__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var contentData = props.contentData,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      performancePlugins = props.performancePlugins;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(true),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      processing = _useState2[0],
      setProcessing = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState3, 2),
      changePage = _useState4[0],
      setChangePage = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState5, 2),
      openModalError = _useState6[0],
      setOpenModalError = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
    header: {},
    footer: {},
    modalType: '',
    closablePopup: true,
    refreshContent: false
  }),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState7, 2),
      popupData = _useState8[0],
      setPopupData = _useState8[1];

  var errorPopUpData = {
    "header": {
      "modalType": "warning",
      "icon": "warning",
      "showCloseButton": false,
      "headerText": "Failed!"
    },
    "footer": {
      "footerType": "dashboard-action"
    },
    "modalType": ["popup-warning", "error-message"],
    "closablePopup": true,
    "refreshContent": false
  };

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState9, 2),
      plugins = _useState10[0],
      setPlugins = _useState10[1];

  var validated = _config__WEBPACK_IMPORTED_MODULE_5__.licenseData.validated;

  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState11, 2),
      listProcess = _useState12[0],
      setListProcess = _useState12[1];

  var _useState13 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      _useState14 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState13, 2),
      inAction = _useState14[0],
      setInAction = _useState14[1];

  var _useState15 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({}),
      _useState16 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState15, 2),
      controls = _useState16[0],
      setControls = _useState16[1];

  var onNextButtonClicked = function onNextButtonClicked() {
    if (!inAction) {
      var processes = [controls.optimization_plugin.value];

      if (controls.enable_wp_supercache.value && 'wp-rocket' !== controls.optimization_plugin.value) {
        processes.push('wp-super-cache');
      }

      var _plugins = {};
      Object.keys(controls).forEach(function (key) {
        _plugins[key] = controls[key].value;
      });
      setPerformanceContext(function (prevState) {
        return _objectSpread(_objectSpread({}, prevState), {}, {
          optimizationPlugins: _objectSpread(_objectSpread({}, prevState.optimizationPlugins), {}, {
            controls: controls
          }),
          configs: _plugins
        });
      });
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.updateOptimizationPlugins)({
        plugin: _plugins
      });
      setInAction(true);
      setIsLoading(true);
      setProcessing({
        current: 0,
        total: processes.length
      });
      setListProcess(processes);
    }
  };

  var onActionError = function onActionError(message, params) {
    setTimeout(function () {
      setInAction(false);
    }, 1000);

    if ('' !== message) {
      (0,_plugin_plugin_process__WEBPACK_IMPORTED_MODULE_8__.popupErrorHandler)(message, _objectSpread({
        setPopupData: setPopupData,
        setOpenModalError: setOpenModalError,
        popupData: errorPopUpData
      }, params));
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(function () {
    if (!inAction) {
      if (undefined !== performanceContext.optimizationPlugins) {
        var options = performanceContext.optimizationPlugins;
        setIsLoading(false);
        setPlugins(options.validated_plugins);
        setControls(options.controls);
      } else {
        setIsLoading(true);
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.getOptimizationPluginsControls)({
          performancePlugins: performancePlugins
        }).then(function (result) {
          setPerformanceContext(function (prevState) {
            return _objectSpread(_objectSpread({}, prevState), {}, {
              optimizationPlugins: result
            });
          });
        });
      }
    }
  }, [performanceContext]);

  var onActionNotice = function onActionNotice(msg) {
    console.log(msg);
  };

  var runManagePlugin = function runManagePlugin(plugin_data, params) {
    // Params
    var doing = params.doing;
    var onActionNotice = params.onActionNotice,
        setListProcess = params.setListProcess;
    (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.managePlugin)({
      from: 'react',
      plugin: plugin_data,
      doing: doing
    }).then(function (result) {
      if (result) {
        setTimeout(function () {
          if ('install' === doing) {
            params.doing = 'activate';
            (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.getPluginFile)({
              plugin: plugin_data
            }).then(function (result) {
              runManagePlugin(result, params);
            });
          } else {
            if (setListProcess) {
              setListProcess(function (prevState) {
                if (prevState.indexOf(plugin_data.slug) > -1) {
                  prevState.splice(prevState.indexOf(plugin_data.slug), 1);
                  prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
                } else {
                  prevState.push(plugin_data.slug);
                  prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
                }

                return prevState;
              });
            }

            onActionNotice('');
          }
        }, 1000);
      } else {
        onActionNotice('failed');
        setTimeout(function () {
          onActionNotice(false);
        }, 1000);
      }
    })["catch"](function (error) {
      var message = false;

      if (error) {
        message = error.message;
      }

      onActionError(message, params);
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(function () {
    if (inAction) {
      if (listProcess.length > 0) {
        var key = listProcess[0];

        if (undefined !== plugins[key]) {
          if ('nothing' !== plugins[key].doing) {
            doPluginProcess(plugins[key]);
          } else {
            setListProcess(function (prevState) {
              if (prevState.indexOf(key) > -1) {
                prevState.splice(prevState.indexOf(key), 1);
                prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
              } else {
                prevState.push(key);
                prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
              }

              return prevState;
            });
          }
        } else {
          setInAction(false);
        }
      } else {
        setChangePage(true);
        setIsLoading(false);
        setInAction(false);
      }
    }
  }, [inAction, listProcess]);

  var doPluginProcess = function doPluginProcess(plugin) {
    setProcessing(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, {
        current: prevState.current + 1
      });
    });
    var slug = plugin.slug,
        name = plugin.name,
        version = plugin.version,
        file_path = plugin.file_path,
        refresh = plugin.refresh,
        source = plugin.source,
        doing = plugin.doing;
    var params = {
      doing: doing,
      plugins: plugins,
      setListProcess: setListProcess,
      onActionNotice: onActionNotice
    };

    if (validated) {
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.checkPluginRemote)({
        source: source,
        slug: slug
      }).then(function (result) {
        var plugin_data = {};

        if (result) {
          plugin_data = {
            slug: slug,
            name: name,
            version: version,
            file: file_path,
            refresh: refresh,
            type: result
          };
          runManagePlugin(plugin_data, params);
        } else {
          onActionError('');
        }
      });
    } else {
      onActionError((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Please activate your copy of JNews', '__text_domain__'));
    }
  };

  return isLoading ? /*#__PURE__*/React.createElement("div", null, "loading ... ", processing.total && "(".concat(processing.current, "/").concat(processing.total, ")")) : /*#__PURE__*/React.createElement("div", {
    className: "welcome-container"
  }, /*#__PURE__*/React.createElement("h3", null, contentData.title), /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_10__["default"], {
    controls: controls,
    setControls: setControls
  }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_4__["default"], {
    setCurrentMenu: setCurrentMenu,
    nextMenu: nextPage,
    buttonTitle: 'Next',
    customFunction: onNextButtonClicked,
    changePage: changePage
  }), /*#__PURE__*/React.createElement(_modal_error__WEBPACK_IMPORTED_MODULE_9__["default"], {
    openModalError: openModalError,
    setOpenModalError: setOpenModalError,
    popupData: popupData
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceOptimizationPlugin);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-options.js":
/*!***********************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-options.js ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _next_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./next-button */ "./src/jnews/src/content/page/performance/next-button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _control_controls__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../control/controls */ "./src/jnews/src/control/controls.js");
/* harmony import */ var _performance_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./performance-context */ "./src/jnews/src/content/page/performance/performance-context.js");





function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PerformanceOptions = function PerformanceOptions(props) {
  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_performance_context__WEBPACK_IMPORTED_MODULE_9__.PerformanceContext),
      performanceContext = _useContext.performanceContext,
      setPerformanceContext = _useContext.setPerformanceContext;

  var setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      activePage = props.activePage;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState, 2),
      controls = _useState2[0],
      setControls = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState3, 2),
      changePage = _useState4[0],
      setChangePage = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_2__["default"])(_useState5, 2),
      isError = _useState6[0],
      setIsError = _useState6[1];

  var updateContext = function updateContext(options) {
    setPerformanceContext(function (prevState) {
      return _objectSpread(_objectSpread({}, prevState), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])({}, activePage, options));
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(function () {
    setChangePage(false); //set change page to false every component render, to prevent page change directly

    if (undefined !== performanceContext[activePage]) {
      if (!undefined === performanceContext[activePage].error) {
        setIsError(true);
        setCurrentMenu("mode");
      } else {
        setControls(performanceContext[activePage]); //ToDo replace setValues use this instead

        setIsLoading(false);
      }
    } else {
      !isLoading && setIsLoading(true);
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.getPerformanceOptions)({
        activepage: activePage
      }).then(function (result) {
        updateContext(result);
      });
    }
  }, [activePage, performanceContext]); //Rerender this component every activePage changes

  var onFindRecommendationClicked = /*#__PURE__*/function () {
    var _ref = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default().mark(function _callee(event) {
      var recommendedOptions;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_3___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              event.preventDefault();
              recommendedOptions = {};
              Object.keys(controls).map(function (key) {
                recommendedOptions[key] = _objectSpread(_objectSpread({}, controls[key]), {}, {
                  value: controls[key]["default"]
                });
              });
              setControls(recommendedOptions);

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onFindRecommendationClicked(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  var onNextButtonClicked = function onNextButtonClicked() {
    updateContext(controls);
    (0,_util_axios__WEBPACK_IMPORTED_MODULE_7__.updatePerformanceOptions)({
      plugin: activePage,
      options: controls
    }).then(function () {
      setChangePage(true); //todo need to change this to true
    });
  };

  if (isLoading) {
    return /*#__PURE__*/React.createElement("div", null, "loading...");
  } else {
    return !isError && /*#__PURE__*/React.createElement("div", {
      className: "options-wrapper"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onFindRecommendationClicked
    }, " ", (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__.__)("Find Recommendations", "__text_domain__")), /*#__PURE__*/React.createElement(_control_controls__WEBPACK_IMPORTED_MODULE_8__["default"], {
      controls: controls,
      setControls: setControls
    }), /*#__PURE__*/React.createElement(_next_button__WEBPACK_IMPORTED_MODULE_5__["default"], {
      setCurrentMenu: setCurrentMenu,
      nextMenu: nextPage,
      buttonTitle: "Next",
      customFunction: onNextButtonClicked,
      changePage: changePage
    }));
  }
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceOptions);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-page-content.js":
/*!****************************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-page-content.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _performance_optimization_plugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./performance-optimization-plugin */ "./src/jnews/src/content/page/performance/performance-optimization-plugin.js");
/* harmony import */ var _performance_image_load__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./performance-image-load */ "./src/jnews/src/content/page/performance/performance-image-load.js");
/* harmony import */ var _performance_features_plugins__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./performance-features-plugins */ "./src/jnews/src/content/page/performance/performance-features-plugins.js");
/* harmony import */ var _performance_element__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./performance-element */ "./src/jnews/src/content/page/performance/performance-element.js");
/* harmony import */ var _performance_server__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./performance-server */ "./src/jnews/src/content/page/performance/performance-server.js");
/* harmony import */ var _performance_options__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./performance-options */ "./src/jnews/src/content/page/performance/performance-options.js");
/* harmony import */ var _performance_mode__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./performance-mode */ "./src/jnews/src/content/page/performance/performance-mode.js");
/* harmony import */ var _performance_easy_plugin__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./performance-easy-plugin */ "./src/jnews/src/content/page/performance/performance-easy-plugin.js");










var ContentSwitch = function ContentSwitch(props) {
  var activePage = props.activePage,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      configs = props.configs;

  switch (activePage.type) {
    case 'mode':
      return /*#__PURE__*/React.createElement(_performance_mode__WEBPACK_IMPORTED_MODULE_7__["default"], {
        contentData: activePage,
        setCurrentMenu: setCurrentMenu,
        nextPage: nextPage,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        performancePlugins: configs
      });
      break;

    case 'optimization-plugin':
      return /*#__PURE__*/React.createElement(_performance_optimization_plugin__WEBPACK_IMPORTED_MODULE_1__["default"], {
        contentData: activePage,
        setCurrentMenu: setCurrentMenu,
        nextPage: nextPage,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        performancePlugins: configs
      });
      break;

    case 'easy-plugin-options':
      return /*#__PURE__*/React.createElement(_performance_easy_plugin__WEBPACK_IMPORTED_MODULE_8__["default"], {
        setCurrentMenu: setCurrentMenu,
        nextPage: nextPage,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        performancePlugins: configs
      });
      break;

    case 'plugin-options':
      return /*#__PURE__*/React.createElement(_performance_options__WEBPACK_IMPORTED_MODULE_6__["default"], {
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        nextPage: nextPage,
        setIsLoading: setIsLoading,
        activePage: configs.optimization_plugin
      });
      break;

    case 'caching-options':
      return /*#__PURE__*/React.createElement(_performance_options__WEBPACK_IMPORTED_MODULE_6__["default"], {
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        nextPage: nextPage,
        setIsLoading: setIsLoading,
        activePage: activePage.type
      });
      break;

    case 'core-web-vital':
      return /*#__PURE__*/React.createElement(_performance_options__WEBPACK_IMPORTED_MODULE_6__["default"], {
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        nextPage: nextPage,
        setIsLoading: setIsLoading,
        activePage: activePage.type
      });
      break;

    case 'page-optimization':
      return /*#__PURE__*/React.createElement(_performance_image_load__WEBPACK_IMPORTED_MODULE_2__["default"], {
        activePage: activePage,
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        nextPage: nextPage,
        performancePlugins: configs
      });
      break;

    case 'feature-and-plugins':
      return /*#__PURE__*/React.createElement(_performance_features_plugins__WEBPACK_IMPORTED_MODULE_3__["default"], {
        contentData: activePage,
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        nextPage: nextPage
      });
      break;

    case 'elements':
      return /*#__PURE__*/React.createElement(_performance_element__WEBPACK_IMPORTED_MODULE_4__["default"], {
        contentData: activePage,
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        setIsLoading: setIsLoading,
        nextPage: nextPage
      });
      break;

    case 'server':
      return /*#__PURE__*/React.createElement(_performance_server__WEBPACK_IMPORTED_MODULE_5__["default"], {
        contentData: activePage,
        setCurrentMenu: setCurrentMenu,
        isLoading: isLoading,
        nextPage: nextPage
      });
      break;
  }
};

var PerformancePageContent = function PerformancePageContent(props) {
  var activePage = props.activePage,
      setCurrentMenu = props.setCurrentMenu,
      nextPage = props.nextPage,
      isLoading = props.isLoading,
      setIsLoading = props.setIsLoading,
      configs = props.configs;
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, /*#__PURE__*/React.createElement(ContentSwitch, {
    activePage: activePage,
    setCurrentMenu: setCurrentMenu,
    nextPage: nextPage,
    isLoading: isLoading,
    setIsLoading: setIsLoading,
    configs: configs
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformancePageContent);

/***/ }),

/***/ "./src/jnews/src/content/page/performance/performance-server.js":
/*!**********************************************************************!*\
  !*** ./src/jnews/src/content/page/performance/performance-server.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);


var PerformanceServer = function PerformanceServer(props) {
  var contentData = props.contentData;
  return /*#__PURE__*/React.createElement("div", {
    className: "welcome-container"
  }, /*#__PURE__*/React.createElement("h3", null, contentData.title), /*#__PURE__*/React.createElement("div", {
    className: "dashboard-button-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    className: "dashboard-button",
    href: "#",
    "data-key": "plugin-options"
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Let\'s Optimize', '__text_domain__'))));
};

/* harmony default export */ __webpack_exports__["default"] = (PerformanceServer);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/install-plugin-content.js":
/*!*********************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/install-plugin-content.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../config */ "./src/jnews/src/config.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _plugin_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plugin-item */ "./src/jnews/src/content/page/plugin/plugin-item.js");
/* harmony import */ var _plugins__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./plugins */ "./src/jnews/src/content/page/plugin/plugins.js");
/* harmony import */ var _modal_error__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modal-error */ "./src/jnews/src/content/modal-error.js");
/* harmony import */ var _plugin_process__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./plugin-process */ "./src/jnews/src/content/page/plugin/plugin-process.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}









var filterPlugins = function filterPlugins(_ref) {
  var plugins = _ref.plugins,
      activeCategories = _ref.activeCategories,
      activeGroups = _ref.activeGroups,
      searchFilter = _ref.searchFilter;
  return plugins ? Object.keys(plugins).filter(function (item) {
    if (!activeCategories.includes('all') && !activeCategories.find(function (data) {
      return plugins[item].group.includes(data);
    })) {
      return false;
    }

    if (activeGroups.includes('installed') && !plugins[item].installed) {
      return false;
    }

    if (activeGroups.includes('activated') && !plugins[item].activated) {
      return false;
    }

    if (activeGroups.includes('deactivated') && plugins[item].activated) {
      return false;
    }

    if (activeGroups.includes('require-update') && !plugins[item].require_update) {
      return false;
    }

    if (searchFilter) {
      if (!plugins[item].name.toLowerCase().includes(searchFilter.toLowerCase())) {
        return false;
      }
    }

    return true;
  }).reduce(function (res, key) {
    return res[key] = plugins[key], res;
  }, {}) : {};
};

var InstallPluginContent = function InstallPluginContent(props) {
  var plugins = props.plugins,
      searchFilter = props.searchFilter,
      activeCategories = props.activeCategories,
      activeGroups = props.activeGroups,
      loading = props.loading,
      localLoading = props.localLoading,
      actionNotice = props.actionNotice,
      selectedPlugin = props.selectedPlugin,
      progressBar = props.progressBar,
      openModalError = props.openModalError,
      popupData = props.popupData,
      inAction = props.inAction;
  var setPlugins = props.setPlugins,
      setCategories = props.setCategories,
      onProcess = props.onProcess,
      onLocalProcess = props.onLocalProcess,
      onActionNotice = props.onActionNotice,
      setSelectedPlugin = props.setSelectedPlugin,
      setProgressBar = props.setProgressBar,
      setOpenModalError = props.setOpenModalError,
      setPopupData = props.setPopupData,
      setInAction = props.setInAction;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(filterPlugins({
    plugins: plugins,
    activeCategories: activeCategories,
    activeGroups: activeGroups,
    searchFilter: searchFilter
  })),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      filteredPlugins = _useState2[0],
      setFilteredPlugins = _useState2[1];

  var onLoadPlugins = function onLoadPlugins(data) {
    data = JSON.parse(JSON.stringify(data).replace(/__theme_url__/gim, _config__WEBPACK_IMPORTED_MODULE_3__.themeURL));
    data = JSON.parse(JSON.stringify(data).replace(/__admin_url__/gim, _config__WEBPACK_IMPORTED_MODULE_3__.adminURL));
    return data;
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    (0,_plugin_process__WEBPACK_IMPORTED_MODULE_8__.refreshPlugin)(false, _objectSpread(_objectSpread({}, {
      onProcess: onProcess,
      onLocalProcess: onLocalProcess,
      setPlugins: setPlugins,
      onLoadPlugins: onLoadPlugins,
      setCategories: setCategories,
      getPlugins: _util_axios__WEBPACK_IMPORTED_MODULE_4__.getPlugins
    }), {
      plugins: plugins
    }));
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    if ('undefined' === typeof plugins['coming-soon-1']) {
      setFilteredPlugins(filterPlugins({
        plugins: plugins,
        activeCategories: activeCategories,
        activeGroups: activeGroups,
        searchFilter: searchFilter
      }));
    }
  }, [plugins, activeCategories, activeGroups, searchFilter]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement(_plugins__WEBPACK_IMPORTED_MODULE_6__["default"], null, Object.keys(filteredPlugins).map(function (key) {
    return /*#__PURE__*/React.createElement(_plugin_item__WEBPACK_IMPORTED_MODULE_5__["default"], {
      setPlugins: setPlugins,
      onProcess: onProcess,
      onLocalProcess: onLocalProcess,
      setProgressBar: setProgressBar,
      onActionNotice: onActionNotice,
      setSelectedPlugin: setSelectedPlugin,
      setPopupData: setPopupData,
      setOpenModalError: setOpenModalError,
      setInAction: setInAction,
      setCategories: setCategories,
      data: filteredPlugins[key],
      plugins: plugins,
      loading: loading,
      localLoading: localLoading,
      progressBar: progressBar,
      actionNotice: actionNotice,
      selectedPlugin: selectedPlugin,
      popupData: popupData,
      inAction: inAction
    });
  })), /*#__PURE__*/React.createElement(_modal_error__WEBPACK_IMPORTED_MODULE_7__["default"], {
    openModalError: openModalError,
    setOpenModalError: setOpenModalError,
    popupData: popupData
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (InstallPluginContent);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugin-bulk-action.js":
/*!*****************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugin-bulk-action.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _plugin_process__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plugin-process */ "./src/jnews/src/content/page/plugin/plugin-process.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}






var PluginBulkActionItems = function PluginBulkActionItems(props) {
  var bulkAction = props.bulkAction,
      setOpenBulkActionList = props.setOpenBulkActionList,
      selectedBulkAction = props.selectedBulkAction,
      setSelectedBulkAction = props.setSelectedBulkAction,
      loading = props.loading;
  /**
   * Bulk Action Item On Click
   *
   * @param {Event} event
   * @param {int} key
   */

  var bulkActionItemOnClick = function bulkActionItemOnClick(event, name) {
    event.preventDefault();

    if (!loading) {
      setSelectedBulkAction(name);
      setOpenBulkActionList(false);
    }
  };

  return Object.keys(bulkAction).map(function (key) {
    return /*#__PURE__*/React.createElement("li", {
      onClick: function onClick(e) {
        return bulkActionItemOnClick(e, key);
      },
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
        active: key === selectedBulkAction
      }),
      "data-key": key
    }, bulkAction[key]);
  });
};

var PluginBulkAction = function PluginBulkAction(props) {
  var setOpenBulkActionList = props.setOpenBulkActionList,
      setSelectedBulkAction = props.setSelectedBulkAction,
      onProcess = props.onProcess,
      onLocalProcess = props.onLocalProcess,
      setSelectedPlugin = props.setSelectedPlugin,
      setInAction = props.setInAction;
  var pluginData = props.pluginData,
      openBulkActionList = props.openBulkActionList,
      loading = props.loading,
      localLoading = props.localLoading,
      selectedBulkAction = props.selectedBulkAction,
      selectedPlugin = props.selectedPlugin,
      inAction = props.inAction;
  var bulkAction = pluginData.bulkAction;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      listProcess = _useState2[0],
      setListProcess = _useState2[1]; // const [inAction, setInAction] = useState(false)


  var pluginBulkActionWrapperClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('plugin-bulk-action-wrapper', {
    disabled: inAction || loading || localLoading
  });
  var bulkActionListWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
  var bulkActionListWrapperClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('bulk-action-list-wrapper', {
    active: openBulkActionList
  });
  /**
   * clickBulkActionListHandler
   *
   * @param {Event} event
   */

  var clickBulkActionListHandler = function clickBulkActionListHandler(event) {
    event.preventDefault();
    setOpenBulkActionList(true);
  };

  var items = _objectSpread({
    "default": (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Bulk Action', '__text_domain__')
  }, bulkAction);

  var onBulkAction = function onBulkAction(event) {
    event.preventDefault();

    if (!inAction) {
      setListProcess(selectedPlugin);
      setInAction(true);
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    if (inAction) {
      if (listProcess.length > 0) {
        (0,_plugin_process__WEBPACK_IMPORTED_MODULE_5__.onBulkManagePlugin)(listProcess, _objectSpread(_objectSpread({}, props), {}, {
          selectedBulkAction: selectedBulkAction,
          setListProcess: setListProcess,
          setInAction: setInAction,
          inAction: inAction
        }));
      } else {
        setSelectedPlugin([]);
        setInAction(false);
      }
    } else {
      onProcess(false);
      onLocalProcess(false);
    }
  }, [inAction, listProcess]);
  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    function handleClickBulkActionListOutside(event) {
      if (bulkActionListWrapperRef.current && !bulkActionListWrapperRef.current.contains(event.target)) {
        setOpenBulkActionList(false);
      }
    }

    document.addEventListener('mousedown', handleClickBulkActionListOutside);
    return function () {
      document.removeEventListener('mousedown', handleClickBulkActionListOutside);
    };
  }, [bulkActionListWrapperRef]);
  return /*#__PURE__*/React.createElement("div", {
    className: pluginBulkActionWrapperClasses
  }, /*#__PURE__*/React.createElement("div", {
    className: bulkActionListWrapperClasses,
    ref: bulkActionListWrapperRef
  }, /*#__PURE__*/React.createElement("div", {
    className: "bulk-action-list-wrapper-inner"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: 'plugin-bulk-action',
    onClick: clickBulkActionListHandler
  }, selectedBulkAction && items[selectedBulkAction] ? items[selectedBulkAction] : (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Bulk Action', '__text_domain__')), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement(PluginBulkActionItems, {
    bulkAction: items,
    selectedBulkAction: selectedBulkAction,
    setSelectedBulkAction: setSelectedBulkAction,
    setOpenBulkActionList: setOpenBulkActionList,
    loading: loading
  })))), /*#__PURE__*/React.createElement("div", {
    className: "bulk-action-action-wrapper"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "dashboard-button",
    onClick: onBulkAction
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Apply', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
    className: "overlay"
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (PluginBulkAction);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugin-categories.js":
/*!****************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugin-categories.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _util_current_url__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../util/current-url */ "./src/jnews/src/util/current-url.js");








var PluginCategories = function PluginCategories(props) {
  var categories = props.categories,
      setActiveCategories = props.setActiveCategories,
      activeCategories = props.activeCategories;

  var groupItemsOnClick = function groupItemsOnClick(event) {
    event.preventDefault();

    if (!props.loading) {
      var ele = umbrellajs__WEBPACK_IMPORTED_MODULE_5___default()(event.currentTarget);
      var key = ele.data('key');
      setActiveCategories(function (prevState) {
        var indexAll = prevState.indexOf('all');

        if ('all' === key && 0 > indexAll) {
          prevState = [key];
          return prevState;
        }

        if (prevState.indexOf(key) > -1) {
          prevState.splice(prevState.indexOf(key), 1);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
        } else {
          prevState.push(key);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
        }

        if (1 < prevState.length && 0 <= indexAll) {
          prevState.splice(indexAll, 1);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
        }

        if (!prevState.length) {
          prevState = ['all'];
        }

        return prevState;
      });
    }
  };

  var categoryItems = Object.keys(categories).filter(function (slug) {
    if ('activated' === slug || 'deactivated' === slug || 'installed' === slug || 'require-update' === slug) {
      return false;
    }

    return true;
  }).reduce(function (res, key) {
    return res[key] = categories[key], res;
  }, {});

  var Items = function Items(props) {
    return Object.keys(props.data).map(function (key) {
      return /*#__PURE__*/React.createElement("li", {
        onClick: groupItemsOnClick,
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
          active: activeCategories.indexOf(key) > -1
        }),
        "data-key": key
      }, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_4__["default"])(props.data[key].title));
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    window.JNewsDashboard['currentLocation'] = window.JNewsDashboard['currentLocation'] || {};
    var currentLocation = window.JNewsDashboard['currentLocation'];
    currentLocation.category = activeCategories;
    (0,_util_current_url__WEBPACK_IMPORTED_MODULE_6__["default"])();
  }, [activeCategories]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement("h3", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Category', '__text_domain__')), /*#__PURE__*/React.createElement("ul", null, /*#__PURE__*/React.createElement(Items, {
    data: categoryItems
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (PluginCategories);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugin-item-checkbox.js":
/*!*******************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugin-item-checkbox.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);


var PluginCheckbox = function PluginCheckbox(props) {
  var slug = props.slug,
      selectedPlugin = props.selectedPlugin,
      onSelectedPlugin = props.onSelectedPlugin;
  return /*#__PURE__*/React.createElement("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()('box-item-checkbox', {
      active: selectedPlugin.indexOf(slug) > -1
    }),
    "data-key": slug,
    onClick: onSelectedPlugin
  });
};

/* harmony default export */ __webpack_exports__["default"] = (PluginCheckbox);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugin-item.js":
/*!**********************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugin-item.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");
/* harmony import */ var _plugin_item_checkbox__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./plugin-item-checkbox */ "./src/jnews/src/content/page/plugin/plugin-item-checkbox.js");
/* harmony import */ var _plugin_process__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./plugin-process */ "./src/jnews/src/content/page/plugin/plugin-process.js");




function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}









var ProgressLine = function ProgressLine(_ref) {
  var progressBar = _ref.progressBar;

  var StepLine = function StepLine() {
    var percent = 0;

    if (progressBar) {
      percent = progressBar;
    }

    return /*#__PURE__*/React.createElement("span", {
      style: {
        width: percent + '%'
      }
    });
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "line"
  }, /*#__PURE__*/React.createElement(StepLine, null));
};

var PluginActionButton = function PluginActionButton(_ref2) {
  var _classNames;

  var action = _ref2.action,
      slug = _ref2.slug,
      buttonText = _ref2.buttonText,
      loading = _ref2.loading,
      localLoading = _ref2.localLoading,
      progressBar = _ref2.progressBar,
      onClickAction = _ref2.onClickAction,
      actionNotice = _ref2.actionNotice;
  var buttonWrapperClass = classnames__WEBPACK_IMPORTED_MODULE_6___default()('dashboard-button-wrapper', {
    disabled: slug === loading && localLoading && action !== localLoading,
    success: slug === loading && localLoading && action === localLoading && 'success' === actionNotice,
    failed: slug === loading && localLoading && action === localLoading && 'failed' === actionNotice
  });
  var buttonClass = classnames__WEBPACK_IMPORTED_MODULE_6___default()('dashboard-button', (_classNames = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(_classNames, "".concat(action), true), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(_classNames, "loading", slug === loading && action === localLoading), _classNames));
  var text = slug === loading && action === localLoading ? buttonText.loading : buttonText.normal;

  if (actionNotice) {
    text = slug === loading && action === localLoading && actionNotice ? buttonText[actionNotice] : buttonText.normal;
  }

  var IconActionNotice = function IconActionNotice() {
    switch (actionNotice) {
      case 'failed':
        return /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_7__["default"], {
          icon: "notice-circle"
        });
        break;

      case 'success':
        return /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_7__["default"], {
          icon: "info-circle"
        });
        break;

      default:
        return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null);
    }
  };

  return /*#__PURE__*/React.createElement("div", {
    className: buttonWrapperClass
  }, /*#__PURE__*/React.createElement("a", {
    className: buttonClass,
    onClick: onClickAction,
    "data-id": slug,
    "data-action": action
  }, slug === loading && action === localLoading && /*#__PURE__*/React.createElement(IconActionNotice, null), text, slug === loading && action === localLoading && /*#__PURE__*/React.createElement(ProgressLine, {
    progressBar: progressBar
  })), slug === loading && action === localLoading && /*#__PURE__*/React.createElement("div", {
    className: "overlay"
  }));
};

var PluginItem = function PluginItem(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)('not-installed'),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      itemClass = _useState2[0],
      setItemClass = _useState2[1];

  var buttonText = {
    install: {
      normal: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Install', '__text_domain__'),
      loading: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Installing...', '__text_domain__'),
      success: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Installing Success', '__text_domain__'),
      failed: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Installing Failed', '__text_domain__')
    },
    activate: {
      normal: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Active', '__text_domain__'),
      loading: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Activating...', '__text_domain__'),
      success: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Activating Success', '__text_domain__'),
      failed: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Activating Failed', '__text_domain__')
    },
    deactivate: {
      normal: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Deactive', '__text_domain__'),
      loading: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Deactivating...', '__text_domain__'),
      success: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Deactivating Success', '__text_domain__'),
      failed: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Deactivating Failed', '__text_domain__')
    },
    update: {
      normal: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Update', '__text_domain__'),
      loading: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Updating...', '__text_domain__'),
      success: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Updating Success', '__text_domain__'),
      failed: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Updating Failed', '__text_domain__')
    }
  };

  var onClickAction = function onClickAction(event) {
    event.preventDefault();

    if (!props.loading) {
      var $target = umbrellajs__WEBPACK_IMPORTED_MODULE_5___default()(event.currentTarget);
      var doing = $target.data('action');
      props.onProcess(props.data.slug);
      props.onLocalProcess(doing);
      (0,_plugin_process__WEBPACK_IMPORTED_MODULE_9__.onManagePlugin)(_objectSpread(_objectSpread({}, props), {}, {
        doing: doing,
        setItemClass: setItemClass
      }));
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    setItemClass(function (prevState) {
      prevState = classnames__WEBPACK_IMPORTED_MODULE_6___default()({
        'not-installed': !props.data.installed,
        installed: props.data.installed && !props.data.activated && !props.data.require_update,
        'need-update': props.data.require_update,
        activated: props.data.activated
      });
      return prevState;
    });
  }, [props.data]);
  var wrapperClass = classnames__WEBPACK_IMPORTED_MODULE_6___default()('item-wrapper', {
    active: props.loading && props.data.slug === props.loading,
    disabled: props.loading && props.data.slug !== props.loading
  });

  var PluginName = function PluginName() {
    if (props.data.link && props.data.activated) {
      return Object.keys(props.data.link).map(function (index) {
        return /*#__PURE__*/React.createElement("a", {
          href: props.data.link[index].url,
          target: props.data.link[index].newtab ? '_blank' : '_self',
          rel: "noreferrer"
        }, /*#__PURE__*/React.createElement("h3", null, props.data.name));
      });
    }

    return /*#__PURE__*/React.createElement("h3", null, props.data.name);
  };

  var onSelectedPlugin = function onSelectedPlugin(event) {
    event.preventDefault();
    event.stopPropagation();

    if (!props.loading) {
      var ele = umbrellajs__WEBPACK_IMPORTED_MODULE_5___default()(event.currentTarget);
      var key = ele.data('key');
      props.setSelectedPlugin(function (prevState) {
        if (prevState.indexOf(key) > -1) {
          prevState.splice(prevState.indexOf(key), 1);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
        } else {
          prevState.push(key);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
        }

        return prevState;
      });
    }
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-box-item item-plugin ".concat(itemClass)
  }, /*#__PURE__*/React.createElement("div", {
    className: wrapperClass
  }, /*#__PURE__*/React.createElement("div", {
    className: "box-item-cover"
  }, /*#__PURE__*/React.createElement("div", {
    className: "box-item-overlay",
    "data-key": props.data.slug,
    onClick: onSelectedPlugin
  }, !props.data.group.includes('coming-soon') && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, /*#__PURE__*/React.createElement(_plugin_item_checkbox__WEBPACK_IMPORTED_MODULE_8__["default"], {
    slug: props.data.slug,
    selectedPlugin: props.selectedPlugin,
    onSelectedPlugin: onSelectedPlugin
  }), props.data.require_update && !props.data.recommended && /*#__PURE__*/React.createElement("div", {
    className: "box-item-update-notice"
  }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_7__["default"], {
    icon: "info-circle",
    noMargin: true
  }), /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Update Available', '__text_domain__'))), props.data.recommended && /*#__PURE__*/React.createElement("div", {
    className: "box-item-recommended-notice"
  }, /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_7__["default"], {
    icon: "star",
    noMargin: true
  }), /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Recomended', '__text_domain__'))), /*#__PURE__*/React.createElement("div", {
    className: "box-item-info-description"
  }, props.data.version && /*#__PURE__*/React.createElement("span", null, "V".concat(props.data.current_version ? props.data.current_version : props.data.version)), props.data.author && /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.sprintf)((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('by %s', '__text_domain__'), props.data.author))))), /*#__PURE__*/React.createElement("img", {
    src: props.data.detail.image,
    alt: props.data.name,
    loading: "lazy"
  })), /*#__PURE__*/React.createElement("div", {
    className: "box-item-info"
  }, /*#__PURE__*/React.createElement(PluginName, null), !props.data.group.includes('coming-soon') && /*#__PURE__*/React.createElement("div", {
    className: "dashboard-action"
  }, !props.data.installed && /*#__PURE__*/React.createElement(PluginActionButton, {
    action: 'install',
    slug: props.data.slug,
    buttonText: buttonText.install,
    loading: props.loading,
    localLoading: props.localLoading,
    progressBar: props.progressBar,
    setProgressBar: props.setProgressBar,
    onClickAction: onClickAction,
    actionNotice: props.actionNotice
  }), props.data.installed && !props.data.activated && /*#__PURE__*/React.createElement(PluginActionButton, {
    action: 'activate',
    slug: props.data.slug,
    buttonText: buttonText.activate,
    loading: props.loading,
    localLoading: props.localLoading,
    progressBar: props.progressBar,
    setProgressBar: props.setProgressBar,
    onClickAction: onClickAction,
    actionNotice: props.actionNotice
  }), props.data.installed && props.data.activated && /*#__PURE__*/React.createElement(PluginActionButton, {
    action: 'deactivate',
    slug: props.data.slug,
    buttonText: buttonText.deactivate,
    loading: props.loading,
    localLoading: props.localLoading,
    progressBar: props.progressBar,
    setProgressBar: props.setProgressBar,
    onClickAction: onClickAction,
    actionNotice: props.actionNotice
  }), props.data.require_update && /*#__PURE__*/React.createElement(PluginActionButton, {
    action: 'update',
    slug: props.data.slug,
    buttonText: buttonText.update,
    loading: props.loading,
    localLoading: props.localLoading,
    progressBar: props.progressBar,
    setProgressBar: props.setProgressBar,
    onClickAction: onClickAction,
    actionNotice: props.actionNotice
  }))), /*#__PURE__*/React.createElement("div", {
    className: "overlay"
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (PluginItem);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugin-process.js":
/*!*************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugin-process.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "onActionError": function() { return /* binding */ onActionError; },
/* harmony export */   "onBulkManagePlugin": function() { return /* binding */ onBulkManagePlugin; },
/* harmony export */   "onManagePlugin": function() { return /* binding */ onManagePlugin; },
/* harmony export */   "popupErrorHandler": function() { return /* binding */ popupErrorHandler; },
/* harmony export */   "refreshCategories": function() { return /* binding */ refreshCategories; },
/* harmony export */   "refreshPlugin": function() { return /* binding */ refreshPlugin; },
/* harmony export */   "runManagePlugin": function() { return /* binding */ runManagePlugin; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../config */ "./src/jnews/src/config.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _modal_error_handler__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../modal-error-handler */ "./src/jnews/src/content/modal-error-handler.js");



function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}






/**
 * Popup Error Handler
 *
 * @param {String|Boolean} message
 *
 * Need popupData
 * Need setPopupData, setOpenModalError
 * @param {Object} params
 */

var popupErrorHandler = function popupErrorHandler(message, params) {
  var popupData = params.popupData;
  var setPopupData = params.setPopupData,
      setOpenModalError = params.setOpenModalError;
  var data = popupData;
  data.header.headerText = (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Failed!', '__text_domain__');
  data.closablePopup = true;
  (0,_modal_error_handler__WEBPACK_IMPORTED_MODULE_6__["default"])({
    popupData: data,
    message: message,
    setPopupData: setPopupData
  });
  setOpenModalError(true);
};
/**
 * Action Error Handler
 *
 * @param {String|Boolean} message
 *
 * Need setProgressBar, onActionNotice, onProcess, onLocalProcess
 * @param {Object} params
 */

var onActionError = function onActionError(message, params) {
  var setProgressBar = params.setProgressBar,
      onActionNotice = params.onActionNotice,
      onProcess = params.onProcess,
      onLocalProcess = params.onLocalProcess,
      setInAction = params.setInAction;
  setProgressBar(100);
  onActionNotice('failed');
  setTimeout(function () {
    onProcess(false);
    onLocalProcess(false);
    onActionNotice(false);
    setInAction(false);
  }, 1000);

  if ('' !== message) {
    popupErrorHandler(message, params);
  }
};
/**
 * Run Manage Plugin
 *
 * @param {Object} plugin_data
 *
 * Need doing, plugins
 * Need setPlugins, onProcess, onLocalProcess, setProgressBar, onActionNotice
 * @param {Object} params
 */

var runManagePlugin = function runManagePlugin(plugin_data, params) {
  // Params
  var doing = params.doing,
      plugins = params.plugins;
  var setPlugins = params.setPlugins,
      onProcess = params.onProcess,
      onLocalProcess = params.onLocalProcess,
      setProgressBar = params.setProgressBar,
      onActionNotice = params.onActionNotice,
      setListProcess = params.setListProcess,
      setCategories = params.setCategories; // Loaded Data

  var loadedDataExist = window.JNewsDashboard['loadedData'];
  var loadedDataPlugin = loadedDataExist ? loadedDataExist['plugin'] : false;
  setProgressBar(60);
  (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.managePlugin)({
    from: 'react',
    plugin: plugin_data,
    doing: doing
  }).then(function (result) {
    setProgressBar(80);

    if (result) {
      if (!setListProcess) {
        if ('install' !== doing) {
          (0,_wordpress_hooks__WEBPACK_IMPORTED_MODULE_2__.doAction)('jnews.after.manage.plugin', plugin_data.slug);
        }
      }

      (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.validatePlugin)({
        plugins: plugins
      }).then(function (result) {
        setProgressBar(100);

        if (result) {
          loadedDataPlugin['plugins'] = result;
          onActionNotice('success');
          setTimeout(function () {
            setPlugins(loadedDataPlugin['plugins']);
            refreshCategories(loadedDataPlugin, setCategories);
            onProcess(false);
            onLocalProcess(false);

            if (setListProcess) {
              setListProcess(function (prevState) {
                if (prevState.indexOf(plugin_data.slug) > -1) {
                  prevState.splice(prevState.indexOf(plugin_data.slug), 1);
                  prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(prevState);
                } else {
                  prevState.push(plugin_data.slug);
                  prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(prevState);
                }

                return prevState;
              });
            }

            onActionNotice(false);
          }, 1000);
        } else {
          onActionError('', params);
        }
      })["catch"](function (error) {
        var message = false;

        if (error) {
          message = error.message;
        }

        onActionError(message, params);
      });
    } else {
      onActionNotice('failed');
      setTimeout(function () {
        onProcess(false);
        onLocalProcess(false);
        onActionNotice(false);
      }, 1000);
    }
  })["catch"](function (error) {
    var message = false;

    if (error) {
      message = error.message;
    }

    onActionError(message, params);
  });
};
/**
 * Manage Plugin Handler
 *
 * Need doing, plugins, popupData
 * Need onLocalProcess, onProcess, setProgressBar, onActionNotice, setOpenModalError, setPopupData, setPlugins
 * @param {Object} params
 */

var onManagePlugin = function onManagePlugin(params) {
  // Params
  var onProcess = params.onProcess,
      onLocalProcess = params.onLocalProcess,
      setProgressBar = params.setProgressBar,
      setInAction = params.setInAction; // Plugin Data

  var _params$data = params.data,
      slug = _params$data.slug,
      name = _params$data.name,
      version = _params$data.version,
      file_path = _params$data.file_path,
      source = _params$data.source,
      refresh = _params$data.refresh; // Validation

  var purchase_code = _config__WEBPACK_IMPORTED_MODULE_4__.licenseData.purchase_code,
      validated = _config__WEBPACK_IMPORTED_MODULE_4__.licenseData.validated;
  setProgressBar(20);

  if (validated) {
    (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.checkPluginRemote)({
      source: source,
      slug: slug
    }).then(function (result) {
      setProgressBar(40);
      var plugin_data = {};

      if (result) {
        if ('bundle' === result || 'server' === result) {
          plugin_data = {
            slug: slug,
            name: name,
            version: version,
            file: file_path,
            source: source,
            refresh: refresh,
            type: result
          };

          if ('server' === result) {
            var plugin_url = new URL(_config__WEBPACK_IMPORTED_MODULE_4__.JNewsServerURL + '/wp-json/' + 'jnews-server/v1/getJNewsData');
            plugin_url.searchParams.set('type', 'plugin');
            plugin_url.searchParams.set('name', source);
            plugin_url.searchParams.set('purchase_code', purchase_code);
            plugin_url.searchParams.set('domain', _config__WEBPACK_IMPORTED_MODULE_4__.domainURL);
            plugin_data.source = plugin_url;
          }
        } else {
          plugin_data = {
            slug: slug,
            name: name,
            version: version,
            file: file_path,
            refresh: refresh,
            type: result
          };
        }

        if (plugin_data.source) {
          (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.validateLicense)({
            purchase_code: purchase_code,
            domain: _config__WEBPACK_IMPORTED_MODULE_4__.domainURL
          }).then(function (result) {
            if (result) {
              runManagePlugin(plugin_data, params);
            } else {
              onActionError('', params);
            }
          })["catch"](function (error) {
            var message = false;

            if (error) {
              message = error.message;

              if (error.response) {
                if (error.response.data) {
                  message = error.response.data.message ? error.response.data.message : error.message;
                }
              }
            }

            onActionError(message, params);
          });
        } else {
          runManagePlugin(plugin_data, params);
        }
      }
    })["catch"](function (error) {
      var message = false;

      if (error) {
        message = error.message;
      }

      onActionError(message, params);
    });
  } else {
    onProcess(false);
    onLocalProcess(false);
    setInAction(false);
    popupErrorHandler((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__.__)('Please activate your copy of JNews', '__text_domain__'), params);
  }
};
/**
 *
 * @param {Boolean} refresh
 *
 * Need plugins
 * Need onProcess, onLocalProcess, setPlugins, onLoadPlugins, getPlugins, setCategories
 * @param {Object} params
 */

var refreshPlugin = function refreshPlugin() {
  var refresh = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  var params = arguments.length > 1 ? arguments[1] : undefined; // Params

  var plugins = params.plugins;
  var onProcess = params.onProcess,
      onLocalProcess = params.onLocalProcess,
      setPlugins = params.setPlugins,
      onLoadPlugins = params.onLoadPlugins,
      getPlugins = params.getPlugins,
      setCategories = params.setCategories; // Global Data

  window.JNewsDashboard['loadedData'] = window.JNewsDashboard['loadedData'] || {};
  var loadedDataExist = window.JNewsDashboard['loadedData'];
  var loadedDataPlugin = loadedDataExist ? loadedDataExist['plugin'] : false;

  if (!loadedDataExist || !loadedDataPlugin || refresh) {
    onProcess(true);
    onLocalProcess(true);
    setPlugins(onLoadPlugins(plugins));
    getPlugins({
      debug: true
    }).then(function (result) {
      if (result) {
        var data = onLoadPlugins(result);
        loadedDataExist['plugin'] = data;
        (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.validatePlugin)({
          plugins: data.plugins
        }).then(function (result) {
          if (result) {
            loadedDataExist['plugin']['plugins'] = result;
            setPlugins(onLoadPlugins(result));
            refreshCategories(data, setCategories);
          }

          onProcess(false);
          onLocalProcess(false);
        });
      }
    })["catch"](function (error) {
      onProcess(false);
      onLocalProcess(false);
    });
  } else {
    if (loadedDataPlugin) {
      var data = loadedDataPlugin;
      setPlugins(data.plugins);
      refreshCategories(data, setCategories);
    }
  }
};
/**
 * Need data ( list of groups and plugin), setCategories
 * @param {Object} data
 * @param {Function} setCategories
 */

var refreshCategories = function refreshCategories(data, setCategories) {
  setCategories(function (prevState) {
    var count = 0;
    prevState = _objectSpread(_objectSpread({}, prevState), data.groups);
    prevState = Object.keys(prevState).filter(function (slug) {
      if ('require-update' === slug) {
        Object.keys(data.plugins).map(function (plugin) {
          if (data.plugins[plugin].require_update) {
            count++;
          }
        });

        if (count > 0) {
          return true;
        }

        return false;
      }

      return true;
    }).reduce(function (res, key) {
      res[key] = prevState[key];

      if ('require-update' === key) {
        if (count > 0) {
          res[key].badge = count;
        }
      } // return (((res[key] = prevState[key]), res), {})


      return res;
    }, {});
    return prevState;
  });
};
var onBulkManagePlugin = function onBulkManagePlugin(listProcess, params) {
  var plugins = params.plugins,
      selectedBulkAction = params.selectedBulkAction;
  var setListProcess = params.setListProcess,
      setInAction = params.setInAction,
      onProcess = params.onProcess,
      onLocalProcess = params.onLocalProcess;

  if (listProcess.length && 'default' !== selectedBulkAction) {
    var key = listProcess[0];
    onProcess(key);
    onLocalProcess(selectedBulkAction);

    if ('activate' === selectedBulkAction && !plugins[key].activated || 'deactivate' === selectedBulkAction && plugins[key].activated || 'update' === selectedBulkAction && plugins[key].require_update || 'install' === selectedBulkAction && !plugins[key].installed) {
      onManagePlugin(_objectSpread(_objectSpread({}, params), {}, {
        doing: selectedBulkAction,
        data: plugins[key],
        setListProcess: setListProcess,
        setInAction: setInAction
      }));
    } else {
      setListProcess(function (prevState) {
        if (prevState.indexOf(key) > -1) {
          prevState.splice(prevState.indexOf(key), 1);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(prevState);
        } else {
          prevState.push(key);
          prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(prevState);
        }

        return prevState;
      });
    }
  } else {
    setInAction(false);
  }
};

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/plugins.js":
/*!******************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/plugins.js ***!
  \******************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var Plugins = function Plugins(props) {
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-items plugin-items"
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (Plugins);

/***/ }),

/***/ "./src/jnews/src/content/page/plugin/search-plugins.js":
/*!*************************************************************!*\
  !*** ./src/jnews/src/content/page/plugin/search-plugins.js ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);


var SearchPlugins = function SearchPlugins(props) {
  var setSearchFilter = props.setSearchFilter,
      searchFilter = props.searchFilter,
      loading = props.loading;
  return /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-search-wrapper"
  }, /*#__PURE__*/React.createElement("div", {
    className: "jnews-dashboard-search-field-wrapper"
  }, /*#__PURE__*/React.createElement("input", {
    type: "text",
    placeholder: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Search...', '__text_domain__'),
    onChange: function onChange(e) {
      if (!loading) {
        setSearchFilter(e.target.value);
      }
    },
    value: searchFilter ? searchFilter : ''
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (SearchPlugins);

/***/ }),

/***/ "./src/jnews/src/content/page/system-status-page.js":
/*!**********************************************************!*\
  !*** ./src/jnews/src/content/page/system-status-page.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _system_status_system_report__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./system-status/system-report */ "./src/jnews/src/content/page/system-status/system-report.js");
/* harmony import */ var _util_axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../util/axios */ "./src/jnews/src/util/axios.js");
/* harmony import */ var _system_status_system_status__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./system-status/system-status */ "./src/jnews/src/content/page/system-status/system-status.js");








var SystemStatusText = function SystemStatusText(_ref) {
  var title = _ref.title,
      content = _ref.content,
      link_text = _ref.link_text,
      additional_text = _ref.additional_text;
  return title + ' : ' + content + ('' !== link_text ? ' ' + link_text : '') + ('' !== additional_text ? ' - ' + additional_text : '') + '\n';
};

var SystemStatusPage = function SystemStatusPage(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({}),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      dataSystemStatus = _useState2[0],
      setDataSystemStatus = _useState2[1];

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    window.JNewsDashboard['loadedData'] = window.JNewsDashboard['loadedData'] || {};
    var loadedDataExist = window.JNewsDashboard['loadedData'];
    var loadedDataSystem = loadedDataExist ? loadedDataExist['system'] : false;

    if (!loadedDataExist || !loadedDataSystem) {
      (0,_util_axios__WEBPACK_IMPORTED_MODULE_5__.getDashboardConfig)({
        config: 'system'
      }).then(function (result) {
        if (result) {
          loadedDataExist['system'] = result;
          setDataSystemStatus(function (prevState) {
            prevState = loadedDataExist['system'];
            return prevState;
          });
        }
      });
    } else {
      setDataSystemStatus(function (prevState) {
        prevState = loadedDataExist['system'];
        return prevState;
      });
    }
  }, []);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_3__["default"], props, /*#__PURE__*/React.createElement(_system_status_system_report__WEBPACK_IMPORTED_MODULE_4__["default"], {
    dataSystemStatus: dataSystemStatus,
    SystemStatusText: SystemStatusText
  }), /*#__PURE__*/React.createElement(_system_status_system_status__WEBPACK_IMPORTED_MODULE_6__["default"], {
    dataSystemStatus: dataSystemStatus
  })));
};

/* harmony default export */ __webpack_exports__["default"] = (SystemStatusPage);

/***/ }),

/***/ "./src/jnews/src/content/page/system-status/admin-table.js":
/*!*****************************************************************!*\
  !*** ./src/jnews/src/content/page/system-status/admin-table.js ***!
  \*****************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




var AdminTable = function AdminTable(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      headerColSpan = _useState2[0],
      setHeaderColSpan = _useState2[1];

  var title = props.title,
      body = props.body,
      id = props.id;

  var TableBody = function TableBody() {
    return body && body.length && body.map(function (row) {
      var totalCol = row.data.length;

      if (headerColSpan < totalCol) {
        setHeaderColSpan(totalCol);
      }

      return /*#__PURE__*/React.createElement("tr", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(row["class"] ? row["class"] : null)
      }, row.data.map(function (col) {
        return /*#__PURE__*/React.createElement("td", {
          className: classnames__WEBPACK_IMPORTED_MODULE_1___default()(col["class"] ? col["class"] : null)
        }, col.data);
      }));
    });
  };

  return /*#__PURE__*/React.createElement("table", {
    className: "jnews-dashboard-table widefat",
    cellSpacing: "0",
    id: id
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    colSpan: headerColSpan
  }, title))), /*#__PURE__*/React.createElement("tbody", null, /*#__PURE__*/React.createElement(TableBody, null)));
};

/* harmony default export */ __webpack_exports__["default"] = (AdminTable);

/***/ }),

/***/ "./src/jnews/src/content/page/system-status/system-report.js":
/*!*******************************************************************!*\
  !*** ./src/jnews/src/content/page/system-status/system-report.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var _admin_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./admin-table */ "./src/jnews/src/content/page/system-status/admin-table.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");










var copySystemReport = function copySystemReport(_ref) {
  var $target = _ref.$target,
      setShowNotice = _ref.setShowNotice;
  var text = $target.find('textarea').first();
  text.focus();
  text.select();

  var copyWithFallback = function copyWithFallback() {
    if (!navigator.clipboard) {
      try {
        document.execCommand('copy');
      } catch (err) {
        return false;
      }
    } else {
      navigator.clipboard.writeText(text).then(null, function (err) {
        return false;
      });
    }

    return true;
  };

  if (copyWithFallback()) {
    setShowNotice(true);
    setTimeout(function () {
      setShowNotice(false);
    }, 3000);
  }
};

var SystemReport = function SystemReport(props) {
  var title = (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_5__["default"])((0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('System Report <em> - Please copy and paste this information when asking for support</em>', '__text_domain__'));
  var id = 'status';
  var dataSystemStatus = props.dataSystemStatus,
      SystemStatusText = props.SystemStatusText;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      showNotice = _useState2[0],
      setShowNotice = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(''),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      debugReport = _useState4[0],
      setDebugReport = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([{
    data: [{
      data: /*#__PURE__*/React.createElement("div", {
        className: "debug-report"
      }, /*#__PURE__*/React.createElement("textarea", {
        readOnly: "readonly"
      }, debugReport))
    }]
  }]),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      tableBody = _useState6[0],
      setTableBody = _useState6[1];

  var onClickSystemReport = function onClickSystemReport(event) {
    event.preventDefault();
    copySystemReport({
      $target: umbrellajs__WEBPACK_IMPORTED_MODULE_4___default()(event.currentTarget),
      setShowNotice: setShowNotice
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    var data = Object.keys(dataSystemStatus);

    if (data.length) {
      setDebugReport(function (prevState) {
        data.map(function (slug) {
          prevState += '### ' + dataSystemStatus[slug].title + ' ###';

          if ('end' !== slug) {
            prevState += '\n\n';
          }

          Object.keys(dataSystemStatus[slug].data).map(function (key) {
            prevState += umbrellajs__WEBPACK_IMPORTED_MODULE_4___default()('<div/>').html(SystemStatusText({
              title: dataSystemStatus[slug].data[key]['title'],
              content: dataSystemStatus[slug].data[key]['content'],
              link_text: dataSystemStatus[slug].data[key]['link_text'] ? dataSystemStatus[slug].data[key]['link_text'] : '',
              additional_text: dataSystemStatus[slug].data[key]['additional_text'] ? dataSystemStatus[slug].data[key]['additional_text'] : ''
            })).text();

            if (dataSystemStatus[slug].data.length === parseInt(key) + 1) {
              prevState += '\n\n';
            }
          });
        });
        return prevState;
      });
    }
  }, [dataSystemStatus]);
  (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(function () {
    if ('' !== debugReport) {
      setTableBody(function (prevState) {
        prevState = [{
          data: [{
            data: /*#__PURE__*/React.createElement("div", {
              onClick: onClickSystemReport,
              className: "debug-report"
            }, /*#__PURE__*/React.createElement("textarea", {
              readOnly: "readonly"
            }, debugReport), /*#__PURE__*/React.createElement("div", {
              className: classnames__WEBPACK_IMPORTED_MODULE_7___default()('jnews-dashboard-notice success', {
                show: showNotice
              })
            }, /*#__PURE__*/React.createElement("span", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('System Report Copied', '__text_domain__')), /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__["default"], {
              icon: "close",
              closeButton: true
            })))
          }]
        }];
        return (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
      });
    }
  }, [debugReport, showNotice]);
  return /*#__PURE__*/React.createElement(_admin_table__WEBPACK_IMPORTED_MODULE_6__["default"], {
    title: title,
    id: id,
    body: tableBody
  });
};

/* harmony default export */ __webpack_exports__["default"] = (SystemReport);

/***/ }),

/***/ "./src/jnews/src/content/page/system-status/system-status.js":
/*!*******************************************************************!*\
  !*** ./src/jnews/src/content/page/system-status/system-status.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _admin_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./admin-table */ "./src/jnews/src/content/page/system-status/admin-table.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-tooltip */ "./node_modules/react-tooltip/dist/index.es.js");
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");



var _PLACEHOLDER;

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var PLACEHOLDER = (_PLACEHOLDER = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_PLACEHOLDER, 'placeholder-1', {
  title: '',
  data: [{
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }]
}), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_PLACEHOLDER, 'placeholder-2', {
  title: '',
  data: [{
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }]
}), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(_PLACEHOLDER, 'placeholder-3', {
  title: '',
  data: [{
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }, {
    data: [{
      data: '',
      "class": 'status-title'
    }, {
      data: '',
      "class": 'status-flag'
    }, {
      data: ''
    }]
  }]
}), _PLACEHOLDER);

var SystemStatus = function SystemStatus(props) {
  var dataSystemStatus = props.dataSystemStatus;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(PLACEHOLDER),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      statusData = _useState2[0],
      setStatusData = _useState2[1];

  var SystemList = function SystemList() {
    var data = Object.keys(statusData).filter(function (item) {
      if ('end' === item) {
        return false;
      }

      return true;
    }).reduce(function (res, key) {
      return res[key] = statusData[key], res;
    }, {});
    return Object.keys(data).map(function (key) {
      return /*#__PURE__*/React.createElement(_admin_table__WEBPACK_IMPORTED_MODULE_5__["default"], {
        title: data[key].title,
        id: key,
        body: data[key].data
      });
    });
  };

  (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(function () {
    var data = Object.keys(dataSystemStatus);

    if (data.length) {
      setStatusData(function (prevState) {
        var newState = {};
        data.map(function (slug) {
          newState[slug] = {
            title: dataSystemStatus[slug].title,
            data: []
          };
          Object.keys(dataSystemStatus[slug].data).map(function (key) {
            var tooltipWrapperClasses = classnames__WEBPACK_IMPORTED_MODULE_3___default()('tooltip-wrapper', (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])({
              'flag-item': 'flag' === dataSystemStatus[slug].data[key].type
            }, "flag-".concat(dataSystemStatus[slug].data[key].flag), 'flag' === dataSystemStatus[slug].data[key].type));

            var LinkText = function LinkText() {
              return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, dataSystemStatus[slug].data[key].link && dataSystemStatus[slug].data[key].link_text && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, ' ', /*#__PURE__*/React.createElement("a", {
                href: dataSystemStatus[slug].data[key].link
              }, dataSystemStatus[slug].data[key].link_text)), !dataSystemStatus[slug].data[key].link && dataSystemStatus[slug].data[key].link_text && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, " ", dataSystemStatus[slug].data[key].link_text));
            };

            var AdditionalText = function AdditionalText() {
              return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, dataSystemStatus[slug].data[key].additional_text && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, ' - ', dataSystemStatus[slug].data[key].additional_text));
            };

            var SmallText = function SmallText() {
              return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, dataSystemStatus[slug].data[key].small && /*#__PURE__*/React.createElement("em", null, umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()('<div/>').html(dataSystemStatus[slug].data[key].small).text()));
            };

            var ColumnContent = function ColumnContent() {
              return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()('<div/>').html(dataSystemStatus[slug].data[key].content).text(), /*#__PURE__*/React.createElement(LinkText, null), /*#__PURE__*/React.createElement(AdditionalText, null), /*#__PURE__*/React.createElement(SmallText, null));
            };

            var row = {
              data: [{
                data: dataSystemStatus[slug].data[key].title,
                "class": 'status-title'
              }, {
                data: (dataSystemStatus[slug].data[key].tooltip || 'flag' === dataSystemStatus[slug].data[key].type) && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, /*#__PURE__*/React.createElement("div", {
                  className: tooltipWrapperClasses,
                  "data-for": slug + '-' + key,
                  "data-tip": umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()('<div/>').html(dataSystemStatus[slug].data[key].tooltip).text(),
                  "data-iscapture": "true"
                }, 'status' === dataSystemStatus[slug].data[key].type && /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_8__["default"], {
                  icon: "question"
                })), /*#__PURE__*/React.createElement(react_tooltip__WEBPACK_IMPORTED_MODULE_7__["default"], {
                  id: slug + '-' + key,
                  place: "right",
                  type: "light",
                  effect: "solid",
                  className: "system-status-tooltip"
                })),
                "class": classnames__WEBPACK_IMPORTED_MODULE_3___default()('status-flag', {
                  help: 'status' === dataSystemStatus[slug].data[key].type,
                  flag: 'flag' === dataSystemStatus[slug].data[key].type
                })
              }, {
                data: /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_4__.Fragment, null, dataSystemStatus[slug].data[key].mark && /*#__PURE__*/React.createElement("mark", {
                  className: dataSystemStatus[slug].data[key].mark
                }, /*#__PURE__*/React.createElement(ColumnContent, null)), !dataSystemStatus[slug].data[key].mark && /*#__PURE__*/React.createElement(ColumnContent, null))
              }]
            };
            newState[slug].data.push(row);
          });
        });
        return _objectSpread({}, newState);
      });
    }
  }, [dataSystemStatus]);
  return /*#__PURE__*/React.createElement(SystemList, null);
};

/* harmony default export */ __webpack_exports__["default"] = (SystemStatus);

/***/ }),

/***/ "./src/jnews/src/content/page/video-documentation.js":
/*!***********************************************************!*\
  !*** ./src/jnews/src/content/page/video-documentation.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../content */ "./src/jnews/src/content/content.js");
/* harmony import */ var _documentation_youtube_iframe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./documentation/youtube-iframe */ "./src/jnews/src/content/page/documentation/youtube-iframe.js");
/* harmony import */ var _documentation_video_block__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./documentation/video-block */ "./src/jnews/src/content/page/documentation/video-block.js");






var listVideos = [{
  id: '1Yl_cAe2Egk',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Install JNews via WordPress', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/1Yl_cAe2Egk/hqdefault.jpg'
}, {
  id: 'FP3gq-DbdoQ',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Install JNews via FTP', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/FP3gq-DbdoQ/hqdefault.jpg'
}, {
  id: 'JO6N-CCrw2k',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Update JNews via WordPress', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/JO6N-CCrw2k/hqdefault.jpg'
}, {
  id: 'aIX6N4E9a5A',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Update JNews via FTP', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/aIX6N4E9a5A/hqdefault.jpg'
}, {
  id: 'HSwh51SKBRo',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('JNews System Status', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/HSwh51SKBRo/hqdefault.jpg'
}, {
  id: 'bNfdYHJ4Hw4',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Setup JNews Translation', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/bNfdYHJ4Hw4/hqdefault.jpg'
}, {
  id: 'sCr8KohYmxQ',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Setup JNews Font', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/sCr8KohYmxQ/hqdefault.jpg'
}, {
  id: '2eIhfdD9uJU',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Setup Comments', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/2eIhfdD9uJU/hqdefault.jpg'
}, {
  id: '1dmOsQTW9Vo',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Setup JNews Split Post', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/1dmOsQTW9Vo/hqdefault.jpg'
}, {
  id: 'd5rNUB6qDu0',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Setup JNews Page Loop', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/d5rNUB6qDu0/hqdefault.jpg'
}, {
  id: 'mldLr8W5m7U',
  name: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('How to Manage JNews Widget', '__text_domain__'),
  thumb: 'https://i.ytimg.com/vi/mldLr8W5m7U/hqdefault.jpg'
}];

var VideoDocumentation = function VideoDocumentation(props) {
  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(listVideos[0].id),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      activeVideo = _useState2[0],
      setActiveVideo = _useState2[1];

  var updateActiveVideo = function updateActiveVideo(value) {
    setActiveVideo(value);
  };

  var VideoHolder = function VideoHolder() {
    return listVideos.filter(function (video) {
      if (activeVideo === video.id) return true;
    }).map(function (video) {
      return /*#__PURE__*/React.createElement(_documentation_youtube_iframe__WEBPACK_IMPORTED_MODULE_4__["default"], {
        id: video.id
      });
    });
  };

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, /*#__PURE__*/React.createElement(_content__WEBPACK_IMPORTED_MODULE_3__["default"], props, /*#__PURE__*/React.createElement("h1", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('Video Documentation', '__text_domain__')), /*#__PURE__*/React.createElement("p", null, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__.__)('We would like to thank you for purchasing JNews! Before you get started, please be sure to always take a look at our Documentation and also watch our integrated Video Tutorials.', '__text_domain__')), /*#__PURE__*/React.createElement("div", {
    className: "video-holder"
  }, /*#__PURE__*/React.createElement("div", {
    className: "video-container"
  }, /*#__PURE__*/React.createElement(VideoHolder, null))), /*#__PURE__*/React.createElement("div", {
    className: "video-wrapper"
  }, /*#__PURE__*/React.createElement("div", {
    className: "video-wrapper-inner"
  }, listVideos.map(function (video) {
    return /*#__PURE__*/React.createElement(_documentation_video_block__WEBPACK_IMPORTED_MODULE_5__["default"], {
      id: video.id,
      title: video.name,
      updateActiveVideo: updateActiveVideo,
      activeVideo: activeVideo
    });
  })))));
};

/* harmony default export */ __webpack_exports__["default"] = (VideoDocumentation);

/***/ }),

/***/ "./src/jnews/src/content/side-content.js":
/*!***********************************************!*\
  !*** ./src/jnews/src/content/side-content.js ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Side Content
 * 
 * @param {object} props 
 * @returns {JSX.Element}
 */
var SideContent = function SideContent(props) {
  return /*#__PURE__*/React.createElement("div", {
    className: "dashboard-side-content"
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (SideContent);

/***/ }),

/***/ "./src/jnews/src/control/control-checkbox.js":
/*!***************************************************!*\
  !*** ./src/jnews/src/control/control-checkbox.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");

/**
 * Control Checkbox
 * 
 * @param {object} props 
 * @returns {JSX.Element}
 */

var ControlCheckbox = function ControlCheckbox(props) {
  var id = props.id,
      title = props.title,
      description = props.description,
      value = props.value,
      updateValue = props.updateValue;
  var type = 'checkbox';
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])();
  /**
   * Input Value
   * 
   * @param {string} id 
   * @param {*} val 
   */

  var inputChange = function inputChange(id, val) {
    updateValue(id, val);
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "control-wrapper control-".concat(type)
  }, /*#__PURE__*/React.createElement("div", {
    className: 'control-body'
  }, /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title, /*#__PURE__*/React.createElement("input", {
    id: "".concat(id, "-").concat(type, "-").concat(uuid),
    type: type,
    checked: value,
    onChange: function onChange(e) {
      return inputChange(id, e.target.checked);
    },
    hidden: true
  }), /*#__PURE__*/React.createElement("span", {
    className: "switch"
  })), description !== '' && /*#__PURE__*/React.createElement("span", {
    className: "control-description"
  }, description)));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlCheckbox);

/***/ }),

/***/ "./src/jnews/src/control/control-radio-tab.js":
/*!****************************************************!*\
  !*** ./src/jnews/src/control/control-radio-tab.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");


/**
 * Control RadioTab
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ControlRadioTab = function ControlRadioTab(props) {
  var id = props.id,
      title = props.title,
      value = props.value,
      globalValue = props.globalValue,
      updateValue = props.updateValue,
      options = props.options;
  var type = 'radio-tab';
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_1__["default"])(),
      description;
  /**
   * Input Value
   *
   * @param {string} id
   * @param {*} val
   */

  var inputChange = function inputChange(id, val) {
    updateValue(id, val);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (globalValue) {
      if (globalValue !== value) {
        inputChange(id, value);
      }
    }
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "control-wrapper control-".concat(type)
  }, /*#__PURE__*/React.createElement("div", {
    className: 'control-body'
  }, /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title), /*#__PURE__*/React.createElement("div", {
    className: 'control-inner-body'
  }, options.map(function (item, index) {
    uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_1__["default"])();
    var checked = value ? value === item.value : index === 0;

    if (value && value === item.value) {
      description = item.description;
    }

    return /*#__PURE__*/React.createElement("label", {
      className: "control-inner-title",
      htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
    }, /*#__PURE__*/React.createElement("input", {
      id: "".concat(id, "-").concat(type, "-").concat(uuid),
      type: 'radio',
      checked: checked,
      onClick: function onClick() {
        return inputChange(id, item.value);
      },
      onChange: function onChange() {},
      name: "".concat(id),
      value: item.value,
      hidden: true
    }), /*#__PURE__*/React.createElement("span", null, item.title));
  })), description !== '' && /*#__PURE__*/React.createElement("span", {
    className: "control-description"
  }, description)));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlRadioTab);

/***/ }),

/***/ "./src/jnews/src/control/control-radio.js":
/*!************************************************!*\
  !*** ./src/jnews/src/control/control-radio.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");


var ControlRadio = function ControlRadio(props) {
  var id = props.id,
      title = props.title,
      description = props.description,
      value = props.value,
      updateValue = props.updateValue,
      options = props.options;
  var type = 'radio';
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])();
  /**
   * Input Value
   *
   * @param {string} id
   * @param {*} val
   */

  var inputChange = function inputChange(id, val, index) {
    updateValue(id, val);
  };

  return /*#__PURE__*/React.createElement("div", {
    className: "control-wrapper control-".concat(type)
  }, /*#__PURE__*/React.createElement("div", {
    className: 'control-body'
  }, /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title), /*#__PURE__*/React.createElement("div", {
    className: 'control-inner-body'
  }, options.map(function (item, index) {
    uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])();
    var checked = value ? value == item.value : index === 0;
    return /*#__PURE__*/React.createElement("label", {
      key: uuid,
      className: "control-inner-title",
      htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
    }, /*#__PURE__*/React.createElement("input", {
      id: "".concat(id, "-").concat(type, "-").concat(uuid),
      type: type,
      checked: checked,
      onClick: function onClick() {
        return inputChange(id, item.value, index);
      },
      onChange: function onChange() {},
      name: "".concat(id),
      value: item.value,
      hidden: true
    }), /*#__PURE__*/React.createElement("span", {
      className: "control-item-title"
    }, item.title), '' !== item.description && /*#__PURE__*/React.createElement("span", {
      className: "item-description"
    }, item.description));
  })), description !== '' && /*#__PURE__*/React.createElement("span", {
    className: "control-description"
  }, description)));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlRadio);

/***/ }),

/***/ "./src/jnews/src/control/control-select.js":
/*!*************************************************!*\
  !*** ./src/jnews/src/control/control-select.js ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");


var ControlSelect = function ControlSelect(props) {
  var id = props.id,
      title = props.title,
      description = props.description,
      value = props.value,
      options = props.options,
      updateValue = props.updateValue;
  var type = 'select';
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_0__["default"])();
  /**
   * Input Value
   * 
   * @param {string} id 
   * @param {*} val 
   */

  var inputChange = function inputChange(id, select) {
    updateValue(id, options[select.selectedIndex].value);
  };

  var selectedOption = value;
  var selectOptions = options.map(function (item, index) {
    selectedOption = value;
    return /*#__PURE__*/React.createElement("option", {
      key: "".concat(item.value, "-").concat(uuid),
      value: item.value
    }, item.title);
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "control-wrapper control-".concat(type)
  }, title && /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title), /*#__PURE__*/React.createElement("select", {
    id: id,
    value: selectedOption,
    onChange: function onChange(e) {
      return inputChange(id, e.target);
    }
  }, selectOptions));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlSelect);

/***/ }),

/***/ "./src/jnews/src/control/control-textarea.js":
/*!***************************************************!*\
  !*** ./src/jnews/src/control/control-textarea.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");



/**
 * Control TextArea
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ControlTextArea = function ControlTextArea(props) {
  var id = props.id,
      title = props.title,
      value = props.value,
      updateValue = props.updateValue,
      description = props.description,
      placeholder = props.placeholder,
      style = props.style;
  var type = 'textarea';
  var wrapperClasses = classnames__WEBPACK_IMPORTED_MODULE_1___default()("control-wrapper control-".concat(type), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, "".concat(style),  true && 'undefined' !== typeof style));
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_2__["default"])();
  /**
   * Input Value
   *
   * @param {string} id
   * @param {*} val
   */

  var inputChange = function inputChange(id, val) {
    updateValue(id, val);
  };

  return /*#__PURE__*/React.createElement("div", {
    className: wrapperClasses
  }, /*#__PURE__*/React.createElement("div", {
    className: 'control-body'
  }, /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title), /*#__PURE__*/React.createElement("div", {
    className: 'control-inner-body'
  }, /*#__PURE__*/React.createElement("textarea", {
    id: "".concat(id, "-").concat(type, "-").concat(uuid),
    placeholder: placeholder,
    onChange: function onChange(e) {
      return inputChange(id, e.target.value);
    },
    defaultValue: value === undefined ? '' : value
  }), description !== '' && /*#__PURE__*/React.createElement("span", {
    className: "control-description"
  }, description))));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlTextArea);

/***/ }),

/***/ "./src/jnews/src/control/control-textbox.js":
/*!**************************************************!*\
  !*** ./src/jnews/src/control/control-textbox.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");



/**
 * Control TextBox
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var ControlTextBox = function ControlTextBox(props) {
  var id = props.id,
      title = props.title,
      value = props.value,
      updateValue = props.updateValue,
      description = props.description,
      placeholder = props.placeholder,
      style = props.style;
  var type = 'textbox';
  var wrapperClasses = classnames__WEBPACK_IMPORTED_MODULE_1___default()("control-wrapper control-".concat(type), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, "".concat(style),  true && 'undefined' !== typeof style));
  var uuid = (0,uuid__WEBPACK_IMPORTED_MODULE_2__["default"])();
  /**
   * Input Value
   *
   * @param {string} id
   * @param {*} val
   */

  var inputChange = function inputChange(id, val) {
    updateValue(id, val);
  };

  return /*#__PURE__*/React.createElement("div", {
    className: wrapperClasses
  }, /*#__PURE__*/React.createElement("div", {
    className: 'control-body'
  }, /*#__PURE__*/React.createElement("label", {
    className: "control-title",
    htmlFor: "".concat(id, "-").concat(type, "-").concat(uuid)
  }, title), /*#__PURE__*/React.createElement("div", {
    className: 'control-inner-body'
  }, /*#__PURE__*/React.createElement("input", {
    id: "".concat(id, "-").concat(type, "-").concat(uuid),
    type: 'text',
    placeholder: placeholder,
    value: value === undefined ? '' : value,
    onChange: function onChange(e) {
      return inputChange(id, e.target.value);
    }
  }), description !== '' && /*#__PURE__*/React.createElement("span", {
    className: "control-description"
  }, description))));
};

/* harmony default export */ __webpack_exports__["default"] = (ControlTextBox);

/***/ }),

/***/ "./src/jnews/src/control/controls.js":
/*!*******************************************!*\
  !*** ./src/jnews/src/control/controls.js ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _control_checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./control-checkbox */ "./src/jnews/src/control/control-checkbox.js");
/* harmony import */ var _control_radio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./control-radio */ "./src/jnews/src/control/control-radio.js");
/* harmony import */ var _control_textarea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./control-textarea */ "./src/jnews/src/control/control-textarea.js");
/* harmony import */ var _control_select__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./control-select */ "./src/jnews/src/control/control-select.js");
/* harmony import */ var _control_textbox__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./control-textbox */ "./src/jnews/src/control/control-textbox.js");


function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}








var Controls = function Controls(props) {
  var controls = props.controls,
      setControls = props.setControls,
      wrapper = props.wrapper;

  var updateControls = function updateControls(id, value) {
    setControls(_objectSpread(_objectSpread({}, controls), {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, id, _objectSpread(_objectSpread({}, controls[id]), {}, {
      value: value
    }))));
  };

  var dependencyCheck = function dependencyCheck(dependency) {
    return undefined !== dependency.value ? dependency.value.includes(controls[dependency.control].value) : true;
  };

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, Object.keys(controls).map(function (key) {
    var _controls$key = controls[key],
        title = _controls$key.title,
        description = _controls$key.description,
        value = _controls$key.value,
        options = _controls$key.options,
        type = _controls$key.type,
        _controls$key$depende = _controls$key.dependency,
        dependency = _controls$key$depende === void 0 ? {} : _controls$key$depende;
    var control = '';

    switch (type) {
      case 'checkbox':
        control = dependencyCheck(dependency) && /*#__PURE__*/React.createElement(_control_checkbox__WEBPACK_IMPORTED_MODULE_2__["default"], {
          id: key,
          title: title,
          value: value,
          description: description,
          updateValue: updateControls
        });
        break;

      case 'select':
        control = dependencyCheck(dependency) && /*#__PURE__*/React.createElement(_control_select__WEBPACK_IMPORTED_MODULE_5__["default"], {
          id: key,
          title: title,
          value: value,
          options: options,
          updateValue: updateControls
        });
        break;

      case 'textarea':
        control = dependencyCheck(dependency) && /*#__PURE__*/React.createElement(_control_textarea__WEBPACK_IMPORTED_MODULE_4__["default"], {
          id: key,
          title: title,
          value: value,
          description: description,
          updateValue: updateControls,
          style: "table"
        });
        break;

      case 'radio':
        control = dependencyCheck(dependency) && /*#__PURE__*/React.createElement(_control_radio__WEBPACK_IMPORTED_MODULE_3__["default"], {
          id: key,
          title: title,
          value: value,
          options: options,
          updateValue: updateControls
        });
        break;

      case 'text':
        control = dependencyCheck(dependency) && /*#__PURE__*/React.createElement(_control_textbox__WEBPACK_IMPORTED_MODULE_6__["default"], {
          id: key,
          title: title,
          value: value,
          updateValue: updateControls
        });
        break;
    }

    return wrapper ? wrapper(control, controls[key]) : control;
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Controls);

/***/ }),

/***/ "./src/jnews/src/dashboard.js":
/*!************************************!*\
  !*** ./src/jnews/src/dashboard.js ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _content_content_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./content/content-wrapper */ "./src/jnews/src/content/content-wrapper.js");
/* harmony import */ var _util_current_url__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./util/current-url */ "./src/jnews/src/util/current-url.js");
/* harmony import */ var _navigation_navigation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./navigation/navigation */ "./src/jnews/src/navigation/navigation.js");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_7__);








/**
 * Dashboard
 *
 * @returns {JSX.Element}
 */

var Dashboard = function Dashboard() {
  var locationURL = new URL(window.location.href);
  var urlDashboardPage = locationURL.searchParams.get('page');
  var urlDashboardPath = locationURL.searchParams.get('path');
  var urlDashboard = (urlDashboardPage ? urlDashboardPage : 'jnews') + (urlDashboardPath ? '&path=' + urlDashboardPath : '');

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      seperateMenu = _useState2[0],
      setSeperateMenu = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(urlDashboard),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      activePage = _useState4[0],
      setActivePage = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      loading = _useState6[0],
      setLoading = _useState6[1];

  var menus = window['JNewsDashboard'].menus;
  var timerRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
  var mainMenu = menus.filter(function (menu) {
    return !menu.plugin;
  });
  var pluginMenu = menus.filter(function (menu) {
    menu.dropdown_item = true;
    return menu.plugin;
  });
  /**
   * On Process Handler
   *
   * @param {boolean|string} value
   */

  var onProcess = function onProcess(value) {
    setLoading(value);
  };
  /**
   * Is loading
   *
   * @returns {boolean|string}
   */


  var isLoading = function isLoading() {
    return loading;
  };
  /**
   * Change Page Handler
   *
   * @param {string} slug
   */


  var changePage = function changePage(slug) {
    if (!loading) {
      setActivePage('jnews&path=jnews' === slug ? slug.replace('jnews&path=jnews', 'jnews') : slug.includes('jnews&path=jnews') ? slug : slug.replace('jnews&path=', ''));
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    if (urlDashboard) {
      changePage(urlDashboard);
    }

    setSeperateMenu(function (prevState) {
      if (pluginMenu.length) {
        prevState = [].concat((0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(mainMenu), [{
          name: 'plugins',
          title: (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_6__.__)('Plugin Dashboard', '__text_domain__'),
          url: '#',
          plugin: false,
          type: 'dropdown',
          menus: pluginMenu
        }]);
      } else {
        prevState = (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(mainMenu);
      }

      return (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
    });
  }, []); // We need to set loading to global

  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var globalLoading;

    if ('undefined' === typeof window.JNewsDashboard['loading']) {
      window.JNewsDashboard['loading'] = window.JNewsDashboard['loading'] || {};
      globalLoading = window.JNewsDashboard['loading'];
      globalLoading.onProcess = onProcess;
    } else {
      globalLoading = window.JNewsDashboard['loading'];
    }

    globalLoading.isLoading = isLoading;
  }, [loading]);
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    window.JNewsDashboard['currentLocation'] = window.JNewsDashboard['currentLocation'] || {};
    var currentLocation = window.JNewsDashboard['currentLocation'];

    if ('jnews' === urlDashboardPage) {
      currentLocation.page = 'jnews';
      currentLocation.path = activePage.replace('jnews&path=', '');
    } else {
      currentLocation.page = null;
      currentLocation.path = activePage.replace('jnews&path=', '');
    }

    (0,_util_current_url__WEBPACK_IMPORTED_MODULE_4__["default"])();
    umbrellajs__WEBPACK_IMPORTED_MODULE_7___default()('#menu-appearance,#toplevel_page_jnews').find('.wp-submenu a').each(function (item) {
      var ahref = umbrellajs__WEBPACK_IMPORTED_MODULE_7___default()(item);
      var href = ahref.attr('href');
      var parent = ahref.parent('li');
      ahref.removeClass('current');
      parent.removeClass('current');

      if (href.includes(activePage) && 'jnews' !== activePage) {
        ahref.addClass('current');
        parent.addClass('current');
      }

      if ('jnews' === activePage) {
        if (href === 'admin.php?page=' + activePage || href === 'themes.php?page=' + activePage) {
          ahref.addClass('current');
          parent.addClass('current');
        }
      }
    });
  }, [activePage]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement(_navigation_navigation__WEBPACK_IMPORTED_MODULE_5__["default"], {
    timerRef: timerRef,
    setCurrentMenu: changePage,
    currentMenu: activePage,
    loading: loading,
    menus: seperateMenu
  }), /*#__PURE__*/React.createElement(_content_content_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    activePage: activePage,
    onNavItemClick: changePage,
    loading: loading,
    onProcess: onProcess,
    menus: seperateMenu
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (Dashboard);

/***/ }),

/***/ "./src/jnews/src/icon/icon-svg.js":
/*!****************************************!*\
  !*** ./src/jnews/src/icon/icon-svg.js ***!
  \****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);



var IconSVG = function IconSVG(props) {
  var icon = props.icon,
      onClick = props.onClick;
  var classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()('jnews-svg', (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, "jnews-svg-".concat(icon), icon));
  return /*#__PURE__*/React.createElement("i", {
    className: classes,
    onClick: onClick
  });
};

/* harmony default export */ __webpack_exports__["default"] = (IconSVG);

/***/ }),

/***/ "./src/jnews/src/icon/icon-wrapper.js":
/*!********************************************!*\
  !*** ./src/jnews/src/icon/icon-wrapper.js ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _icon_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./icon-svg */ "./src/jnews/src/icon/icon-svg.js");




var IconWrapper = function IconWrapper(props) {
  var _classNames;

  var icon = props.icon,
      fillCircle = props.fillCircle,
      type = props.type,
      noMargin = props.noMargin,
      closeButton = props.closeButton,
      onClick = props.onClick;
  var classes = classnames__WEBPACK_IMPORTED_MODULE_1___default()('jnews-svg-wrapper', (_classNames = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "jnews-svg-wrapper-circle", fillCircle), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "jnews-svg-wrapper-".concat(type), fillCircle && type), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "jnews-svg-type-".concat(type), !fillCircle && type), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "jnews-svg-wrapper-no-margin", noMargin), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "jnews-svg-wrapper-close-button", closeButton), _classNames));
  return /*#__PURE__*/React.createElement("span", {
    className: classes
  }, /*#__PURE__*/React.createElement(_icon_svg__WEBPACK_IMPORTED_MODULE_2__["default"], {
    icon: icon,
    onClick: onClick
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (IconWrapper);

/***/ }),

/***/ "./src/jnews/src/navigation/navigation-item.js":
/*!*****************************************************!*\
  !*** ./src/jnews/src/navigation/navigation-item.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _util_dom_translate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/dom-translate */ "./src/jnews/src/util/dom-translate.js");
/* harmony import */ var _icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../icon/icon-wrapper */ "./src/jnews/src/icon/icon-wrapper.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! umbrellajs */ "./node_modules/umbrellajs/umbrella.min.js");
/* harmony import */ var umbrellajs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(umbrellajs__WEBPACK_IMPORTED_MODULE_6__);








var isCurrentActive = function isCurrentActive(name, menus) {
  var parent = [name];

  if (menus) {
    menus.map(function (menu) {
      parent.push(menu.name);

      if (menu.menus) {
        parent.push.apply(parent, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__["default"])(isCurrentActive(name, menu.menus)));
      }
    });
  }

  return parent;
};
/**
 * Menu Item Icon
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var MenuIcon = function MenuIcon(props) {
  var menu = props.menu;
  var iconType = menu.icon ? menu.icon.includes('font-awesome:') : false;
  var icon = menu.icon ? menu.icon.replace('font-awesome:', 'fa ') : '';

  if ('' !== menu.icon && 'undefined' !== typeof menu.icon) {
    if (iconType) {
      return /*#__PURE__*/React.createElement("i", {
        className: "".concat(icon)
      });
    }

    return /*#__PURE__*/React.createElement(_icon_icon_wrapper__WEBPACK_IMPORTED_MODULE_4__["default"], {
      icon: "".concat(icon),
      fillCircle: false
    });
  }

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_5__.Fragment, null);
};

var MenuBadge = function MenuBadge(props) {
  var menu = props.menu;

  if ('' !== menu.badge && 'undefined' !== typeof menu.badge) {
    return /*#__PURE__*/React.createElement("div", {
      className: "menu-badge"
    }, /*#__PURE__*/React.createElement("span", null, menu.badge));
  }

  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_5__.Fragment, null);
};
/**
 * Navigation Item
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var NavigationItem = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_5__.forwardRef)(function (props, menuRef) {
  var _classNames;

  var menu = props.menu,
      currentMenu = props.currentMenu,
      setCurrentMenu = props.setCurrentMenu,
      currentHover = props.currentHover,
      setCurrentHover = props.setCurrentHover,
      timerRef = props.timerRef,
      loading = props.loading,
      showItemNumber = props.showItemNumber,
      itemIndex = props.itemIndex,
      showItemProgress = props.showItemProgress,
      passed = props.passed,
      setActiveItemIndex = props.setActiveItemIndex;
  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(function () {
    if (showItemProgress) {
      if (menu.name === currentMenu) {
        setActiveItemIndex(itemIndex);
      }
    }
  }, [currentMenu]);

  var onNavigationItemClick = function onNavigationItemClick(e, menu) {
    e.preventDefault();

    if (!loading) {
      if (menu.menus && menu.type === 'dropdown') {
        if (!menu.menus[0].dropdown_item) {
          setCurrentMenu(menu.name);
        }

        clearTimeout(timerRef.current);
        setCurrentHover(menuRef.current.dataset.menu);
      } else {
        setCurrentMenu(menu.name);
      }
    }
  };

  var classes = classnames__WEBPACK_IMPORTED_MODULE_2___default()('menus-item', (_classNames = {}, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "menus-current-menu-item", currentMenu === menu.name || isCurrentActive(menu.name, menu.menus).indexOf(currentMenu) > -1), (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_classNames, "passed", passed), _classNames));

  var mouseEnterHandler = function mouseEnterHandler(event) {
    clearTimeout(timerRef.current);
    setCurrentHover(menuRef.current.dataset.menu);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(function () {
    if (isCurrentActive(menu.name, menu.menus).indexOf(currentHover) > -1) {
      if ('undefined' !== typeof menu.menus) {
        var handleClickMenuOutside = function handleClickMenuOutside(event) {
          if (menuRef.current) {
            if (umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()(event.target).closest('[data-parent="' + menuRef.current.dataset.menu + '"]').length < 1 && umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()(event.target).closest('[data-menu="' + menuRef.current.dataset.menu + '"]').length < 1) {
              setCurrentHover(false);
            }
          }
        };

        var handleOverMenuOutside = function handleOverMenuOutside(event) {
          if (event.target) {
            if (umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()(event.target).closest('[data-parent="' + menuRef.current.dataset.menu + '"]').length < 1 && umbrellajs__WEBPACK_IMPORTED_MODULE_6___default()(event.target).closest('[data-menu="' + menuRef.current.dataset.menu + '"]').length < 1) {
              timerRef.current = setTimeout(function () {
                setCurrentHover(false);
              }, 'touchstart' !== event.type ? 200 : 0);
            }
          }
        };

        document.addEventListener('mouseover', handleOverMenuOutside);
        document.addEventListener('touchstart', handleOverMenuOutside);
        document.addEventListener('mousedown', handleClickMenuOutside);
        return function () {
          document.removeEventListener('mouseover', handleOverMenuOutside);
          document.removeEventListener('touchstart', handleOverMenuOutside);
          document.removeEventListener('mousedown', handleClickMenuOutside);
        };
      }
    }
  }, [menuRef, currentHover, currentMenu]);
  return /*#__PURE__*/React.createElement("li", {
    ref: menuRef,
    className: classes,
    "data-menu": menu.name,
    onMouseEnter: mouseEnterHandler,
    onClick: function onClick(e) {
      return onNavigationItemClick(e, menu);
    }
  }, showItemNumber && /*#__PURE__*/React.createElement("span", {
    className: "menus-item-number"
  }, itemIndex), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "menus-item-goto",
    "data-key": menu.name
  }, /*#__PURE__*/React.createElement(MenuIcon, {
    menu: menu
  }), " ", /*#__PURE__*/React.createElement("span", null, (0,_util_dom_translate__WEBPACK_IMPORTED_MODULE_3__["default"])(menu.title)), " ", /*#__PURE__*/React.createElement(MenuBadge, {
    menu: menu
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (NavigationItem);

/***/ }),

/***/ "./src/jnews/src/navigation/navigation-menu.js":
/*!*****************************************************!*\
  !*** ./src/jnews/src/navigation/navigation-menu.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _navigation_item__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navigation-item */ "./src/jnews/src/navigation/navigation-item.js");


/**
 * Navigation level
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var NavigationMenu = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(function (props, menuRef) {
  var menus = props.menus,
      currentMenu = props.currentMenu,
      setCurrentMenu = props.setCurrentMenu,
      currentHover = props.currentHover,
      setCurrentHover = props.setCurrentHover,
      timerRef = props.timerRef,
      loading = props.loading,
      showItemNumber = props.showItemNumber,
      showItemProgress = props.showItemProgress,
      activeItemIndex = props.activeItemIndex,
      setActiveItemIndex = props.setActiveItemIndex;
  var menuItem = menus.map(function (menu, index) {
    menuRef.current[menu.name] = menuRef.current[menu.name] || /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createRef)();
    return /*#__PURE__*/React.createElement(_navigation_item__WEBPACK_IMPORTED_MODULE_1__["default"], {
      timerRef: timerRef,
      menu: menu,
      currentMenu: currentMenu,
      setCurrentMenu: setCurrentMenu,
      currentHover: currentHover,
      setCurrentHover: setCurrentHover,
      loading: loading,
      ref: menuRef.current[menu.name],
      showItemNumber: showItemNumber,
      itemIndex: index + 1,
      showItemProgress: showItemProgress,
      passed: showItemProgress && index < activeItemIndex - 1,
      setActiveItemIndex: setActiveItemIndex
    });
  });
  return /*#__PURE__*/React.createElement("ul", {
    className: "menus"
  }, menuItem);
});
/* harmony default export */ __webpack_exports__["default"] = (NavigationMenu);

/***/ }),

/***/ "./src/jnews/src/navigation/navigation-tab-child.js":
/*!**********************************************************!*\
  !*** ./src/jnews/src/navigation/navigation-tab-child.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./navigation */ "./src/jnews/src/navigation/navigation.js");




var isCurrentActive = function isCurrentActive(name, menus) {
  var parent = [name];

  if (menus) {
    menus.map(function (menu) {
      parent.push(menu.name);

      if (menu.menus) {
        parent.push.apply(parent, (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(isCurrentActive(name, menu.menus)));
      }
    });
  }

  return parent;
};
/**
 * Navigation Tab Child
 *
 * @param {object} props
 * @returns {JSX.Element}
 */


var NavigationTabChild = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(function (props, menuRef) {
  var menus = props.menus,
      currentMenu = props.currentMenu,
      setCurrentMenu = props.setCurrentMenu,
      currentHover = props.currentHover,
      setCurrentHover = props.setCurrentHover,
      loading = props.loading,
      timerRef = props.timerRef;
  return menus.map(function (menu) {
    if ('dropdown' === menu.type) {
      return menu.menus && isCurrentActive(menu.name, menu.menus).indexOf(currentHover) > -1 && /*#__PURE__*/React.createElement(_navigation__WEBPACK_IMPORTED_MODULE_2__["default"], {
        timerRef: timerRef,
        setCurrentMenu: setCurrentMenu,
        currentMenu: currentMenu,
        currentHover: currentHover,
        setCurrentHover: setCurrentHover,
        ref: menuRef,
        loading: loading,
        menus: menu.menus,
        child: true,
        type: menu.type,
        parent: menu.name
      });
    } else {
      return menu.menus && isCurrentActive(menu.name, menu.menus).indexOf(currentMenu) > -1 && /*#__PURE__*/React.createElement(_navigation__WEBPACK_IMPORTED_MODULE_2__["default"], {
        timerRef: timerRef,
        setCurrentMenu: setCurrentMenu,
        currentMenu: currentMenu,
        currentHover: currentHover,
        setCurrentHover: setCurrentHover,
        ref: menuRef,
        loading: loading,
        menus: menu.menus,
        child: true,
        type: menu.type,
        parent: menu.name
      });
    }
  });
});
/* harmony default export */ __webpack_exports__["default"] = (NavigationTabChild);

/***/ }),

/***/ "./src/jnews/src/navigation/navigation-wrapper.js":
/*!********************************************************!*\
  !*** ./src/jnews/src/navigation/navigation-wrapper.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _util_library__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/library */ "./src/jnews/src/util/library.js");




/**
 * Navigation Wrapper
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var NavigationWrapper = function NavigationWrapper(props) {
  var setWrapperWidth = props.setWrapperWidth,
      setInnerWidth = props.setInnerWidth,
      setInnerLeftWidth = props.setInnerLeftWidth,
      setInnerRightWidth = props.setInnerRightWidth,
      className = props.className,
      additionalClass = props.additionalClass,
      scrollable = props.scrollable,
      menuRef = props.menuRef,
      type = props.type,
      parent = props.parent;
  var ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
  var wrapperClass = 'wrapper';

  if ('undefined' !== typeof className) {
    wrapperClass += '-' + className;
  }

  var classes = classnames__WEBPACK_IMPORTED_MODULE_2___default()(wrapperClass, (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({
    scrollable: scrollable
  }, "".concat(type), type), additionalClass);
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    var showWidth = function showWidth() {
      if ('undefined' !== typeof setWrapperWidth) {
        setWrapperWidth((0,_util_library__WEBPACK_IMPORTED_MODULE_3__.getWidth)(ref.current));
      }

      if ('undefined' !== typeof setInnerWidth) {
        setInnerWidth((0,_util_library__WEBPACK_IMPORTED_MODULE_3__.getWidth)(ref.current));
      }

      if ('left' === className) {
        if ('undefined' !== typeof setInnerLeftWidth) {
          setInnerLeftWidth((0,_util_library__WEBPACK_IMPORTED_MODULE_3__.getWidth)(ref.current));
        }
      }

      if ('right' === className) {
        if ('undefined' !== typeof setInnerRightWidth) {
          setInnerRightWidth((0,_util_library__WEBPACK_IMPORTED_MODULE_3__.getWidth)(ref.current));
        }
      }
    };

    var resizeEvent = {
      resize: showWidth
    };
    showWidth();
    (0,_util_library__WEBPACK_IMPORTED_MODULE_3__.addEvents)(window, resizeEvent);
    return function () {
      return (0,_util_library__WEBPACK_IMPORTED_MODULE_3__.removeEvents)(window, resizeEvent);
    };
  });
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    if (parent && 'dropdown' === type) {
      if (ref.current.style.top === '') {
        var getPosition = function getPosition(el) {
          var xPos = 0;
          var yPos = 0;
          xPos += el.offsetLeft - el.scrollLeft + el.clientLeft;
          yPos += el.offsetTop - el.scrollTop + el.clientTop + el.offsetHeight;
          return {
            x: xPos,
            y: yPos
          };
        };

        var position = getPosition(menuRef.current[parent].current);
        ref.current.style.top = position.y + 'px';
        ref.current.style.left = position.x + 'px';
      }
    }
  }, [menuRef, scrollable]);
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: classes,
    "data-parent": parent
  }, props.children);
};

/* harmony default export */ __webpack_exports__["default"] = (NavigationWrapper);

/***/ }),

/***/ "./src/jnews/src/navigation/navigation.js":
/*!************************************************!*\
  !*** ./src/jnews/src/navigation/navigation.js ***!
  \************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./navigation-wrapper */ "./src/jnews/src/navigation/navigation-wrapper.js");
/* harmony import */ var _util_library__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util/library */ "./src/jnews/src/util/library.js");
/* harmony import */ var _navigation_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./navigation-menu */ "./src/jnews/src/navigation/navigation-menu.js");
/* harmony import */ var _navigation_tab_child__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./navigation-tab-child */ "./src/jnews/src/navigation/navigation-tab-child.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! classnames */ "../node_modules/classnames/index.js");
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);








/**
 * Navigation
 *
 * @param {object} props
 * @returns {JSX.Element}
 */

var Navigation = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.forwardRef)(function (props, currentMenuRef) {
  var menus = props.menus,
      currentMenu = props.currentMenu,
      setCurrentMenu = props.setCurrentMenu,
      hover = props.currentHover,
      setHover = props.setCurrentHover,
      loading = props.loading,
      child = props.child,
      type = props.type,
      parent = props.parent,
      timerRef = props.timerRef,
      rightMenu = props.rightMenu,
      customClass = props.customClass,
      showItemNumber = props.showItemNumber,
      showItemProgress = props.showItemProgress;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      scrollable = _useState2[0],
      setScrollable = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(undefined),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState3, 2),
      wrapperWidth = _useState4[0],
      setWrapperWidth = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(undefined),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState5, 2),
      innerWidth = _useState6[0],
      setInnerWidth = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(undefined),
      _useState8 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState7, 2),
      innerLeftWidth = _useState8[0],
      setInnerLeftWidth = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(undefined),
      _useState10 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState9, 2),
      innerRightWidth = _useState10[0],
      setInnerRightWidth = _useState10[1];

  var _useState11 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState12 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState11, 2),
      currentHover = _useState12[0],
      setCurrentHover = _useState12[1];

  var _useState13 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false),
      _useState14 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState13, 2),
      activeItemIndex = _useState14[0],
      setActiveItemIndex = _useState14[1];

  var menuRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)([]);
  var classes = classnames__WEBPACK_IMPORTED_MODULE_7___default()((0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({
    left_right: rightMenu
  }, "".concat(customClass), customClass));
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    var updateScrollable = _util_library__WEBPACK_IMPORTED_MODULE_4__.requestAnimationFrame.call(window, function () {
      if (innerWidth > wrapperWidth) {
        setScrollable(true);
      } else {
        if (scrollable) {
          if ('undefined' !== typeof innerLeftWidth && 'undefined' !== typeof innerRightWidth) {
            if (innerLeftWidth > innerWidth && innerLeftWidth + innerRightWidth > wrapperWidth) {
              setScrollable(true);
            } else {
              if (innerLeftWidth <= innerWidth && innerWidth - innerLeftWidth < 279) {
                setScrollable(true);
              } else {
                setScrollable(false);
              }
            }
          } else {
            setScrollable(false);
          }
        }
      }
    });
    return function () {
      _util_library__WEBPACK_IMPORTED_MODULE_4__.cancelAnimationFrame.call(window, updateScrollable);
    };
  }, [wrapperWidth, innerWidth]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, !child && /*#__PURE__*/React.createElement("div", {
    className: "jnews-navigation"
  }, /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    additionalClass: classes,
    className: child ? 'child' : undefined,
    scrollable: scrollable,
    setWrapperWidth: setWrapperWidth,
    type: type,
    parent: parent,
    menuRef: null !== currentMenuRef ? currentMenuRef : menuRef
  }, rightMenu && /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "inner",
    setInnerWidth: setInnerWidth
  }, /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "left",
    setInnerWidth: setInnerWidth,
    setInnerLeftWidth: setInnerLeftWidth
  }, /*#__PURE__*/React.createElement(_navigation_menu__WEBPACK_IMPORTED_MODULE_5__["default"], {
    timerRef: timerRef,
    menus: menus,
    currentMenu: currentMenu,
    setCurrentMenu: setCurrentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    showItemProgress: showItemProgress,
    activeItemIndex: activeItemIndex,
    setActiveItemIndex: setActiveItemIndex
  })), /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "right",
    setInnerWidth: setInnerWidth,
    setInnerRightWidth: setInnerRightWidth
  }, rightMenu())), !rightMenu && /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "inner",
    setInnerWidth: setInnerWidth
  }, /*#__PURE__*/React.createElement(_navigation_menu__WEBPACK_IMPORTED_MODULE_5__["default"], {
    timerRef: timerRef,
    menus: menus,
    currentMenu: currentMenu,
    setCurrentMenu: setCurrentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    showItemNumber: showItemNumber,
    showItemProgress: showItemProgress,
    activeItemIndex: activeItemIndex,
    setActiveItemIndex: setActiveItemIndex
  }))), /*#__PURE__*/React.createElement(_navigation_tab_child__WEBPACK_IMPORTED_MODULE_6__["default"], {
    timerRef: timerRef,
    setCurrentMenu: setCurrentMenu,
    currentMenu: currentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    menus: menus,
    type: type ? type : undefined,
    parent: parent
  })), child && /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    additionalClass: classes,
    className: child ? 'child' : undefined,
    scrollable: scrollable,
    setWrapperWidth: setWrapperWidth,
    type: type,
    parent: parent,
    menuRef: null !== currentMenuRef ? currentMenuRef : menuRef
  }, rightMenu && /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "inner",
    setInnerWidth: setInnerWidth
  }, /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "left",
    setInnerWidth: setInnerWidth,
    setInnerLeftWidth: setInnerLeftWidth
  }, /*#__PURE__*/React.createElement(_navigation_menu__WEBPACK_IMPORTED_MODULE_5__["default"], {
    timerRef: timerRef,
    menus: menus,
    currentMenu: currentMenu,
    setCurrentMenu: setCurrentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    showItemProgress: showItemProgress,
    activeItemIndex: activeItemIndex,
    setActiveItemIndex: setActiveItemIndex
  })), /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "right",
    setInnerWidth: setInnerWidth,
    setInnerRightWidth: setInnerRightWidth
  }, rightMenu())), !rightMenu && /*#__PURE__*/React.createElement(_navigation_wrapper__WEBPACK_IMPORTED_MODULE_3__["default"], {
    className: "inner",
    setInnerWidth: setInnerWidth
  }, /*#__PURE__*/React.createElement(_navigation_menu__WEBPACK_IMPORTED_MODULE_5__["default"], {
    timerRef: timerRef,
    menus: menus,
    currentMenu: currentMenu,
    setCurrentMenu: setCurrentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    showItemProgress: showItemProgress,
    activeItemIndex: activeItemIndex,
    setActiveItemIndex: setActiveItemIndex
  }))), /*#__PURE__*/React.createElement(_navigation_tab_child__WEBPACK_IMPORTED_MODULE_6__["default"], {
    timerRef: timerRef,
    setCurrentMenu: setCurrentMenu,
    currentMenu: currentMenu,
    currentHover: 'undefined' !== typeof hover ? hover : currentHover,
    setCurrentHover: 'undefined' !== typeof hover ? setHover : setCurrentHover,
    ref: null !== currentMenuRef ? currentMenuRef : menuRef,
    loading: loading,
    menus: menus,
    type: type ? type : undefined,
    parent: parent
  })));
});
/* harmony default export */ __webpack_exports__["default"] = (Navigation);

/***/ }),

/***/ "./src/jnews/src/util/axios.js":
/*!*************************************!*\
  !*** ./src/jnews/src/util/axios.js ***!
  \*************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "checkPluginRemote": function() { return /* binding */ checkPluginRemote; },
/* harmony export */   "deletePagespeedReportTransient": function() { return /* binding */ deletePagespeedReportTransient; },
/* harmony export */   "easyPluginsOptions": function() { return /* binding */ easyPluginsOptions; },
/* harmony export */   "exportPanelOptions": function() { return /* binding */ exportPanelOptions; },
/* harmony export */   "getActiveElements": function() { return /* binding */ getActiveElements; },
/* harmony export */   "getDashboardConfig": function() { return /* binding */ getDashboardConfig; },
/* harmony export */   "getDemoConfig": function() { return /* binding */ getDemoConfig; },
/* harmony export */   "getDemoContent": function() { return /* binding */ getDemoContent; },
/* harmony export */   "getDemoList": function() { return /* binding */ getDemoList; },
/* harmony export */   "getDemoScheme": function() { return /* binding */ getDemoScheme; },
/* harmony export */   "getJnewsElements": function() { return /* binding */ getJnewsElements; },
/* harmony export */   "getOptimizationPluginsControls": function() { return /* binding */ getOptimizationPluginsControls; },
/* harmony export */   "getPageSpeedReport": function() { return /* binding */ getPageSpeedReport; },
/* harmony export */   "getPageSpeedReportTesting": function() { return /* binding */ getPageSpeedReportTesting; },
/* harmony export */   "getPerformanceMode": function() { return /* binding */ getPerformanceMode; },
/* harmony export */   "getPerformanceOptions": function() { return /* binding */ getPerformanceOptions; },
/* harmony export */   "getPluginFile": function() { return /* binding */ getPluginFile; },
/* harmony export */   "getPlugins": function() { return /* binding */ getPlugins; },
/* harmony export */   "getPublishedPages": function() { return /* binding */ getPublishedPages; },
/* harmony export */   "httpClientServer": function() { return /* binding */ httpClientServer; },
/* harmony export */   "importPanelOptions": function() { return /* binding */ importPanelOptions; },
/* harmony export */   "manageDemo": function() { return /* binding */ manageDemo; },
/* harmony export */   "managePlugin": function() { return /* binding */ managePlugin; },
/* harmony export */   "restorePanelOptions": function() { return /* binding */ restorePanelOptions; },
/* harmony export */   "savePanelOptions": function() { return /* binding */ savePanelOptions; },
/* harmony export */   "updateEasyPluginOptions": function() { return /* binding */ updateEasyPluginOptions; },
/* harmony export */   "updateJNewsModules": function() { return /* binding */ updateJNewsModules; },
/* harmony export */   "updateOptimizationPlugins": function() { return /* binding */ updateOptimizationPlugins; },
/* harmony export */   "updatePagesImageLoad": function() { return /* binding */ updatePagesImageLoad; },
/* harmony export */   "updatePagespeedReportTransient": function() { return /* binding */ updatePagespeedReportTransient; },
/* harmony export */   "updatePerformanceMode": function() { return /* binding */ updatePerformanceMode; },
/* harmony export */   "updatePerformanceOptions": function() { return /* binding */ updatePerformanceOptions; },
/* harmony export */   "validateLicense": function() { return /* binding */ validateLicense; },
/* harmony export */   "validatePlugin": function() { return /* binding */ validatePlugin; }
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/api-fetch */ "@wordpress/api-fetch");
/* harmony import */ var _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "./src/jnews/src/config.js");




function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}




var httpClientServer = (0,axios__WEBPACK_IMPORTED_MODULE_4__.create)({
  baseURL: _config__WEBPACK_IMPORTED_MODULE_5__.JNewsServerURL + '/wp-json/' + 'jnews-server/v1'
});
var validateLicense = function validateLicense(params) {
  return new Promise(function (resolve, reject) {
    httpClientServer.post('/validateLicense', params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getDashboardConfig = function getDashboardConfig(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/getDashboardConfig',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getPlugins = function getPlugins(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/getPlugins',
      method: 'POST',
      data: params
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getDemoList = function getDemoList(params) {
  return new Promise(function (resolve, reject) {
    httpClientServer.post('/getDemoList', params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getDemoConfig = function getDemoConfig(params) {
  return new Promise(function (resolve, reject) {
    httpClientServer.post('/getDemoConfig', params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error.response.data);
    });
  });
};
var getDemoContent = function getDemoContent(params) {
  return new Promise(function (resolve, reject) {
    httpClientServer.post('/getDemoContent', params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error.response.data);
    });
  });
};
var getDemoScheme = function getDemoScheme(params) {
  return new Promise(function (resolve, reject) {
    httpClientServer.post('/getDemoScheme', params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error.response.data);
    });
  });
};
var manageDemo = /*#__PURE__*/function () {
  var _ref = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/manageDemo',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function manageDemo(_x) {
    return _ref.apply(this, arguments);
  };
}();
var checkPluginRemote = /*#__PURE__*/function () {
  var _ref2 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/checkPluginRemote',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI,
                  theme_version: _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.parentVersion ? _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.parentVersion : _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.version
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function checkPluginRemote(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var managePlugin = /*#__PURE__*/function () {
  var _ref3 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            return _context3.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/managePlugin',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI,
                  theme_version: _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.parentVersion ? _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.parentVersion : _config__WEBPACK_IMPORTED_MODULE_5__.themeInfo.version
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));

  return function managePlugin(_x3) {
    return _ref3.apply(this, arguments);
  };
}();
var validatePlugin = /*#__PURE__*/function () {
  var _ref4 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            return _context4.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/validatePlugin',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));

  return function validatePlugin(_x4) {
    return _ref4.apply(this, arguments);
  };
}();
var savePanelOptions = /*#__PURE__*/function () {
  var _ref5 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context5) {
      while (1) {
        switch (_context5.prev = _context5.next) {
          case 0:
            return _context5.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/savePanelOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context5.stop();
        }
      }
    }, _callee5);
  }));

  return function savePanelOptions(_x5) {
    return _ref5.apply(this, arguments);
  };
}();
var restorePanelOptions = /*#__PURE__*/function () {
  var _ref6 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee6(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee6$(_context6) {
      while (1) {
        switch (_context6.prev = _context6.next) {
          case 0:
            return _context6.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/restorePanelOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context6.stop();
        }
      }
    }, _callee6);
  }));

  return function restorePanelOptions(_x6) {
    return _ref6.apply(this, arguments);
  };
}();
var importPanelOptions = /*#__PURE__*/function () {
  var _ref7 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee7(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee7$(_context7) {
      while (1) {
        switch (_context7.prev = _context7.next) {
          case 0:
            return _context7.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/importPanelOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context7.stop();
        }
      }
    }, _callee7);
  }));

  return function importPanelOptions(_x7) {
    return _ref7.apply(this, arguments);
  };
}();
var exportPanelOptions = /*#__PURE__*/function () {
  var _ref8 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee8(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee8$(_context8) {
      while (1) {
        switch (_context8.prev = _context8.next) {
          case 0:
            return _context8.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/exportPanelOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context8.stop();
        }
      }
    }, _callee8);
  }));

  return function exportPanelOptions(_x8) {
    return _ref8.apply(this, arguments);
  };
}();
var getOptimizationPluginsControls = /*#__PURE__*/function () {
  var _ref9 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee9(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee9$(_context9) {
      while (1) {
        switch (_context9.prev = _context9.next) {
          case 0:
            return _context9.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/getOptimizationPluginsControls',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context9.stop();
        }
      }
    }, _callee9);
  }));

  return function getOptimizationPluginsControls(_x9) {
    return _ref9.apply(this, arguments);
  };
}();
var getPluginFile = /*#__PURE__*/function () {
  var _ref10 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee10(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee10$(_context10) {
      while (1) {
        switch (_context10.prev = _context10.next) {
          case 0:
            return _context10.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/getPluginFile',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context10.stop();
        }
      }
    }, _callee10);
  }));

  return function getPluginFile(_x10) {
    return _ref10.apply(this, arguments);
  };
}();
var getPerformanceOptions = /*#__PURE__*/function () {
  var _ref11 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee11(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee11$(_context11) {
      while (1) {
        switch (_context11.prev = _context11.next) {
          case 0:
            return _context11.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/getPerformanceOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context11.stop();
        }
      }
    }, _callee11);
  }));

  return function getPerformanceOptions(_x11) {
    return _ref11.apply(this, arguments);
  };
}();
var updateOptimizationPlugins = /*#__PURE__*/function () {
  var _ref12 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee12(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee12$(_context12) {
      while (1) {
        switch (_context12.prev = _context12.next) {
          case 0:
            return _context12.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/updateOptimizationPlugins',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context12.stop();
        }
      }
    }, _callee12);
  }));

  return function updateOptimizationPlugins(_x12) {
    return _ref12.apply(this, arguments);
  };
}();
var updatePerformanceOptions = /*#__PURE__*/function () {
  var _ref13 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee13(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee13$(_context13) {
      while (1) {
        switch (_context13.prev = _context13.next) {
          case 0:
            return _context13.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/updatePerformanceOptions',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context13.stop();
        }
      }
    }, _callee13);
  }));

  return function updatePerformanceOptions(_x13) {
    return _ref13.apply(this, arguments);
  };
}();
var getPublishedPages = /*#__PURE__*/function () {
  var _ref14 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee14(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee14$(_context14) {
      while (1) {
        switch (_context14.prev = _context14.next) {
          case 0:
            return _context14.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/getPublishedPages',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context14.stop();
        }
      }
    }, _callee14);
  }));

  return function getPublishedPages(_x14) {
    return _ref14.apply(this, arguments);
  };
}();
var getPageSpeedReport = function getPageSpeedReport(params) {
  return new Promise(function (resolve, reject) {
    (0,axios__WEBPACK_IMPORTED_MODULE_4__.create)({
      baseURL: 'https://www.googleapis.com'
    }).get('/pagespeedonline/v5/runPagespeed?url=' + params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var updatePagesImageLoad = /*#__PURE__*/function () {
  var _ref15 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee15(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee15$(_context15) {
      while (1) {
        switch (_context15.prev = _context15.next) {
          case 0:
            return _context15.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/updatePagesImageLoad',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context15.stop();
        }
      }
    }, _callee15);
  }));

  return function updatePagesImageLoad(_x15) {
    return _ref15.apply(this, arguments);
  };
}();
var updatePagespeedReportTransient = /*#__PURE__*/function () {
  var _ref16 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee16(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee16$(_context16) {
      while (1) {
        switch (_context16.prev = _context16.next) {
          case 0:
            return _context16.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/updatePagespeedReportTransient',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context16.stop();
        }
      }
    }, _callee16);
  }));

  return function updatePagespeedReportTransient(_x16) {
    return _ref16.apply(this, arguments);
  };
}();
var deletePagespeedReportTransient = /*#__PURE__*/function () {
  var _ref17 = (0,_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee17(params) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee17$(_context17) {
      while (1) {
        switch (_context17.prev = _context17.next) {
          case 0:
            return _context17.abrupt("return", new Promise(function (resolve, reject) {
              _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
                path: 'jnews/v1/deletePagespeedReportTransient',
                method: 'POST',
                data: _objectSpread({
                  nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
                }, params)
              }).then(function (response) {
                resolve(response);
              })["catch"](function (error) {
                reject(error);
              });
            }));

          case 1:
          case "end":
            return _context17.stop();
        }
      }
    }, _callee17);
  }));

  return function deletePagespeedReportTransient(_x17) {
    return _ref17.apply(this, arguments);
  };
}();
var getPageSpeedReportTesting = function getPageSpeedReportTesting(params) {
  return new Promise(function (resolve, reject) {
    (0,axios__WEBPACK_IMPORTED_MODULE_4__.create)({
      baseURL: 'http://localhost:3000'
    }).get('/pagespeedonline/v5/runPagespeed?url=' + params).then(function (response) {
      if (response.status === 200) {
        resolve(response.data);
      } else {
        reject(response.statusText);
      }
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getJnewsElements = function getJnewsElements(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/getJnewsElements',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var updateJNewsModules = function updateJNewsModules(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/updateJNewsModules',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getActiveElements = function getActiveElements(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/getActiveElements',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var getPerformanceMode = function getPerformanceMode(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/getPerformanceMode',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var updatePerformanceMode = function updatePerformanceMode(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/updatePerformanceMode',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var easyPluginsOptions = function easyPluginsOptions(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/easyPluginsOptions',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};
var updateEasyPluginOptions = function updateEasyPluginOptions(params) {
  return new Promise(function (resolve, reject) {
    _wordpress_api_fetch__WEBPACK_IMPORTED_MODULE_3___default()({
      path: 'jnews/v1/updateEasyPluginOptions',
      method: 'POST',
      data: _objectSpread({
        nonce: _config__WEBPACK_IMPORTED_MODULE_5__.nonceAPI
      }, params)
    }).then(function (response) {
      resolve(response);
    })["catch"](function (error) {
      reject(error);
    });
  });
};

/***/ }),

/***/ "./src/jnews/src/util/current-url.js":
/*!*******************************************!*\
  !*** ./src/jnews/src/util/current-url.js ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Current URL
 */
var currentURL = function currentURL() {
  var locationURL = new URL(window.location.href);
  window.JNewsDashboard['currentLocation'] = window.JNewsDashboard['currentLocation'] || {};
  var currentLocation = window.JNewsDashboard['currentLocation'];
  var urlCategory = locationURL.searchParams.get('category');
  var urlDashboardPage = locationURL.searchParams.get('page');
  var urlDashboardPath = locationURL.searchParams.get('path');

  if (locationURL.searchParams.get('access_token') !== null || locationURL.searchParams.get('refresh_token') !== null || locationURL.searchParams.get('purchase_code') !== null || locationURL.searchParams.get('action') !== null) {
    locationURL.searchParams["delete"]('access_token');
    locationURL.searchParams["delete"]('refresh_token');
    locationURL.searchParams["delete"]('purchase_code');
    locationURL.searchParams["delete"]('action');
  }

  if (!currentLocation) {
    if (urlCategory) {
      currentLocation.category = urlCategory.split(',');
    }

    if (urlDashboardPath) {
      currentLocation.path = urlDashboardPath;
    }

    if (urlDashboardPage) {
      currentLocation.page = urlDashboardPage;
    }
  }

  if (locationURL) {
    if (currentLocation.page) {
      locationURL.searchParams.set('page', currentLocation.page);
    } else {
      locationURL.searchParams["delete"]('page');
    }

    if (currentLocation.path) {
      locationURL.searchParams.set('path', currentLocation.path);
    } else {
      locationURL.searchParams["delete"]('path');
    }

    if ('jnews_plugin' === currentLocation.path && currentLocation.category) {
      locationURL.searchParams.set('category', currentLocation.category);
    } else {
      locationURL.searchParams["delete"]('category');
    }

    window.history.replaceState(null, null, locationURL);
  }
};

/* harmony default export */ __webpack_exports__["default"] = (currentURL);

/***/ }),

/***/ "./src/jnews/src/util/dom-translate.js":
/*!*********************************************!*\
  !*** ./src/jnews/src/util/dom-translate.js ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! html-react-parser */ "./node_modules/html-react-parser/index.mjs");

/**
 * 
 * @param {string} content 
 * @returns {JSX.Element|array|string}
 */

var DomTranslate = function DomTranslate(content) {
  return (0,html_react_parser__WEBPACK_IMPORTED_MODULE_0__["default"])(content);
};

/* harmony default export */ __webpack_exports__["default"] = (DomTranslate);

/***/ }),

/***/ "./src/jnews/src/util/esc-listener.js":
/*!********************************************!*\
  !*** ./src/jnews/src/util/esc-listener.js ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Esc Listener
 * 
 * @param {Function} param0 
 * @returns {null}
 */

var EscListener = function EscListener(_ref) {
  var execute = _ref.execute;

  var escFunction = function escFunction(event) {
    if (event.keyCode === 27) {
      execute();
    }
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    document.addEventListener('keydown', escFunction, false);
    return function () {
      document.removeEventListener('keydown', escFunction, false);
    };
  }, []);
  return null;
};

/* harmony default export */ __webpack_exports__["default"] = (EscListener);

/***/ }),

/***/ "./src/jnews/src/util/library.js":
/*!***************************************!*\
  !*** ./src/jnews/src/util/library.js ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addEvents": function() { return /* binding */ addEvents; },
/* harmony export */   "cancelAnimationFrame": function() { return /* binding */ cancelAnimationFrame; },
/* harmony export */   "docReady": function() { return /* binding */ docReady; },
/* harmony export */   "getParents": function() { return /* binding */ getParents; },
/* harmony export */   "getWidth": function() { return /* binding */ getWidth; },
/* harmony export */   "removeEvents": function() { return /* binding */ removeEvents; },
/* harmony export */   "requestAnimationFrame": function() { return /* binding */ requestAnimationFrame; },
/* harmony export */   "windowWidth": function() { return /* binding */ windowWidth; }
/* harmony export */ });
var _window$jnews$library = window['jnews']['library'],
    addEvents = _window$jnews$library.addEvents,
    removeEvents = _window$jnews$library.removeEvents,
    getWidth = _window$jnews$library.getWidth,
    cancelAnimationFrame = _window$jnews$library.cancelAnimationFrame,
    requestAnimationFrame = _window$jnews$library.requestAnimationFrame,
    getParents = _window$jnews$library.getParents,
    windowWidth = _window$jnews$library.windowWidth,
    docReady = _window$jnews$library.docReady;


/***/ }),

/***/ "./src/jnews/src/util/pagination/pagination-next.js":
/*!**********************************************************!*\
  !*** ./src/jnews/src/util/pagination/pagination-next.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);


var PaginationNext = function PaginationNext(props) {
  var pageNow = props.pageNow,
      maxPages = props.maxPages,
      onClickPagination = props.onClickPagination;
  return pageNow && pageNow < maxPages && /*#__PURE__*/React.createElement("a", {
    "class": "page-nav next",
    "data-id": pageNow + 1,
    onClick: onClickPagination
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Next', '__text_domain__'));
};

/* harmony default export */ __webpack_exports__["default"] = (PaginationNext);

/***/ }),

/***/ "./src/jnews/src/util/pagination/pagination-number.js":
/*!************************************************************!*\
  !*** ./src/jnews/src/util/pagination/pagination-number.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




var PaginationNumber = function PaginationNumber(props) {
  var pageNow = props.pageNow,
      maxPages = props.maxPages,
      onClickPagination = props.onClickPagination;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_useState, 2),
      pageNumber = _useState2[0],
      setPageNumber = _useState2[1];

  var dots = false;
  (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(function () {
    setPageNumber([]);
    setPageNumber(function (prevState) {
      if (1 !== maxPages) {
        for (var i = 1; i <= maxPages; i++) {
          if (i === pageNow) {
            dots = true;
            prevState.push( /*#__PURE__*/React.createElement("span", {
              className: "page-number active"
            }, i));
          } else {
            if (i <= 1 || pageNow && i >= pageNow - 1 && i <= pageNow + 1 || i > maxPages - 1) {
              dots = true;
              prevState.push( /*#__PURE__*/React.createElement("a", {
                className: "page-number",
                "data-id": i,
                onClick: onClickPagination
              }, i));
            } else if (dots) {
              dots = false;
              prevState.push( /*#__PURE__*/React.createElement("span", {
                className: "page-number dots"
              }, "\u2026"));
            }
          }
        }
      }

      return (0,_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__["default"])(prevState);
    });
  }, [maxPages, pageNow]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_2__.Fragment, null, pageNumber);
};

/* harmony default export */ __webpack_exports__["default"] = (PaginationNumber);

/***/ }),

/***/ "./src/jnews/src/util/pagination/pagination-prev.js":
/*!**********************************************************!*\
  !*** ./src/jnews/src/util/pagination/pagination-prev.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);


var PaginationPrev = function PaginationPrev(props) {
  var pageNow = props.pageNow,
      onClickPagination = props.onClickPagination;
  return pageNow && 1 < pageNow && /*#__PURE__*/React.createElement("a", {
    "class": "page-nav prev",
    "data-id": pageNow - 1,
    onClick: onClickPagination
  }, (0,_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__.__)('Prev', '__text_domain__'));
};

/* harmony default export */ __webpack_exports__["default"] = (PaginationPrev);

/***/ }),

/***/ "./src/jnews/src/util/pagination/pagination.js":
/*!*****************************************************!*\
  !*** ./src/jnews/src/util/pagination/pagination.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pagination_next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pagination-next */ "./src/jnews/src/util/pagination/pagination-next.js");
/* harmony import */ var _pagination_number__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pagination-number */ "./src/jnews/src/util/pagination/pagination-number.js");
/* harmony import */ var _pagination_prev__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pagination-prev */ "./src/jnews/src/util/pagination/pagination-prev.js");






var chunk = function chunk(_ref) {
  var setMaxPages = _ref.setMaxPages,
      dataArr = _ref.dataArr,
      size = _ref.size;
  var maxPages = Math.ceil(dataArr.length / size);
  setMaxPages(maxPages);
  return Array.from({
    length: maxPages
  }, function (v, i) {
    return dataArr.slice(i * size, i * size + size);
  });
};

var Pagination = function Pagination(props) {
  var pagedData = props.pagedData,
      children = props.children,
      pages = props.pages;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
      _useState2 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState, 2),
      maxPages = _useState2[0],
      setMaxPages = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0),
      _useState4 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState3, 2),
      pageNow = _useState4[0],
      setPageNow = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]),
      _useState6 = (0,_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useState5, 2),
      pagedPaginations = _useState6[0],
      setPagedPaginations = _useState6[1];

  var onClickPagination = function onClickPagination(event) {
    event.preventDefault();
    setPageNow(parseInt(event.target.dataset.id) ? parseInt(event.target.dataset.id) : 1);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function () {
    setPageNow(1);
    setPagedPaginations(chunk({
      setMaxPages: setMaxPages,
      dataArr: pagedData,
      size: pages ? pages : 10
    }));
  }, [pagedData]);
  return /*#__PURE__*/React.createElement(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, null, children({
    pagedPaginations: pagedPaginations,
    pageNow: pageNow
  }), /*#__PURE__*/React.createElement("div", {
    "class": "jnews-dashboard-pagination-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    "class": "jnews-dashboard-pagination"
  }, /*#__PURE__*/React.createElement(_pagination_prev__WEBPACK_IMPORTED_MODULE_4__["default"], {
    pageNow: pageNow,
    onClickPagination: onClickPagination
  }), /*#__PURE__*/React.createElement(_pagination_number__WEBPACK_IMPORTED_MODULE_3__["default"], {
    pageNow: pageNow,
    maxPages: maxPages,
    onClickPagination: onClickPagination
  }), /*#__PURE__*/React.createElement(_pagination_next__WEBPACK_IMPORTED_MODULE_2__["default"], {
    pageNow: pageNow,
    maxPages: maxPages,
    onClickPagination: onClickPagination
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (Pagination);

/***/ }),

/***/ "./node_modules/html-dom-parser/lib/client/constants.js":
/*!**************************************************************!*\
  !*** ./node_modules/html-dom-parser/lib/client/constants.js ***!
  \**************************************************************/
/***/ (function(module) {

/**
 * SVG elements are case-sensitive.
 *
 * @see {@link https://developer.mozilla.org/docs/Web/SVG/Element#SVG_elements_A_to_Z}
 */
var CASE_SENSITIVE_TAG_NAMES = [
  'animateMotion',
  'animateTransform',
  'clipPath',
  'feBlend',
  'feColorMatrix',
  'feComponentTransfer',
  'feComposite',
  'feConvolveMatrix',
  'feDiffuseLighting',
  'feDisplacementMap',
  'feDropShadow',
  'feFlood',
  'feFuncA',
  'feFuncB',
  'feFuncG',
  'feFuncR',
  'feGaussainBlur',
  'feImage',
  'feMerge',
  'feMergeNode',
  'feMorphology',
  'feOffset',
  'fePointLight',
  'feSpecularLighting',
  'feSpotLight',
  'feTile',
  'feTurbulence',
  'foreignObject',
  'linearGradient',
  'radialGradient',
  'textPath'
];

module.exports = {
  CASE_SENSITIVE_TAG_NAMES: CASE_SENSITIVE_TAG_NAMES
};


/***/ }),

/***/ "./node_modules/html-dom-parser/lib/client/domparser.js":
/*!**************************************************************!*\
  !*** ./node_modules/html-dom-parser/lib/client/domparser.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

// constants
var HTML = 'html';
var HEAD = 'head';
var BODY = 'body';
var FIRST_TAG_REGEX = /<([a-zA-Z]+[0-9]?)/; // e.g., <h1>
var HEAD_TAG_REGEX = /<head.*>/i;
var BODY_TAG_REGEX = /<body.*>/i;

// falls back to `parseFromString` if `createHTMLDocument` cannot be used
var parseFromDocument = function () {
  throw new Error(
    'This browser does not support `document.implementation.createHTMLDocument`'
  );
};

var parseFromString = function () {
  throw new Error(
    'This browser does not support `DOMParser.prototype.parseFromString`'
  );
};

/**
 * DOMParser (performance: slow).
 *
 * @see https://developer.mozilla.org/docs/Web/API/DOMParser#Parsing_an_SVG_or_HTML_document
 */
if (typeof window.DOMParser === 'function') {
  var domParser = new window.DOMParser();
  var mimeType = 'text/html';

  /**
   * Creates an HTML document using `DOMParser.parseFromString`.
   *
   * @param  {string} html      - The HTML string.
   * @param  {string} [tagName] - The element to render the HTML (with 'body' as fallback).
   * @return {HTMLDocument}
   */
  parseFromString = function (html, tagName) {
    if (tagName) {
      html = '<' + tagName + '>' + html + '</' + tagName + '>';
    }

    return domParser.parseFromString(html, mimeType);
  };

  parseFromDocument = parseFromString;
}

/**
 * DOMImplementation (performance: fair).
 *
 * @see https://developer.mozilla.org/docs/Web/API/DOMImplementation/createHTMLDocument
 */
if (document.implementation) {
  var isIE = (__webpack_require__(/*! ./utilities */ "./node_modules/html-dom-parser/lib/client/utilities.js").isIE);

  // title parameter is required in IE
  // https://msdn.microsoft.com/en-us/library/ff975457(v=vs.85).aspx
  var doc = document.implementation.createHTMLDocument(
    isIE() ? 'html-dom-parser' : undefined
  );

  /**
   * Use HTML document created by `document.implementation.createHTMLDocument`.
   *
   * @param  {string} html      - The HTML string.
   * @param  {string} [tagName] - The element to render the HTML (with 'body' as fallback).
   * @return {HTMLDocument}
   */
  parseFromDocument = function (html, tagName) {
    if (tagName) {
      doc.documentElement.getElementsByTagName(tagName)[0].innerHTML = html;
      return doc;
    }

    doc.documentElement.innerHTML = html;
    return doc;
  };
}

/**
 * Template (performance: fast).
 *
 * @see https://developer.mozilla.org/docs/Web/HTML/Element/template
 */
var template = document.createElement('template');
var parseFromTemplate;

if (template.content) {
  /**
   * Uses a template element (content fragment) to parse HTML.
   *
   * @param  {string} html - The HTML string.
   * @return {NodeList}
   */
  parseFromTemplate = function (html) {
    template.innerHTML = html;
    return template.content.childNodes;
  };
}

/**
 * Parses HTML string to DOM nodes.
 *
 * @param  {string}   html - HTML markup.
 * @return {NodeList}
 */
function domparser(html) {
  var firstTagName;
  var match = html.match(FIRST_TAG_REGEX);

  if (match && match[1]) {
    firstTagName = match[1].toLowerCase();
  }

  var doc;
  var element;
  var elements;

  switch (firstTagName) {
    case HTML:
      doc = parseFromString(html);

      // the created document may come with filler head/body elements,
      // so make sure to remove them if they don't actually exist
      if (!HEAD_TAG_REGEX.test(html)) {
        element = doc.getElementsByTagName(HEAD)[0];
        if (element) {
          element.parentNode.removeChild(element);
        }
      }

      if (!BODY_TAG_REGEX.test(html)) {
        element = doc.getElementsByTagName(BODY)[0];
        if (element) {
          element.parentNode.removeChild(element);
        }
      }

      return doc.getElementsByTagName(HTML);

    case HEAD:
    case BODY:
      elements = parseFromDocument(html).getElementsByTagName(firstTagName);

      // if there's a sibling element, then return both elements
      if (BODY_TAG_REGEX.test(html) && HEAD_TAG_REGEX.test(html)) {
        return elements[0].parentNode.childNodes;
      }
      return elements;

    // low-level tag or text
    default:
      if (parseFromTemplate) {
        return parseFromTemplate(html);
      }

      return parseFromDocument(html, BODY).getElementsByTagName(BODY)[0]
        .childNodes;
  }
}

module.exports = domparser;


/***/ }),

/***/ "./node_modules/html-dom-parser/lib/client/html-to-dom.js":
/*!****************************************************************!*\
  !*** ./node_modules/html-dom-parser/lib/client/html-to-dom.js ***!
  \****************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var domparser = __webpack_require__(/*! ./domparser */ "./node_modules/html-dom-parser/lib/client/domparser.js");
var formatDOM = (__webpack_require__(/*! ./utilities */ "./node_modules/html-dom-parser/lib/client/utilities.js").formatDOM);

var DIRECTIVE_REGEX = /<(![a-zA-Z\s]+)>/; // e.g., <!doctype html>

/**
 * Parses HTML string to DOM nodes in browser.
 *
 * @param  {string} html  - HTML markup.
 * @return {DomElement[]} - DOM elements.
 */
function HTMLDOMParser(html) {
  if (typeof html !== 'string') {
    throw new TypeError('First argument must be a string');
  }

  if (html === '') {
    return [];
  }

  // match directive
  var match = html.match(DIRECTIVE_REGEX);
  var directive;

  if (match && match[1]) {
    directive = match[1];
  }

  return formatDOM(domparser(html), null, directive);
}

module.exports = HTMLDOMParser;


/***/ }),

/***/ "./node_modules/html-dom-parser/lib/client/utilities.js":
/*!**************************************************************!*\
  !*** ./node_modules/html-dom-parser/lib/client/utilities.js ***!
  \**************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var constants = __webpack_require__(/*! ./constants */ "./node_modules/html-dom-parser/lib/client/constants.js");
var domhandler = __webpack_require__(/*! domhandler/lib/node */ "./node_modules/html-dom-parser/node_modules/domhandler/lib/node.js");

var CASE_SENSITIVE_TAG_NAMES = constants.CASE_SENSITIVE_TAG_NAMES;

var Comment = domhandler.Comment;
var Element = domhandler.Element;
var ProcessingInstruction = domhandler.ProcessingInstruction;
var Text = domhandler.Text;

var caseSensitiveTagNamesMap = {};
var tagName;

for (var i = 0, len = CASE_SENSITIVE_TAG_NAMES.length; i < len; i++) {
  tagName = CASE_SENSITIVE_TAG_NAMES[i];
  caseSensitiveTagNamesMap[tagName.toLowerCase()] = tagName;
}

/**
 * Gets case-sensitive tag name.
 *
 * @param  {string}           tagName - Tag name in lowercase.
 * @return {string|undefined}         - Case-sensitive tag name.
 */
function getCaseSensitiveTagName(tagName) {
  return caseSensitiveTagNamesMap[tagName];
}

/**
 * Formats DOM attributes to a hash map.
 *
 * @param  {NamedNodeMap} attributes - List of attributes.
 * @return {object}                  - Map of attribute name to value.
 */
function formatAttributes(attributes) {
  var result = {};
  var attribute;
  // `NamedNodeMap` is array-like
  for (var i = 0, len = attributes.length; i < len; i++) {
    attribute = attributes[i];
    result[attribute.name] = attribute.value;
  }
  return result;
}

/**
 * Corrects the tag name if it is case-sensitive (SVG).
 * Otherwise, returns the lowercase tag name (HTML).
 *
 * @param  {string} tagName - Lowercase tag name.
 * @return {string}         - Formatted tag name.
 */
function formatTagName(tagName) {
  tagName = tagName.toLowerCase();
  var caseSensitiveTagName = getCaseSensitiveTagName(tagName);
  if (caseSensitiveTagName) {
    return caseSensitiveTagName;
  }
  return tagName;
}

/**
 * Transforms DOM nodes to `domhandler` nodes.
 *
 * @param  {NodeList}     nodes         - DOM nodes.
 * @param  {Element|null} [parent=null] - Parent node.
 * @param  {string}       [directive]   - Directive.
 * @return {Array<Comment|Element|ProcessingInstruction|Text>}
 */
function formatDOM(nodes, parent, directive) {
  parent = parent || null;
  var result = [];

  for (var index = 0, len = nodes.length; index < len; index++) {
    var node = nodes[index];
    var current;

    // set the node data given the type
    switch (node.nodeType) {
      case 1:
        // script, style, or tag
        current = new Element(
          formatTagName(node.nodeName),
          formatAttributes(node.attributes)
        );
        current.children = formatDOM(node.childNodes, current);
        break;

      case 3:
        current = new Text(node.nodeValue);
        break;

      case 8:
        current = new Comment(node.nodeValue);
        break;

      default:
        continue;
    }

    // set previous node next
    var prev = result[index - 1] || null;
    if (prev) {
      prev.next = current;
    }

    // set properties for current node
    current.parent = parent;
    current.prev = prev;
    current.next = null;

    result.push(current);
  }

  if (directive) {
    current = new ProcessingInstruction(
      directive.substring(0, directive.indexOf(' ')).toLowerCase(),
      directive
    );
    current.next = result[0] || null;
    current.parent = parent;
    result.unshift(current);

    if (result[1]) {
      result[1].prev = result[0];
    }
  }

  return result;
}

/**
 * Detects if browser is Internet Explorer.
 *
 * @return {boolean} - Whether IE is detected.
 */
function isIE() {
  return /(MSIE |Trident\/|Edge\/)/.test(navigator.userAgent);
}

module.exports = {
  formatAttributes: formatAttributes,
  formatDOM: formatDOM,
  isIE: isIE
};


/***/ }),

/***/ "./node_modules/html-dom-parser/node_modules/domelementtype/lib/index.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/html-dom-parser/node_modules/domelementtype/lib/index.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Doctype = exports.CDATA = exports.Tag = exports.Style = exports.Script = exports.Comment = exports.Directive = exports.Text = exports.Root = exports.isTag = exports.ElementType = void 0;
/** Types of elements found in htmlparser2's DOM */
var ElementType;
(function (ElementType) {
    /** Type for the root element of a document */
    ElementType["Root"] = "root";
    /** Type for Text */
    ElementType["Text"] = "text";
    /** Type for <? ... ?> */
    ElementType["Directive"] = "directive";
    /** Type for <!-- ... --> */
    ElementType["Comment"] = "comment";
    /** Type for <script> tags */
    ElementType["Script"] = "script";
    /** Type for <style> tags */
    ElementType["Style"] = "style";
    /** Type for Any tag */
    ElementType["Tag"] = "tag";
    /** Type for <![CDATA[ ... ]]> */
    ElementType["CDATA"] = "cdata";
    /** Type for <!doctype ...> */
    ElementType["Doctype"] = "doctype";
})(ElementType = exports.ElementType || (exports.ElementType = {}));
/**
 * Tests whether an element is a tag or not.
 *
 * @param elem Element to test
 */
function isTag(elem) {
    return (elem.type === ElementType.Tag ||
        elem.type === ElementType.Script ||
        elem.type === ElementType.Style);
}
exports.isTag = isTag;
// Exports for backwards compatibility
/** Type for the root element of a document */
exports.Root = ElementType.Root;
/** Type for Text */
exports.Text = ElementType.Text;
/** Type for <? ... ?> */
exports.Directive = ElementType.Directive;
/** Type for <!-- ... --> */
exports.Comment = ElementType.Comment;
/** Type for <script> tags */
exports.Script = ElementType.Script;
/** Type for <style> tags */
exports.Style = ElementType.Style;
/** Type for Any tag */
exports.Tag = ElementType.Tag;
/** Type for <![CDATA[ ... ]]> */
exports.CDATA = ElementType.CDATA;
/** Type for <!doctype ...> */
exports.Doctype = ElementType.Doctype;


/***/ }),

/***/ "./node_modules/html-dom-parser/node_modules/domhandler/lib/node.js":
/*!**************************************************************************!*\
  !*** ./node_modules/html-dom-parser/node_modules/domhandler/lib/node.js ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.cloneNode = exports.hasChildren = exports.isDocument = exports.isDirective = exports.isComment = exports.isText = exports.isCDATA = exports.isTag = exports.Element = exports.Document = exports.NodeWithChildren = exports.ProcessingInstruction = exports.Comment = exports.Text = exports.DataNode = exports.Node = void 0;
var domelementtype_1 = __webpack_require__(/*! domelementtype */ "./node_modules/html-dom-parser/node_modules/domelementtype/lib/index.js");
var nodeTypes = new Map([
    [domelementtype_1.ElementType.Tag, 1],
    [domelementtype_1.ElementType.Script, 1],
    [domelementtype_1.ElementType.Style, 1],
    [domelementtype_1.ElementType.Directive, 1],
    [domelementtype_1.ElementType.Text, 3],
    [domelementtype_1.ElementType.CDATA, 4],
    [domelementtype_1.ElementType.Comment, 8],
    [domelementtype_1.ElementType.Root, 9],
]);
/**
 * This object will be used as the prototype for Nodes when creating a
 * DOM-Level-1-compliant structure.
 */
var Node = /** @class */ (function () {
    /**
     *
     * @param type The type of the node.
     */
    function Node(type) {
        this.type = type;
        /** Parent of the node */
        this.parent = null;
        /** Previous sibling */
        this.prev = null;
        /** Next sibling */
        this.next = null;
        /** The start index of the node. Requires `withStartIndices` on the handler to be `true. */
        this.startIndex = null;
        /** The end index of the node. Requires `withEndIndices` on the handler to be `true. */
        this.endIndex = null;
    }
    Object.defineProperty(Node.prototype, "nodeType", {
        // Read-only aliases
        /**
         * [DOM spec](https://dom.spec.whatwg.org/#dom-node-nodetype)-compatible
         * node {@link type}.
         */
        get: function () {
            var _a;
            return (_a = nodeTypes.get(this.type)) !== null && _a !== void 0 ? _a : 1;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "parentNode", {
        // Read-write aliases for properties
        /**
         * Same as {@link parent}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.parent;
        },
        set: function (parent) {
            this.parent = parent;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "previousSibling", {
        /**
         * Same as {@link prev}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.prev;
        },
        set: function (prev) {
            this.prev = prev;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "nextSibling", {
        /**
         * Same as {@link next}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.next;
        },
        set: function (next) {
            this.next = next;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Clone this node, and optionally its children.
     *
     * @param recursive Clone child nodes as well.
     * @returns A clone of the node.
     */
    Node.prototype.cloneNode = function (recursive) {
        if (recursive === void 0) { recursive = false; }
        return cloneNode(this, recursive);
    };
    return Node;
}());
exports.Node = Node;
/**
 * A node that contains some data.
 */
var DataNode = /** @class */ (function (_super) {
    __extends(DataNode, _super);
    /**
     * @param type The type of the node
     * @param data The content of the data node
     */
    function DataNode(type, data) {
        var _this = _super.call(this, type) || this;
        _this.data = data;
        return _this;
    }
    Object.defineProperty(DataNode.prototype, "nodeValue", {
        /**
         * Same as {@link data}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.data;
        },
        set: function (data) {
            this.data = data;
        },
        enumerable: false,
        configurable: true
    });
    return DataNode;
}(Node));
exports.DataNode = DataNode;
/**
 * Text within the document.
 */
var Text = /** @class */ (function (_super) {
    __extends(Text, _super);
    function Text(data) {
        return _super.call(this, domelementtype_1.ElementType.Text, data) || this;
    }
    return Text;
}(DataNode));
exports.Text = Text;
/**
 * Comments within the document.
 */
var Comment = /** @class */ (function (_super) {
    __extends(Comment, _super);
    function Comment(data) {
        return _super.call(this, domelementtype_1.ElementType.Comment, data) || this;
    }
    return Comment;
}(DataNode));
exports.Comment = Comment;
/**
 * Processing instructions, including doc types.
 */
var ProcessingInstruction = /** @class */ (function (_super) {
    __extends(ProcessingInstruction, _super);
    function ProcessingInstruction(name, data) {
        var _this = _super.call(this, domelementtype_1.ElementType.Directive, data) || this;
        _this.name = name;
        return _this;
    }
    return ProcessingInstruction;
}(DataNode));
exports.ProcessingInstruction = ProcessingInstruction;
/**
 * A `Node` that can have children.
 */
var NodeWithChildren = /** @class */ (function (_super) {
    __extends(NodeWithChildren, _super);
    /**
     * @param type Type of the node.
     * @param children Children of the node. Only certain node types can have children.
     */
    function NodeWithChildren(type, children) {
        var _this = _super.call(this, type) || this;
        _this.children = children;
        return _this;
    }
    Object.defineProperty(NodeWithChildren.prototype, "firstChild", {
        // Aliases
        /** First child of the node. */
        get: function () {
            var _a;
            return (_a = this.children[0]) !== null && _a !== void 0 ? _a : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "lastChild", {
        /** Last child of the node. */
        get: function () {
            return this.children.length > 0
                ? this.children[this.children.length - 1]
                : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "childNodes", {
        /**
         * Same as {@link children}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.children;
        },
        set: function (children) {
            this.children = children;
        },
        enumerable: false,
        configurable: true
    });
    return NodeWithChildren;
}(Node));
exports.NodeWithChildren = NodeWithChildren;
/**
 * The root node of the document.
 */
var Document = /** @class */ (function (_super) {
    __extends(Document, _super);
    function Document(children) {
        return _super.call(this, domelementtype_1.ElementType.Root, children) || this;
    }
    return Document;
}(NodeWithChildren));
exports.Document = Document;
/**
 * An element within the DOM.
 */
var Element = /** @class */ (function (_super) {
    __extends(Element, _super);
    /**
     * @param name Name of the tag, eg. `div`, `span`.
     * @param attribs Object mapping attribute names to attribute values.
     * @param children Children of the node.
     */
    function Element(name, attribs, children, type) {
        if (children === void 0) { children = []; }
        if (type === void 0) { type = name === "script"
            ? domelementtype_1.ElementType.Script
            : name === "style"
                ? domelementtype_1.ElementType.Style
                : domelementtype_1.ElementType.Tag; }
        var _this = _super.call(this, type, children) || this;
        _this.name = name;
        _this.attribs = attribs;
        return _this;
    }
    Object.defineProperty(Element.prototype, "tagName", {
        // DOM Level 1 aliases
        /**
         * Same as {@link name}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.name;
        },
        set: function (name) {
            this.name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Element.prototype, "attributes", {
        get: function () {
            var _this = this;
            return Object.keys(this.attribs).map(function (name) {
                var _a, _b;
                return ({
                    name: name,
                    value: _this.attribs[name],
                    namespace: (_a = _this["x-attribsNamespace"]) === null || _a === void 0 ? void 0 : _a[name],
                    prefix: (_b = _this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name],
                });
            });
        },
        enumerable: false,
        configurable: true
    });
    return Element;
}(NodeWithChildren));
exports.Element = Element;
/**
 * @param node Node to check.
 * @returns `true` if the node is a `Element`, `false` otherwise.
 */
function isTag(node) {
    return (0, domelementtype_1.isTag)(node);
}
exports.isTag = isTag;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `CDATA`, `false` otherwise.
 */
function isCDATA(node) {
    return node.type === domelementtype_1.ElementType.CDATA;
}
exports.isCDATA = isCDATA;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Text`, `false` otherwise.
 */
function isText(node) {
    return node.type === domelementtype_1.ElementType.Text;
}
exports.isText = isText;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Comment`, `false` otherwise.
 */
function isComment(node) {
    return node.type === domelementtype_1.ElementType.Comment;
}
exports.isComment = isComment;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */
function isDirective(node) {
    return node.type === domelementtype_1.ElementType.Directive;
}
exports.isDirective = isDirective;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */
function isDocument(node) {
    return node.type === domelementtype_1.ElementType.Root;
}
exports.isDocument = isDocument;
/**
 * @param node Node to check.
 * @returns `true` if the node is a `NodeWithChildren` (has children), `false` otherwise.
 */
function hasChildren(node) {
    return Object.prototype.hasOwnProperty.call(node, "children");
}
exports.hasChildren = hasChildren;
/**
 * Clone a node, and optionally its children.
 *
 * @param recursive Clone child nodes as well.
 * @returns A clone of the node.
 */
function cloneNode(node, recursive) {
    if (recursive === void 0) { recursive = false; }
    var result;
    if (isText(node)) {
        result = new Text(node.data);
    }
    else if (isComment(node)) {
        result = new Comment(node.data);
    }
    else if (isTag(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_1 = new Element(node.name, __assign({}, node.attribs), children);
        children.forEach(function (child) { return (child.parent = clone_1); });
        if (node.namespace != null) {
            clone_1.namespace = node.namespace;
        }
        if (node["x-attribsNamespace"]) {
            clone_1["x-attribsNamespace"] = __assign({}, node["x-attribsNamespace"]);
        }
        if (node["x-attribsPrefix"]) {
            clone_1["x-attribsPrefix"] = __assign({}, node["x-attribsPrefix"]);
        }
        result = clone_1;
    }
    else if (isCDATA(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_2 = new NodeWithChildren(domelementtype_1.ElementType.CDATA, children);
        children.forEach(function (child) { return (child.parent = clone_2); });
        result = clone_2;
    }
    else if (isDocument(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_3 = new Document(children);
        children.forEach(function (child) { return (child.parent = clone_3); });
        if (node["x-mode"]) {
            clone_3["x-mode"] = node["x-mode"];
        }
        result = clone_3;
    }
    else if (isDirective(node)) {
        var instruction = new ProcessingInstruction(node.name, node.data);
        if (node["x-name"] != null) {
            instruction["x-name"] = node["x-name"];
            instruction["x-publicId"] = node["x-publicId"];
            instruction["x-systemId"] = node["x-systemId"];
        }
        result = instruction;
    }
    else {
        throw new Error("Not implemented yet: ".concat(node.type));
    }
    result.startIndex = node.startIndex;
    result.endIndex = node.endIndex;
    if (node.sourceCodeLocation != null) {
        result.sourceCodeLocation = node.sourceCodeLocation;
    }
    return result;
}
exports.cloneNode = cloneNode;
function cloneChildren(childs) {
    var children = childs.map(function (child) { return cloneNode(child, true); });
    for (var i = 1; i < children.length; i++) {
        children[i].prev = children[i - 1];
        children[i - 1].next = children[i];
    }
    return children;
}


/***/ }),

/***/ "./node_modules/html-react-parser/index.js":
/*!*************************************************!*\
  !*** ./node_modules/html-react-parser/index.js ***!
  \*************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var domToReact = __webpack_require__(/*! ./lib/dom-to-react */ "./node_modules/html-react-parser/lib/dom-to-react.js");
var attributesToProps = __webpack_require__(/*! ./lib/attributes-to-props */ "./node_modules/html-react-parser/lib/attributes-to-props.js");
var htmlToDOM = __webpack_require__(/*! html-dom-parser */ "./node_modules/html-dom-parser/lib/client/html-to-dom.js");

// support backwards compatibility for ES Module
htmlToDOM =
  /* istanbul ignore next */
  typeof htmlToDOM.default === 'function' ? htmlToDOM.default : htmlToDOM;

var domParserOptions = { lowerCaseAttributeNames: false };

/**
 * Converts HTML string to React elements.
 *
 * @param  {String}   html                    - HTML string.
 * @param  {Object}   [options]               - Parser options.
 * @param  {Object}   [options.htmlparser2]   - htmlparser2 options.
 * @param  {Object}   [options.library]       - Library for React, Preact, etc.
 * @param  {Function} [options.replace]       - Replace method.
 * @return {JSX.Element|JSX.Element[]|String} - React element(s), empty array, or string.
 */
function HTMLReactParser(html, options) {
  if (typeof html !== 'string') {
    throw new TypeError('First argument must be a string');
  }
  if (html === '') {
    return [];
  }
  options = options || {};
  return domToReact(
    htmlToDOM(html, options.htmlparser2 || domParserOptions),
    options
  );
}

HTMLReactParser.domToReact = domToReact;
HTMLReactParser.htmlToDOM = htmlToDOM;
HTMLReactParser.attributesToProps = attributesToProps;
HTMLReactParser.Element = (__webpack_require__(/*! domhandler/lib/node */ "./node_modules/html-react-parser/node_modules/domhandler/lib/node.js").Element);

// support CommonJS and ES Modules
module.exports = HTMLReactParser;
module.exports["default"] = HTMLReactParser;


/***/ }),

/***/ "./node_modules/html-react-parser/lib/attributes-to-props.js":
/*!*******************************************************************!*\
  !*** ./node_modules/html-react-parser/lib/attributes-to-props.js ***!
  \*******************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var reactProperty = __webpack_require__(/*! react-property */ "./node_modules/react-property/lib/index.js");
var utilities = __webpack_require__(/*! ./utilities */ "./node_modules/html-react-parser/lib/utilities.js");

/**
 * Converts HTML/SVG DOM attributes to React props.
 *
 * @param  {object} [attributes={}] - HTML/SVG DOM attributes.
 * @return {object}                 - React props.
 */
module.exports = function attributesToProps(attributes) {
  attributes = attributes || {};

  var valueOnlyInputs = {
    reset: true,
    submit: true
  };

  var attributeName;
  var attributeNameLowerCased;
  var attributeValue;
  var propName;
  var propertyInfo;
  var props = {};
  var inputIsValueOnly = attributes.type && valueOnlyInputs[attributes.type];

  for (attributeName in attributes) {
    attributeValue = attributes[attributeName];

    // ARIA (aria-*) or custom data (data-*) attribute
    if (reactProperty.isCustomAttribute(attributeName)) {
      props[attributeName] = attributeValue;
      continue;
    }

    // convert HTML/SVG attribute to React prop
    attributeNameLowerCased = attributeName.toLowerCase();
    propName = getPropName(attributeNameLowerCased);

    if (propName) {
      propertyInfo = reactProperty.getPropertyInfo(propName);

      // convert attribute to uncontrolled component prop (e.g., `value` to `defaultValue`)
      // https://reactjs.org/docs/uncontrolled-components.html
      if (
        (propName === 'checked' || propName === 'value') &&
        !inputIsValueOnly
      ) {
        propName = getPropName('default' + attributeNameLowerCased);
      }

      props[propName] = attributeValue;

      switch (propertyInfo && propertyInfo.type) {
        case reactProperty.BOOLEAN:
          props[propName] = true;
          break;
        case reactProperty.OVERLOADED_BOOLEAN:
          if (attributeValue === '') {
            props[propName] = true;
          }
          break;
      }
      continue;
    }

    // preserve custom attribute if React >=16
    if (utilities.PRESERVE_CUSTOM_ATTRIBUTES) {
      props[attributeName] = attributeValue;
    }
  }

  // transform inline style to object
  utilities.setStyleProp(attributes.style, props);

  return props;
};

/**
 * Gets prop name from lowercased attribute name.
 *
 * @param {string} attributeName - Lowercased attribute name.
 * @return {string}
 */
function getPropName(attributeName) {
  return reactProperty.possibleStandardNames[attributeName];
}


/***/ }),

/***/ "./node_modules/html-react-parser/lib/dom-to-react.js":
/*!************************************************************!*\
  !*** ./node_modules/html-react-parser/lib/dom-to-react.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var React = __webpack_require__(/*! react */ "react");
var attributesToProps = __webpack_require__(/*! ./attributes-to-props */ "./node_modules/html-react-parser/lib/attributes-to-props.js");
var utilities = __webpack_require__(/*! ./utilities */ "./node_modules/html-react-parser/lib/utilities.js");

var setStyleProp = utilities.setStyleProp;
var canTextBeChildOfNode = utilities.canTextBeChildOfNode;

/**
 * Converts DOM nodes to JSX element(s).
 *
 * @param  {DomElement[]} nodes             - DOM nodes.
 * @param  {object}       [options={}]      - Options.
 * @param  {Function}     [options.replace] - Replacer.
 * @param  {object}       [options.library] - Library (React/Preact/etc.).
 * @return {string|JSX.Element|JSX.Element[]}
 */
function domToReact(nodes, options) {
  options = options || {};

  var library = options.library || React;
  var cloneElement = library.cloneElement;
  var createElement = library.createElement;
  var isValidElement = library.isValidElement;

  var result = [];
  var node;
  var isWhitespace;
  var hasReplace = typeof options.replace === 'function';
  var replaceElement;
  var props;
  var children;
  var trim = options.trim;

  for (var i = 0, len = nodes.length; i < len; i++) {
    node = nodes[i];

    // replace with custom React element (if present)
    if (hasReplace) {
      replaceElement = options.replace(node);

      if (isValidElement(replaceElement)) {
        // set "key" prop for sibling elements
        // https://fb.me/react-warning-keys
        if (len > 1) {
          replaceElement = cloneElement(replaceElement, {
            key: replaceElement.key || i
          });
        }
        result.push(replaceElement);
        continue;
      }
    }

    if (node.type === 'text') {
      isWhitespace = !node.data.trim().length;

      if (isWhitespace && node.parent && !canTextBeChildOfNode(node.parent)) {
        // We have a whitespace node that can't be nested in its parent
        // so skip it
        continue;
      }

      if (trim && isWhitespace) {
        // Trim is enabled and we have a whitespace node
        // so skip it
        continue;
      }

      // We have a text node that's not whitespace and it can be nested
      // in its parent so add it to the results
      result.push(node.data);
      continue;
    }

    props = node.attribs;
    if (skipAttributesToProps(node)) {
      setStyleProp(props.style, props);
    } else if (props) {
      props = attributesToProps(props);
    }

    children = null;

    switch (node.type) {
      case 'script':
      case 'style':
        // prevent text in <script> or <style> from being escaped
        // https://reactjs.org/docs/dom-elements.html#dangerouslysetinnerhtml
        if (node.children[0]) {
          props.dangerouslySetInnerHTML = {
            __html: node.children[0].data
          };
        }
        break;

      case 'tag':
        // setting textarea value in children is an antipattern in React
        // https://reactjs.org/docs/forms.html#the-textarea-tag
        if (node.name === 'textarea' && node.children[0]) {
          props.defaultValue = node.children[0].data;
        } else if (node.children && node.children.length) {
          // continue recursion of creating React elements (if applicable)
          children = domToReact(node.children, options);
        }
        break;

      // skip all other cases (e.g., comment)
      default:
        continue;
    }

    // set "key" prop for sibling elements
    // https://fb.me/react-warning-keys
    if (len > 1) {
      props.key = i;
    }

    result.push(createElement(node.name, props, children));
  }

  return result.length === 1 ? result[0] : result;
}

/**
 * Determines whether DOM element attributes should be transformed to props.
 * Web Components should not have their attributes transformed except for `style`.
 *
 * @param  {DomElement} node
 * @return {boolean}
 */
function skipAttributesToProps(node) {
  return (
    utilities.PRESERVE_CUSTOM_ATTRIBUTES &&
    node.type === 'tag' &&
    utilities.isCustomComponent(node.name, node.attribs)
  );
}

module.exports = domToReact;


/***/ }),

/***/ "./node_modules/html-react-parser/lib/utilities.js":
/*!*********************************************************!*\
  !*** ./node_modules/html-react-parser/lib/utilities.js ***!
  \*********************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var React = __webpack_require__(/*! react */ "react");
var styleToJS = (__webpack_require__(/*! style-to-js */ "./node_modules/style-to-js/cjs/index.js")["default"]);

/**
 * Swap key with value in an object.
 *
 * @param  {Object}   obj        - The object.
 * @param  {Function} [override] - The override method.
 * @return {Object}              - The inverted object.
 */
function invertObject(obj, override) {
  if (!obj || typeof obj !== 'object') {
    throw new TypeError('First argument must be an object');
  }

  var key;
  var value;
  var isOverridePresent = typeof override === 'function';
  var overrides = {};
  var result = {};

  for (key in obj) {
    value = obj[key];

    if (isOverridePresent) {
      overrides = override(key, value);
      if (overrides && overrides.length === 2) {
        result[overrides[0]] = overrides[1];
        continue;
      }
    }

    if (typeof value === 'string') {
      result[value] = key;
    }
  }

  return result;
}

/**
 * Check if a given tag is a custom component.
 *
 * @see {@link https://github.com/facebook/react/blob/v16.6.3/packages/react-dom/src/shared/isCustomComponent.js}
 *
 * @param {string} tagName - The name of the html tag.
 * @param {Object} props   - The props being passed to the element.
 * @return {boolean}
 */
function isCustomComponent(tagName, props) {
  if (tagName.indexOf('-') === -1) {
    return props && typeof props.is === 'string';
  }

  switch (tagName) {
    // These are reserved SVG and MathML elements.
    // We don't mind this whitelist too much because we expect it to never grow.
    // The alternative is to track the namespace in a few places which is convoluted.
    // https://w3c.github.io/webcomponents/spec/custom/#custom-elements-core-concepts
    case 'annotation-xml':
    case 'color-profile':
    case 'font-face':
    case 'font-face-src':
    case 'font-face-uri':
    case 'font-face-format':
    case 'font-face-name':
    case 'missing-glyph':
      return false;
    default:
      return true;
  }
}

var styleToJSOptions = { reactCompat: true };

/**
 * Sets style prop.
 *
 * @param {null|undefined|string} style
 * @param {object} props
 */
function setStyleProp(style, props) {
  if (style === null || style === undefined) {
    return;
  }
  try {
    props.style = styleToJS(style, styleToJSOptions);
  } catch (err) {
    props.style = {};
  }
}

/**
 * @constant {boolean}
 * @see {@link https://reactjs.org/blog/2017/09/08/dom-attributes-in-react-16.html}
 */
var PRESERVE_CUSTOM_ATTRIBUTES = React.version.split('.')[0] >= 16;

// Taken from
// https://github.com/facebook/react/blob/cae635054e17a6f107a39d328649137b83f25972/packages/react-dom/src/client/validateDOMNesting.js#L213
var elementsWithNoTextChildren = new Set([
  'tr',
  'tbody',
  'thead',
  'tfoot',
  'colgroup',
  'table',
  'head',
  'html',
  'frameset'
]);

/**
 * Checks if the given node can contain text nodes
 *
 * @param {DomElement} node
 * @returns {boolean}
 */
function canTextBeChildOfNode(node) {
  return !elementsWithNoTextChildren.has(node.name);
}

module.exports = {
  PRESERVE_CUSTOM_ATTRIBUTES: PRESERVE_CUSTOM_ATTRIBUTES,
  invertObject: invertObject,
  isCustomComponent: isCustomComponent,
  setStyleProp: setStyleProp,
  canTextBeChildOfNode: canTextBeChildOfNode,
  elementsWithNoTextChildren: elementsWithNoTextChildren
};


/***/ }),

/***/ "./node_modules/html-react-parser/node_modules/domelementtype/lib/index.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/html-react-parser/node_modules/domelementtype/lib/index.js ***!
  \*********************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Doctype = exports.CDATA = exports.Tag = exports.Style = exports.Script = exports.Comment = exports.Directive = exports.Text = exports.Root = exports.isTag = exports.ElementType = void 0;
/** Types of elements found in htmlparser2's DOM */
var ElementType;
(function (ElementType) {
    /** Type for the root element of a document */
    ElementType["Root"] = "root";
    /** Type for Text */
    ElementType["Text"] = "text";
    /** Type for <? ... ?> */
    ElementType["Directive"] = "directive";
    /** Type for <!-- ... --> */
    ElementType["Comment"] = "comment";
    /** Type for <script> tags */
    ElementType["Script"] = "script";
    /** Type for <style> tags */
    ElementType["Style"] = "style";
    /** Type for Any tag */
    ElementType["Tag"] = "tag";
    /** Type for <![CDATA[ ... ]]> */
    ElementType["CDATA"] = "cdata";
    /** Type for <!doctype ...> */
    ElementType["Doctype"] = "doctype";
})(ElementType = exports.ElementType || (exports.ElementType = {}));
/**
 * Tests whether an element is a tag or not.
 *
 * @param elem Element to test
 */
function isTag(elem) {
    return (elem.type === ElementType.Tag ||
        elem.type === ElementType.Script ||
        elem.type === ElementType.Style);
}
exports.isTag = isTag;
// Exports for backwards compatibility
/** Type for the root element of a document */
exports.Root = ElementType.Root;
/** Type for Text */
exports.Text = ElementType.Text;
/** Type for <? ... ?> */
exports.Directive = ElementType.Directive;
/** Type for <!-- ... --> */
exports.Comment = ElementType.Comment;
/** Type for <script> tags */
exports.Script = ElementType.Script;
/** Type for <style> tags */
exports.Style = ElementType.Style;
/** Type for Any tag */
exports.Tag = ElementType.Tag;
/** Type for <![CDATA[ ... ]]> */
exports.CDATA = ElementType.CDATA;
/** Type for <!doctype ...> */
exports.Doctype = ElementType.Doctype;


/***/ }),

/***/ "./node_modules/html-react-parser/node_modules/domhandler/lib/node.js":
/*!****************************************************************************!*\
  !*** ./node_modules/html-react-parser/node_modules/domhandler/lib/node.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.cloneNode = exports.hasChildren = exports.isDocument = exports.isDirective = exports.isComment = exports.isText = exports.isCDATA = exports.isTag = exports.Element = exports.Document = exports.NodeWithChildren = exports.ProcessingInstruction = exports.Comment = exports.Text = exports.DataNode = exports.Node = void 0;
var domelementtype_1 = __webpack_require__(/*! domelementtype */ "./node_modules/html-react-parser/node_modules/domelementtype/lib/index.js");
var nodeTypes = new Map([
    [domelementtype_1.ElementType.Tag, 1],
    [domelementtype_1.ElementType.Script, 1],
    [domelementtype_1.ElementType.Style, 1],
    [domelementtype_1.ElementType.Directive, 1],
    [domelementtype_1.ElementType.Text, 3],
    [domelementtype_1.ElementType.CDATA, 4],
    [domelementtype_1.ElementType.Comment, 8],
    [domelementtype_1.ElementType.Root, 9],
]);
/**
 * This object will be used as the prototype for Nodes when creating a
 * DOM-Level-1-compliant structure.
 */
var Node = /** @class */ (function () {
    /**
     *
     * @param type The type of the node.
     */
    function Node(type) {
        this.type = type;
        /** Parent of the node */
        this.parent = null;
        /** Previous sibling */
        this.prev = null;
        /** Next sibling */
        this.next = null;
        /** The start index of the node. Requires `withStartIndices` on the handler to be `true. */
        this.startIndex = null;
        /** The end index of the node. Requires `withEndIndices` on the handler to be `true. */
        this.endIndex = null;
    }
    Object.defineProperty(Node.prototype, "nodeType", {
        // Read-only aliases
        /**
         * [DOM spec](https://dom.spec.whatwg.org/#dom-node-nodetype)-compatible
         * node {@link type}.
         */
        get: function () {
            var _a;
            return (_a = nodeTypes.get(this.type)) !== null && _a !== void 0 ? _a : 1;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "parentNode", {
        // Read-write aliases for properties
        /**
         * Same as {@link parent}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.parent;
        },
        set: function (parent) {
            this.parent = parent;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "previousSibling", {
        /**
         * Same as {@link prev}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.prev;
        },
        set: function (prev) {
            this.prev = prev;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Node.prototype, "nextSibling", {
        /**
         * Same as {@link next}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.next;
        },
        set: function (next) {
            this.next = next;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * Clone this node, and optionally its children.
     *
     * @param recursive Clone child nodes as well.
     * @returns A clone of the node.
     */
    Node.prototype.cloneNode = function (recursive) {
        if (recursive === void 0) { recursive = false; }
        return cloneNode(this, recursive);
    };
    return Node;
}());
exports.Node = Node;
/**
 * A node that contains some data.
 */
var DataNode = /** @class */ (function (_super) {
    __extends(DataNode, _super);
    /**
     * @param type The type of the node
     * @param data The content of the data node
     */
    function DataNode(type, data) {
        var _this = _super.call(this, type) || this;
        _this.data = data;
        return _this;
    }
    Object.defineProperty(DataNode.prototype, "nodeValue", {
        /**
         * Same as {@link data}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.data;
        },
        set: function (data) {
            this.data = data;
        },
        enumerable: false,
        configurable: true
    });
    return DataNode;
}(Node));
exports.DataNode = DataNode;
/**
 * Text within the document.
 */
var Text = /** @class */ (function (_super) {
    __extends(Text, _super);
    function Text(data) {
        return _super.call(this, domelementtype_1.ElementType.Text, data) || this;
    }
    return Text;
}(DataNode));
exports.Text = Text;
/**
 * Comments within the document.
 */
var Comment = /** @class */ (function (_super) {
    __extends(Comment, _super);
    function Comment(data) {
        return _super.call(this, domelementtype_1.ElementType.Comment, data) || this;
    }
    return Comment;
}(DataNode));
exports.Comment = Comment;
/**
 * Processing instructions, including doc types.
 */
var ProcessingInstruction = /** @class */ (function (_super) {
    __extends(ProcessingInstruction, _super);
    function ProcessingInstruction(name, data) {
        var _this = _super.call(this, domelementtype_1.ElementType.Directive, data) || this;
        _this.name = name;
        return _this;
    }
    return ProcessingInstruction;
}(DataNode));
exports.ProcessingInstruction = ProcessingInstruction;
/**
 * A `Node` that can have children.
 */
var NodeWithChildren = /** @class */ (function (_super) {
    __extends(NodeWithChildren, _super);
    /**
     * @param type Type of the node.
     * @param children Children of the node. Only certain node types can have children.
     */
    function NodeWithChildren(type, children) {
        var _this = _super.call(this, type) || this;
        _this.children = children;
        return _this;
    }
    Object.defineProperty(NodeWithChildren.prototype, "firstChild", {
        // Aliases
        /** First child of the node. */
        get: function () {
            var _a;
            return (_a = this.children[0]) !== null && _a !== void 0 ? _a : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "lastChild", {
        /** Last child of the node. */
        get: function () {
            return this.children.length > 0
                ? this.children[this.children.length - 1]
                : null;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(NodeWithChildren.prototype, "childNodes", {
        /**
         * Same as {@link children}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.children;
        },
        set: function (children) {
            this.children = children;
        },
        enumerable: false,
        configurable: true
    });
    return NodeWithChildren;
}(Node));
exports.NodeWithChildren = NodeWithChildren;
/**
 * The root node of the document.
 */
var Document = /** @class */ (function (_super) {
    __extends(Document, _super);
    function Document(children) {
        return _super.call(this, domelementtype_1.ElementType.Root, children) || this;
    }
    return Document;
}(NodeWithChildren));
exports.Document = Document;
/**
 * An element within the DOM.
 */
var Element = /** @class */ (function (_super) {
    __extends(Element, _super);
    /**
     * @param name Name of the tag, eg. `div`, `span`.
     * @param attribs Object mapping attribute names to attribute values.
     * @param children Children of the node.
     */
    function Element(name, attribs, children, type) {
        if (children === void 0) { children = []; }
        if (type === void 0) { type = name === "script"
            ? domelementtype_1.ElementType.Script
            : name === "style"
                ? domelementtype_1.ElementType.Style
                : domelementtype_1.ElementType.Tag; }
        var _this = _super.call(this, type, children) || this;
        _this.name = name;
        _this.attribs = attribs;
        return _this;
    }
    Object.defineProperty(Element.prototype, "tagName", {
        // DOM Level 1 aliases
        /**
         * Same as {@link name}.
         * [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
         */
        get: function () {
            return this.name;
        },
        set: function (name) {
            this.name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Element.prototype, "attributes", {
        get: function () {
            var _this = this;
            return Object.keys(this.attribs).map(function (name) {
                var _a, _b;
                return ({
                    name: name,
                    value: _this.attribs[name],
                    namespace: (_a = _this["x-attribsNamespace"]) === null || _a === void 0 ? void 0 : _a[name],
                    prefix: (_b = _this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name],
                });
            });
        },
        enumerable: false,
        configurable: true
    });
    return Element;
}(NodeWithChildren));
exports.Element = Element;
/**
 * @param node Node to check.
 * @returns `true` if the node is a `Element`, `false` otherwise.
 */
function isTag(node) {
    return (0, domelementtype_1.isTag)(node);
}
exports.isTag = isTag;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `CDATA`, `false` otherwise.
 */
function isCDATA(node) {
    return node.type === domelementtype_1.ElementType.CDATA;
}
exports.isCDATA = isCDATA;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Text`, `false` otherwise.
 */
function isText(node) {
    return node.type === domelementtype_1.ElementType.Text;
}
exports.isText = isText;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `Comment`, `false` otherwise.
 */
function isComment(node) {
    return node.type === domelementtype_1.ElementType.Comment;
}
exports.isComment = isComment;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */
function isDirective(node) {
    return node.type === domelementtype_1.ElementType.Directive;
}
exports.isDirective = isDirective;
/**
 * @param node Node to check.
 * @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
 */
function isDocument(node) {
    return node.type === domelementtype_1.ElementType.Root;
}
exports.isDocument = isDocument;
/**
 * @param node Node to check.
 * @returns `true` if the node is a `NodeWithChildren` (has children), `false` otherwise.
 */
function hasChildren(node) {
    return Object.prototype.hasOwnProperty.call(node, "children");
}
exports.hasChildren = hasChildren;
/**
 * Clone a node, and optionally its children.
 *
 * @param recursive Clone child nodes as well.
 * @returns A clone of the node.
 */
function cloneNode(node, recursive) {
    if (recursive === void 0) { recursive = false; }
    var result;
    if (isText(node)) {
        result = new Text(node.data);
    }
    else if (isComment(node)) {
        result = new Comment(node.data);
    }
    else if (isTag(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_1 = new Element(node.name, __assign({}, node.attribs), children);
        children.forEach(function (child) { return (child.parent = clone_1); });
        if (node.namespace != null) {
            clone_1.namespace = node.namespace;
        }
        if (node["x-attribsNamespace"]) {
            clone_1["x-attribsNamespace"] = __assign({}, node["x-attribsNamespace"]);
        }
        if (node["x-attribsPrefix"]) {
            clone_1["x-attribsPrefix"] = __assign({}, node["x-attribsPrefix"]);
        }
        result = clone_1;
    }
    else if (isCDATA(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_2 = new NodeWithChildren(domelementtype_1.ElementType.CDATA, children);
        children.forEach(function (child) { return (child.parent = clone_2); });
        result = clone_2;
    }
    else if (isDocument(node)) {
        var children = recursive ? cloneChildren(node.children) : [];
        var clone_3 = new Document(children);
        children.forEach(function (child) { return (child.parent = clone_3); });
        if (node["x-mode"]) {
            clone_3["x-mode"] = node["x-mode"];
        }
        result = clone_3;
    }
    else if (isDirective(node)) {
        var instruction = new ProcessingInstruction(node.name, node.data);
        if (node["x-name"] != null) {
            instruction["x-name"] = node["x-name"];
            instruction["x-publicId"] = node["x-publicId"];
            instruction["x-systemId"] = node["x-systemId"];
        }
        result = instruction;
    }
    else {
        throw new Error("Not implemented yet: ".concat(node.type));
    }
    result.startIndex = node.startIndex;
    result.endIndex = node.endIndex;
    if (node.sourceCodeLocation != null) {
        result.sourceCodeLocation = node.sourceCodeLocation;
    }
    return result;
}
exports.cloneNode = cloneNode;
function cloneChildren(childs) {
    var children = childs.map(function (child) { return cloneNode(child, true); });
    for (var i = 1; i < children.length; i++) {
        children[i].prev = children[i - 1];
        children[i - 1].next = children[i];
    }
    return children;
}


/***/ }),

/***/ "./node_modules/inline-style-parser/index.js":
/*!***************************************************!*\
  !*** ./node_modules/inline-style-parser/index.js ***!
  \***************************************************/
/***/ (function(module) {

// http://www.w3.org/TR/CSS21/grammar.html
// https://github.com/visionmedia/css-parse/pull/49#issuecomment-30088027
var COMMENT_REGEX = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g;

var NEWLINE_REGEX = /\n/g;
var WHITESPACE_REGEX = /^\s*/;

// declaration
var PROPERTY_REGEX = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/;
var COLON_REGEX = /^:\s*/;
var VALUE_REGEX = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/;
var SEMICOLON_REGEX = /^[;\s]*/;

// https://developer.mozilla.org/docs/Web/JavaScript/Reference/Global_Objects/String/Trim#Polyfill
var TRIM_REGEX = /^\s+|\s+$/g;

// strings
var NEWLINE = '\n';
var FORWARD_SLASH = '/';
var ASTERISK = '*';
var EMPTY_STRING = '';

// types
var TYPE_COMMENT = 'comment';
var TYPE_DECLARATION = 'declaration';

/**
 * @param {String} style
 * @param {Object} [options]
 * @return {Object[]}
 * @throws {TypeError}
 * @throws {Error}
 */
module.exports = function(style, options) {
  if (typeof style !== 'string') {
    throw new TypeError('First argument must be a string');
  }

  if (!style) return [];

  options = options || {};

  /**
   * Positional.
   */
  var lineno = 1;
  var column = 1;

  /**
   * Update lineno and column based on `str`.
   *
   * @param {String} str
   */
  function updatePosition(str) {
    var lines = str.match(NEWLINE_REGEX);
    if (lines) lineno += lines.length;
    var i = str.lastIndexOf(NEWLINE);
    column = ~i ? str.length - i : column + str.length;
  }

  /**
   * Mark position and patch `node.position`.
   *
   * @return {Function}
   */
  function position() {
    var start = { line: lineno, column: column };
    return function(node) {
      node.position = new Position(start);
      whitespace();
      return node;
    };
  }

  /**
   * Store position information for a node.
   *
   * @constructor
   * @property {Object} start
   * @property {Object} end
   * @property {undefined|String} source
   */
  function Position(start) {
    this.start = start;
    this.end = { line: lineno, column: column };
    this.source = options.source;
  }

  /**
   * Non-enumerable source string.
   */
  Position.prototype.content = style;

  var errorsList = [];

  /**
   * Error `msg`.
   *
   * @param {String} msg
   * @throws {Error}
   */
  function error(msg) {
    var err = new Error(
      options.source + ':' + lineno + ':' + column + ': ' + msg
    );
    err.reason = msg;
    err.filename = options.source;
    err.line = lineno;
    err.column = column;
    err.source = style;

    if (options.silent) {
      errorsList.push(err);
    } else {
      throw err;
    }
  }

  /**
   * Match `re` and return captures.
   *
   * @param {RegExp} re
   * @return {undefined|Array}
   */
  function match(re) {
    var m = re.exec(style);
    if (!m) return;
    var str = m[0];
    updatePosition(str);
    style = style.slice(str.length);
    return m;
  }

  /**
   * Parse whitespace.
   */
  function whitespace() {
    match(WHITESPACE_REGEX);
  }

  /**
   * Parse comments.
   *
   * @param {Object[]} [rules]
   * @return {Object[]}
   */
  function comments(rules) {
    var c;
    rules = rules || [];
    while ((c = comment())) {
      if (c !== false) {
        rules.push(c);
      }
    }
    return rules;
  }

  /**
   * Parse comment.
   *
   * @return {Object}
   * @throws {Error}
   */
  function comment() {
    var pos = position();
    if (FORWARD_SLASH != style.charAt(0) || ASTERISK != style.charAt(1)) return;

    var i = 2;
    while (
      EMPTY_STRING != style.charAt(i) &&
      (ASTERISK != style.charAt(i) || FORWARD_SLASH != style.charAt(i + 1))
    ) {
      ++i;
    }
    i += 2;

    if (EMPTY_STRING === style.charAt(i - 1)) {
      return error('End of comment missing');
    }

    var str = style.slice(2, i - 2);
    column += 2;
    updatePosition(str);
    style = style.slice(i);
    column += 2;

    return pos({
      type: TYPE_COMMENT,
      comment: str
    });
  }

  /**
   * Parse declaration.
   *
   * @return {Object}
   * @throws {Error}
   */
  function declaration() {
    var pos = position();

    // prop
    var prop = match(PROPERTY_REGEX);
    if (!prop) return;
    comment();

    // :
    if (!match(COLON_REGEX)) return error("property missing ':'");

    // val
    var val = match(VALUE_REGEX);

    var ret = pos({
      type: TYPE_DECLARATION,
      property: trim(prop[0].replace(COMMENT_REGEX, EMPTY_STRING)),
      value: val
        ? trim(val[0].replace(COMMENT_REGEX, EMPTY_STRING))
        : EMPTY_STRING
    });

    // ;
    match(SEMICOLON_REGEX);

    return ret;
  }

  /**
   * Parse declarations.
   *
   * @return {Object[]}
   */
  function declarations() {
    var decls = [];

    comments(decls);

    // declarations
    var decl;
    while ((decl = declaration())) {
      if (decl !== false) {
        decls.push(decl);
        comments(decls);
      }
    }

    return decls;
  }

  whitespace();
  return declarations();
};

/**
 * Trim `str`.
 *
 * @param {String} str
 * @return {String}
 */
function trim(str) {
  return str ? str.replace(TRIM_REGEX, EMPTY_STRING) : EMPTY_STRING;
}


/***/ }),

/***/ "./src/jnews/assets/scss/index.scss":
/*!******************************************!*\
  !*** ./src/jnews/assets/scss/index.scss ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./node_modules/object-assign/index.js":
/*!*********************************************!*\
  !*** ./node_modules/object-assign/index.js ***!
  \*********************************************/
/***/ (function(module) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ "./node_modules/prop-types/checkPropTypes.js":
/*!***************************************************!*\
  !*** ./node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};
  var has = __webpack_require__(/*! ./lib/has */ "./node_modules/prop-types/lib/has.js");

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) { /**/ }
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.' +
              'This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          );
        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

/**
 * Resets warning cache when testing.
 *
 * @private
 */
checkPropTypes.resetWarningCache = function() {
  if (true) {
    loggedTypeFailures = {};
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "./node_modules/prop-types/factoryWithTypeCheckers.js":
/*!************************************************************!*\
  !*** ./node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");
var assign = __webpack_require__(/*! object-assign */ "./node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
var has = __webpack_require__(/*! ./lib/has */ "./node_modules/prop-types/lib/has.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "./node_modules/prop-types/checkPropTypes.js");

var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bigint: createPrimitiveTypeChecker('bigint'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    elementType: createElementTypeTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message, data) {
    this.message = message;
    this.data = data && typeof data === 'object' ? data: {};
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError(
          'Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'),
          {expectedType: expectedType}
        );
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!ReactIs.isValidElementType(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
      if (true) {
        if (arguments.length > 1) {
          printWarning(
            'Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' +
            'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).'
          );
        } else {
          printWarning('Invalid argument supplied to oneOf, expected an array.');
        }
      }
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
        var type = getPreciseType(value);
        if (type === 'symbol') {
          return String(value);
        }
        return value;
      });
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (has(propValue, key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : 0;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      var expectedTypes = [];
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        var checkerResult = checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret);
        if (checkerResult == null) {
          return null;
        }
        if (checkerResult.data && has(checkerResult.data, 'expectedType')) {
          expectedTypes.push(checkerResult.data.expectedType);
        }
      }
      var expectedTypesMessage = (expectedTypes.length > 0) ? ', expected one of type [' + expectedTypes.join(', ') + ']': '';
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`' + expectedTypesMessage + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function invalidValidatorError(componentName, location, propFullName, key, type) {
    return new PropTypeError(
      (componentName || 'React class') + ': ' + location + ' type `' + propFullName + '.' + key + '` is invalid; ' +
      'it must be a function, usually from the `prop-types` package, but received `' + type + '`.'
    );
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (typeof checker !== 'function') {
          return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (has(shapeTypes, key) && typeof checker !== 'function') {
          return invalidValidatorError(componentName, location, propFullName, key, getPreciseType(checker));
        }
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' + JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // falsy value can't be a Symbol
    if (!propValue) {
      return false;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "./node_modules/prop-types/index.js":
/*!******************************************!*\
  !*** ./node_modules/prop-types/index.js ***!
  \******************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "./node_modules/prop-types/factoryWithTypeCheckers.js")(ReactIs.isElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "./node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!*************************************************************!*\
  !*** ./node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************/
/***/ (function(module) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "./node_modules/prop-types/lib/has.js":
/*!********************************************!*\
  !*** ./node_modules/prop-types/lib/has.js ***!
  \********************************************/
/***/ (function(module) {

module.exports = Function.call.bind(Object.prototype.hasOwnProperty);


/***/ }),

/***/ "./node_modules/react-is/cjs/react-is.development.js":
/*!***********************************************************!*\
  !*** ./node_modules/react-is/cjs/react-is.development.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */





if (true) {
  (function() {
'use strict';

// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?

var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;

function isValidElementType(type) {
  return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
  type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_ASYNC_MODE_TYPE:
          case REACT_CONCURRENT_MODE_TYPE:
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
} // AsyncMode is deprecated along with isAsyncMode

var AsyncMode = REACT_ASYNC_MODE_TYPE;
var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
    }
  }

  return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
}
function isConcurrentMode(object) {
  return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.AsyncMode = AsyncMode;
exports.ConcurrentMode = ConcurrentMode;
exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "./node_modules/react-is/index.js":
/*!****************************************!*\
  !*** ./node_modules/react-is/index.js ***!
  \****************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "./node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "./node_modules/react-property/lib/index.js":
/*!**************************************************!*\
  !*** ./node_modules/react-property/lib/index.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", ({ value: true }));

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(arr, i) {
  var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];

  if (_i == null) return;
  var _arr = [];
  var _n = true;
  var _d = false;

  var _s, _e;

  try {
    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

  return arr2;
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

// A reserved attribute.
// It is handled by React separately and shouldn't be written to the DOM.
var RESERVED = 0; // A simple string attribute.
// Attributes that aren't in the filter are presumed to have this type.

var STRING = 1; // A string attribute that accepts booleans in React. In HTML, these are called
// "enumerated" attributes with "true" and "false" as possible values.
// When true, it should be set to a "true" string.
// When false, it should be set to a "false" string.

var BOOLEANISH_STRING = 2; // A real boolean attribute.
// When true, it should be present (set either to an empty string or its name).
// When false, it should be omitted.

var BOOLEAN = 3; // An attribute that can be used as a flag as well as with a value.
// When true, it should be present (set either to an empty string or its name).
// When false, it should be omitted.
// For any other value, should be present with that value.

var OVERLOADED_BOOLEAN = 4; // An attribute that must be numeric or parse as a numeric.
// When falsy, it should be removed.

var NUMERIC = 5; // An attribute that must be positive numeric or parse as a positive numeric.
// When falsy, it should be removed.

var POSITIVE_NUMERIC = 6;
function getPropertyInfo(name) {
  return properties.hasOwnProperty(name) ? properties[name] : null;
}

function PropertyInfoRecord(name, type, mustUseProperty, attributeName, attributeNamespace, sanitizeURL, removeEmptyString) {
  this.acceptsBooleans = type === BOOLEANISH_STRING || type === BOOLEAN || type === OVERLOADED_BOOLEAN;
  this.attributeName = attributeName;
  this.attributeNamespace = attributeNamespace;
  this.mustUseProperty = mustUseProperty;
  this.propertyName = name;
  this.type = type;
  this.sanitizeURL = sanitizeURL;
  this.removeEmptyString = removeEmptyString;
} // When adding attributes to this list, be sure to also add them to
// the `possibleStandardNames` module to ensure casing and incorrect
// name warnings.


var properties = {}; // These props are reserved by React. They shouldn't be written to the DOM.

var reservedProps = ['children', 'dangerouslySetInnerHTML', // TODO: This prevents the assignment of defaultValue to regular
// elements (not just inputs). Now that ReactDOMInput assigns to the
// defaultValue property -- do we need this?
'defaultValue', 'defaultChecked', 'innerHTML', 'suppressContentEditableWarning', 'suppressHydrationWarning', 'style'];
reservedProps.forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, RESERVED, false, // mustUseProperty
  name, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // A few React string attributes have a different name.
// This is a mapping from React prop names to the attribute names.

[['acceptCharset', 'accept-charset'], ['className', 'class'], ['htmlFor', 'for'], ['httpEquiv', 'http-equiv']].forEach(function (_ref) {
  var _ref2 = _slicedToArray(_ref, 2),
      name = _ref2[0],
      attributeName = _ref2[1];

  properties[name] = new PropertyInfoRecord(name, STRING, false, // mustUseProperty
  attributeName, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are "enumerated" HTML attributes that accept "true" and "false".
// In React, we let users pass `true` and `false` even though technically
// these aren't boolean attributes (they are coerced to strings).

['contentEditable', 'draggable', 'spellCheck', 'value'].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, BOOLEANISH_STRING, false, // mustUseProperty
  name.toLowerCase(), // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are "enumerated" SVG attributes that accept "true" and "false".
// In React, we let users pass `true` and `false` even though technically
// these aren't boolean attributes (they are coerced to strings).
// Since these are SVG attributes, their attribute names are case-sensitive.

['autoReverse', 'externalResourcesRequired', 'focusable', 'preserveAlpha'].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, BOOLEANISH_STRING, false, // mustUseProperty
  name, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are HTML boolean attributes.

['allowFullScreen', 'async', // Note: there is a special case that prevents it from being written to the DOM
// on the client side because the browsers are inconsistent. Instead we call focus().
'autoFocus', 'autoPlay', 'controls', 'default', 'defer', 'disabled', 'disablePictureInPicture', 'disableRemotePlayback', 'formNoValidate', 'hidden', 'loop', 'noModule', 'noValidate', 'open', 'playsInline', 'readOnly', 'required', 'reversed', 'scoped', 'seamless', // Microdata
'itemScope'].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, BOOLEAN, false, // mustUseProperty
  name.toLowerCase(), // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are the few React props that we set as DOM properties
// rather than attributes. These are all booleans.

['checked', // Note: `option.selected` is not updated if `select.multiple` is
// disabled with `removeAttribute`. We have special logic for handling this.
'multiple', 'muted', 'selected' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, BOOLEAN, true, // mustUseProperty
  name, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are HTML attributes that are "overloaded booleans": they behave like
// booleans, but can also accept a string value.

['capture', 'download' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, OVERLOADED_BOOLEAN, false, // mustUseProperty
  name, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are HTML attributes that must be positive numbers.

['cols', 'rows', 'size', 'span' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, POSITIVE_NUMERIC, false, // mustUseProperty
  name, // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These are HTML attributes that must be numbers.

['rowSpan', 'start'].forEach(function (name) {
  properties[name] = new PropertyInfoRecord(name, NUMERIC, false, // mustUseProperty
  name.toLowerCase(), // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
});
var CAMELIZE = /[\-\:]([a-z])/g;

var capitalize = function capitalize(token) {
  return token[1].toUpperCase();
}; // This is a list of all SVG attributes that need special casing, namespacing,
// or boolean value assignment. Regular attributes that just accept strings
// and have the same names are omitted, just like in the HTML attribute filter.
// Some of these attributes can be hard to find. This list was created by
// scraping the MDN documentation.


['accent-height', 'alignment-baseline', 'arabic-form', 'baseline-shift', 'cap-height', 'clip-path', 'clip-rule', 'color-interpolation', 'color-interpolation-filters', 'color-profile', 'color-rendering', 'dominant-baseline', 'enable-background', 'fill-opacity', 'fill-rule', 'flood-color', 'flood-opacity', 'font-family', 'font-size', 'font-size-adjust', 'font-stretch', 'font-style', 'font-variant', 'font-weight', 'glyph-name', 'glyph-orientation-horizontal', 'glyph-orientation-vertical', 'horiz-adv-x', 'horiz-origin-x', 'image-rendering', 'letter-spacing', 'lighting-color', 'marker-end', 'marker-mid', 'marker-start', 'overline-position', 'overline-thickness', 'paint-order', 'panose-1', 'pointer-events', 'rendering-intent', 'shape-rendering', 'stop-color', 'stop-opacity', 'strikethrough-position', 'strikethrough-thickness', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit', 'stroke-opacity', 'stroke-width', 'text-anchor', 'text-decoration', 'text-rendering', 'underline-position', 'underline-thickness', 'unicode-bidi', 'unicode-range', 'units-per-em', 'v-alphabetic', 'v-hanging', 'v-ideographic', 'v-mathematical', 'vector-effect', 'vert-adv-y', 'vert-origin-x', 'vert-origin-y', 'word-spacing', 'writing-mode', 'xmlns:xlink', 'x-height' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (attributeName) {
  var name = attributeName.replace(CAMELIZE, capitalize);
  properties[name] = new PropertyInfoRecord(name, STRING, false, // mustUseProperty
  attributeName, null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // String SVG attributes with the xlink namespace.

['xlink:actuate', 'xlink:arcrole', 'xlink:role', 'xlink:show', 'xlink:title', 'xlink:type' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (attributeName) {
  var name = attributeName.replace(CAMELIZE, capitalize);
  properties[name] = new PropertyInfoRecord(name, STRING, false, // mustUseProperty
  attributeName, 'http://www.w3.org/1999/xlink', false, // sanitizeURL
  false);
}); // String SVG attributes with the xml namespace.

['xml:base', 'xml:lang', 'xml:space' // NOTE: if you add a camelCased prop to this list,
// you'll need to set attributeName to name.toLowerCase()
// instead in the assignment below.
].forEach(function (attributeName) {
  var name = attributeName.replace(CAMELIZE, capitalize);
  properties[name] = new PropertyInfoRecord(name, STRING, false, // mustUseProperty
  attributeName, 'http://www.w3.org/XML/1998/namespace', false, // sanitizeURL
  false);
}); // These attribute exists both in HTML and SVG.
// The attribute name is case-sensitive in SVG so we can't just use
// the React name like we do for attributes that exist only in HTML.

['tabIndex', 'crossOrigin'].forEach(function (attributeName) {
  properties[attributeName] = new PropertyInfoRecord(attributeName, STRING, false, // mustUseProperty
  attributeName.toLowerCase(), // attributeName
  null, // attributeNamespace
  false, // sanitizeURL
  false);
}); // These attributes accept URLs. These must not allow javascript: URLS.
// These will also need to accept Trusted Types object in the future.

var xlinkHref = 'xlinkHref';
properties[xlinkHref] = new PropertyInfoRecord('xlinkHref', STRING, false, // mustUseProperty
'xlink:href', 'http://www.w3.org/1999/xlink', true, // sanitizeURL
false);
['src', 'href', 'action', 'formAction'].forEach(function (attributeName) {
  properties[attributeName] = new PropertyInfoRecord(attributeName, STRING, false, // mustUseProperty
  attributeName.toLowerCase(), // attributeName
  null, // attributeNamespace
  true, // sanitizeURL
  true);
});

var _require = __webpack_require__(/*! ../lib/possibleStandardNamesOptimized */ "./node_modules/react-property/lib/possibleStandardNamesOptimized.js"),
    CAMELCASE = _require.CAMELCASE,
    SAME = _require.SAME,
    possibleStandardNamesOptimized = _require.possibleStandardNames;

var ATTRIBUTE_NAME_START_CHAR = ":A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
var ATTRIBUTE_NAME_CHAR = ATTRIBUTE_NAME_START_CHAR + "\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
/**
 * Checks whether a property name is a custom attribute.
 *
 * @see {@link https://github.com/facebook/react/blob/15-stable/src/renderers/dom/shared/HTMLDOMPropertyConfig.js#L23-L25}
 *
 * @param {string}
 * @return {boolean}
 */

var isCustomAttribute = RegExp.prototype.test.bind( // eslint-disable-next-line no-misleading-character-class
new RegExp('^(data|aria)-[' + ATTRIBUTE_NAME_CHAR + ']*$'));
var possibleStandardNames = Object.keys(possibleStandardNamesOptimized).reduce(function (accumulator, standardName) {
  var propName = possibleStandardNamesOptimized[standardName];

  if (propName === SAME) {
    accumulator[standardName] = standardName;
  } else if (propName === CAMELCASE) {
    accumulator[standardName.toLowerCase()] = standardName;
  } else {
    accumulator[standardName] = propName;
  }

  return accumulator;
}, {});

exports.BOOLEAN = BOOLEAN;
exports.BOOLEANISH_STRING = BOOLEANISH_STRING;
exports.NUMERIC = NUMERIC;
exports.OVERLOADED_BOOLEAN = OVERLOADED_BOOLEAN;
exports.POSITIVE_NUMERIC = POSITIVE_NUMERIC;
exports.RESERVED = RESERVED;
exports.STRING = STRING;
exports.getPropertyInfo = getPropertyInfo;
exports.isCustomAttribute = isCustomAttribute;
exports.possibleStandardNames = possibleStandardNames;


/***/ }),

/***/ "./node_modules/react-property/lib/possibleStandardNamesOptimized.js":
/*!***************************************************************************!*\
  !*** ./node_modules/react-property/lib/possibleStandardNamesOptimized.js ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, exports) {

// An attribute in which the DOM/SVG standard name is the same as the React prop name (e.g., 'accept').
var SAME = 0;
exports.SAME = SAME;

// An attribute in which the React prop name is the camelcased version of the DOM/SVG standard name (e.g., 'acceptCharset').
var CAMELCASE = 1;
exports.CAMELCASE = CAMELCASE;

exports.possibleStandardNames = {
  accept: 0,
  acceptCharset: 1,
  'accept-charset': 'acceptCharset',
  accessKey: 1,
  action: 0,
  allowFullScreen: 1,
  alt: 0,
  as: 0,
  async: 0,
  autoCapitalize: 1,
  autoComplete: 1,
  autoCorrect: 1,
  autoFocus: 1,
  autoPlay: 1,
  autoSave: 1,
  capture: 0,
  cellPadding: 1,
  cellSpacing: 1,
  challenge: 0,
  charSet: 1,
  checked: 0,
  children: 0,
  cite: 0,
  class: 'className',
  classID: 1,
  className: 1,
  cols: 0,
  colSpan: 1,
  content: 0,
  contentEditable: 1,
  contextMenu: 1,
  controls: 0,
  controlsList: 1,
  coords: 0,
  crossOrigin: 1,
  dangerouslySetInnerHTML: 1,
  data: 0,
  dateTime: 1,
  default: 0,
  defaultChecked: 1,
  defaultValue: 1,
  defer: 0,
  dir: 0,
  disabled: 0,
  disablePictureInPicture: 1,
  disableRemotePlayback: 1,
  download: 0,
  draggable: 0,
  encType: 1,
  enterKeyHint: 1,
  for: 'htmlFor',
  form: 0,
  formMethod: 1,
  formAction: 1,
  formEncType: 1,
  formNoValidate: 1,
  formTarget: 1,
  frameBorder: 1,
  headers: 0,
  height: 0,
  hidden: 0,
  high: 0,
  href: 0,
  hrefLang: 1,
  htmlFor: 1,
  httpEquiv: 1,
  'http-equiv': 'httpEquiv',
  icon: 0,
  id: 0,
  innerHTML: 1,
  inputMode: 1,
  integrity: 0,
  is: 0,
  itemID: 1,
  itemProp: 1,
  itemRef: 1,
  itemScope: 1,
  itemType: 1,
  keyParams: 1,
  keyType: 1,
  kind: 0,
  label: 0,
  lang: 0,
  list: 0,
  loop: 0,
  low: 0,
  manifest: 0,
  marginWidth: 1,
  marginHeight: 1,
  max: 0,
  maxLength: 1,
  media: 0,
  mediaGroup: 1,
  method: 0,
  min: 0,
  minLength: 1,
  multiple: 0,
  muted: 0,
  name: 0,
  noModule: 1,
  nonce: 0,
  noValidate: 1,
  open: 0,
  optimum: 0,
  pattern: 0,
  placeholder: 0,
  playsInline: 1,
  poster: 0,
  preload: 0,
  profile: 0,
  radioGroup: 1,
  readOnly: 1,
  referrerPolicy: 1,
  rel: 0,
  required: 0,
  reversed: 0,
  role: 0,
  rows: 0,
  rowSpan: 1,
  sandbox: 0,
  scope: 0,
  scoped: 0,
  scrolling: 0,
  seamless: 0,
  selected: 0,
  shape: 0,
  size: 0,
  sizes: 0,
  span: 0,
  spellCheck: 1,
  src: 0,
  srcDoc: 1,
  srcLang: 1,
  srcSet: 1,
  start: 0,
  step: 0,
  style: 0,
  summary: 0,
  tabIndex: 1,
  target: 0,
  title: 0,
  type: 0,
  useMap: 1,
  value: 0,
  width: 0,
  wmode: 0,
  wrap: 0,
  about: 0,
  accentHeight: 1,
  'accent-height': 'accentHeight',
  accumulate: 0,
  additive: 0,
  alignmentBaseline: 1,
  'alignment-baseline': 'alignmentBaseline',
  allowReorder: 1,
  alphabetic: 0,
  amplitude: 0,
  arabicForm: 1,
  'arabic-form': 'arabicForm',
  ascent: 0,
  attributeName: 1,
  attributeType: 1,
  autoReverse: 1,
  azimuth: 0,
  baseFrequency: 1,
  baselineShift: 1,
  'baseline-shift': 'baselineShift',
  baseProfile: 1,
  bbox: 0,
  begin: 0,
  bias: 0,
  by: 0,
  calcMode: 1,
  capHeight: 1,
  'cap-height': 'capHeight',
  clip: 0,
  clipPath: 1,
  'clip-path': 'clipPath',
  clipPathUnits: 1,
  clipRule: 1,
  'clip-rule': 'clipRule',
  color: 0,
  colorInterpolation: 1,
  'color-interpolation': 'colorInterpolation',
  colorInterpolationFilters: 1,
  'color-interpolation-filters': 'colorInterpolationFilters',
  colorProfile: 1,
  'color-profile': 'colorProfile',
  colorRendering: 1,
  'color-rendering': 'colorRendering',
  contentScriptType: 1,
  contentStyleType: 1,
  cursor: 0,
  cx: 0,
  cy: 0,
  d: 0,
  datatype: 0,
  decelerate: 0,
  descent: 0,
  diffuseConstant: 1,
  direction: 0,
  display: 0,
  divisor: 0,
  dominantBaseline: 1,
  'dominant-baseline': 'dominantBaseline',
  dur: 0,
  dx: 0,
  dy: 0,
  edgeMode: 1,
  elevation: 0,
  enableBackground: 1,
  'enable-background': 'enableBackground',
  end: 0,
  exponent: 0,
  externalResourcesRequired: 1,
  fill: 0,
  fillOpacity: 1,
  'fill-opacity': 'fillOpacity',
  fillRule: 1,
  'fill-rule': 'fillRule',
  filter: 0,
  filterRes: 1,
  filterUnits: 1,
  floodOpacity: 1,
  'flood-opacity': 'floodOpacity',
  floodColor: 1,
  'flood-color': 'floodColor',
  focusable: 0,
  fontFamily: 1,
  'font-family': 'fontFamily',
  fontSize: 1,
  'font-size': 'fontSize',
  fontSizeAdjust: 1,
  'font-size-adjust': 'fontSizeAdjust',
  fontStretch: 1,
  'font-stretch': 'fontStretch',
  fontStyle: 1,
  'font-style': 'fontStyle',
  fontVariant: 1,
  'font-variant': 'fontVariant',
  fontWeight: 1,
  'font-weight': 'fontWeight',
  format: 0,
  from: 0,
  fx: 0,
  fy: 0,
  g1: 0,
  g2: 0,
  glyphName: 1,
  'glyph-name': 'glyphName',
  glyphOrientationHorizontal: 1,
  'glyph-orientation-horizontal': 'glyphOrientationHorizontal',
  glyphOrientationVertical: 1,
  'glyph-orientation-vertical': 'glyphOrientationVertical',
  glyphRef: 1,
  gradientTransform: 1,
  gradientUnits: 1,
  hanging: 0,
  horizAdvX: 1,
  'horiz-adv-x': 'horizAdvX',
  horizOriginX: 1,
  'horiz-origin-x': 'horizOriginX',
  ideographic: 0,
  imageRendering: 1,
  'image-rendering': 'imageRendering',
  in2: 0,
  in: 0,
  inlist: 0,
  intercept: 0,
  k1: 0,
  k2: 0,
  k3: 0,
  k4: 0,
  k: 0,
  kernelMatrix: 1,
  kernelUnitLength: 1,
  kerning: 0,
  keyPoints: 1,
  keySplines: 1,
  keyTimes: 1,
  lengthAdjust: 1,
  letterSpacing: 1,
  'letter-spacing': 'letterSpacing',
  lightingColor: 1,
  'lighting-color': 'lightingColor',
  limitingConeAngle: 1,
  local: 0,
  markerEnd: 1,
  'marker-end': 'markerEnd',
  markerHeight: 1,
  markerMid: 1,
  'marker-mid': 'markerMid',
  markerStart: 1,
  'marker-start': 'markerStart',
  markerUnits: 1,
  markerWidth: 1,
  mask: 0,
  maskContentUnits: 1,
  maskUnits: 1,
  mathematical: 0,
  mode: 0,
  numOctaves: 1,
  offset: 0,
  opacity: 0,
  operator: 0,
  order: 0,
  orient: 0,
  orientation: 0,
  origin: 0,
  overflow: 0,
  overlinePosition: 1,
  'overline-position': 'overlinePosition',
  overlineThickness: 1,
  'overline-thickness': 'overlineThickness',
  paintOrder: 1,
  'paint-order': 'paintOrder',
  panose1: 0,
  'panose-1': 'panose1',
  pathLength: 1,
  patternContentUnits: 1,
  patternTransform: 1,
  patternUnits: 1,
  pointerEvents: 1,
  'pointer-events': 'pointerEvents',
  points: 0,
  pointsAtX: 1,
  pointsAtY: 1,
  pointsAtZ: 1,
  prefix: 0,
  preserveAlpha: 1,
  preserveAspectRatio: 1,
  primitiveUnits: 1,
  property: 0,
  r: 0,
  radius: 0,
  refX: 1,
  refY: 1,
  renderingIntent: 1,
  'rendering-intent': 'renderingIntent',
  repeatCount: 1,
  repeatDur: 1,
  requiredExtensions: 1,
  requiredFeatures: 1,
  resource: 0,
  restart: 0,
  result: 0,
  results: 0,
  rotate: 0,
  rx: 0,
  ry: 0,
  scale: 0,
  security: 0,
  seed: 0,
  shapeRendering: 1,
  'shape-rendering': 'shapeRendering',
  slope: 0,
  spacing: 0,
  specularConstant: 1,
  specularExponent: 1,
  speed: 0,
  spreadMethod: 1,
  startOffset: 1,
  stdDeviation: 1,
  stemh: 0,
  stemv: 0,
  stitchTiles: 1,
  stopColor: 1,
  'stop-color': 'stopColor',
  stopOpacity: 1,
  'stop-opacity': 'stopOpacity',
  strikethroughPosition: 1,
  'strikethrough-position': 'strikethroughPosition',
  strikethroughThickness: 1,
  'strikethrough-thickness': 'strikethroughThickness',
  string: 0,
  stroke: 0,
  strokeDasharray: 1,
  'stroke-dasharray': 'strokeDasharray',
  strokeDashoffset: 1,
  'stroke-dashoffset': 'strokeDashoffset',
  strokeLinecap: 1,
  'stroke-linecap': 'strokeLinecap',
  strokeLinejoin: 1,
  'stroke-linejoin': 'strokeLinejoin',
  strokeMiterlimit: 1,
  'stroke-miterlimit': 'strokeMiterlimit',
  strokeWidth: 1,
  'stroke-width': 'strokeWidth',
  strokeOpacity: 1,
  'stroke-opacity': 'strokeOpacity',
  suppressContentEditableWarning: 1,
  suppressHydrationWarning: 1,
  surfaceScale: 1,
  systemLanguage: 1,
  tableValues: 1,
  targetX: 1,
  targetY: 1,
  textAnchor: 1,
  'text-anchor': 'textAnchor',
  textDecoration: 1,
  'text-decoration': 'textDecoration',
  textLength: 1,
  textRendering: 1,
  'text-rendering': 'textRendering',
  to: 0,
  transform: 0,
  typeof: 0,
  u1: 0,
  u2: 0,
  underlinePosition: 1,
  'underline-position': 'underlinePosition',
  underlineThickness: 1,
  'underline-thickness': 'underlineThickness',
  unicode: 0,
  unicodeBidi: 1,
  'unicode-bidi': 'unicodeBidi',
  unicodeRange: 1,
  'unicode-range': 'unicodeRange',
  unitsPerEm: 1,
  'units-per-em': 'unitsPerEm',
  unselectable: 0,
  vAlphabetic: 1,
  'v-alphabetic': 'vAlphabetic',
  values: 0,
  vectorEffect: 1,
  'vector-effect': 'vectorEffect',
  version: 0,
  vertAdvY: 1,
  'vert-adv-y': 'vertAdvY',
  vertOriginX: 1,
  'vert-origin-x': 'vertOriginX',
  vertOriginY: 1,
  'vert-origin-y': 'vertOriginY',
  vHanging: 1,
  'v-hanging': 'vHanging',
  vIdeographic: 1,
  'v-ideographic': 'vIdeographic',
  viewBox: 1,
  viewTarget: 1,
  visibility: 0,
  vMathematical: 1,
  'v-mathematical': 'vMathematical',
  vocab: 0,
  widths: 0,
  wordSpacing: 1,
  'word-spacing': 'wordSpacing',
  writingMode: 1,
  'writing-mode': 'writingMode',
  x1: 0,
  x2: 0,
  x: 0,
  xChannelSelector: 1,
  xHeight: 1,
  'x-height': 'xHeight',
  xlinkActuate: 1,
  'xlink:actuate': 'xlinkActuate',
  xlinkArcrole: 1,
  'xlink:arcrole': 'xlinkArcrole',
  xlinkHref: 1,
  'xlink:href': 'xlinkHref',
  xlinkRole: 1,
  'xlink:role': 'xlinkRole',
  xlinkShow: 1,
  'xlink:show': 'xlinkShow',
  xlinkTitle: 1,
  'xlink:title': 'xlinkTitle',
  xlinkType: 1,
  'xlink:type': 'xlinkType',
  xmlBase: 1,
  'xml:base': 'xmlBase',
  xmlLang: 1,
  'xml:lang': 'xmlLang',
  xmlns: 0,
  'xml:space': 'xmlSpace',
  xmlnsXlink: 1,
  'xmlns:xlink': 'xmlnsXlink',
  xmlSpace: 1,
  y1: 0,
  y2: 0,
  y: 0,
  yChannelSelector: 1,
  z: 0,
  zoomAndPan: 1
};


/***/ }),

/***/ "./node_modules/react-tooltip/dist/index.es.js":
/*!*****************************************************!*\
  !*** ./node_modules/react-tooltip/dist/index.es.js ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! uuid */ "./node_modules/uuid/dist/esm-browser/v4.js");




function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly) symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    });
    keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};

    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
      });
    }
  }

  return target;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _possibleConstructorReturn(self, call) {
  if (call && (typeof call === "object" || typeof call === "function")) {
    return call;
  }

  return _assertThisInitialized(self);
}

var CONSTANT = {
  GLOBAL: {
    HIDE: '__react_tooltip_hide_event',
    REBUILD: '__react_tooltip_rebuild_event',
    SHOW: '__react_tooltip_show_event'
  }
};

/**
 * Static methods for react-tooltip
 */

var dispatchGlobalEvent = function dispatchGlobalEvent(eventName, opts) {
  // Compatible with IE
  // @see http://stackoverflow.com/questions/26596123/internet-explorer-9-10-11-event-constructor-doesnt-work
  // @see https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/CustomEvent
  var event;

  if (typeof window.CustomEvent === 'function') {
    event = new window.CustomEvent(eventName, {
      detail: opts
    });
  } else {
    event = document.createEvent('Event');
    event.initEvent(eventName, false, true, opts);
  }

  window.dispatchEvent(event);
};

function staticMethods (target) {
  /**
   * Hide all tooltip
   * @trigger ReactTooltip.hide()
   */
  target.hide = function (target) {
    dispatchGlobalEvent(CONSTANT.GLOBAL.HIDE, {
      target: target
    });
  };
  /**
   * Rebuild all tooltip
   * @trigger ReactTooltip.rebuild()
   */


  target.rebuild = function () {
    dispatchGlobalEvent(CONSTANT.GLOBAL.REBUILD);
  };
  /**
   * Show specific tooltip
   * @trigger ReactTooltip.show()
   */


  target.show = function (target) {
    dispatchGlobalEvent(CONSTANT.GLOBAL.SHOW, {
      target: target
    });
  };

  target.prototype.globalRebuild = function () {
    if (this.mount) {
      this.unbindListener();
      this.bindListener();
    }
  };

  target.prototype.globalShow = function (event) {
    if (this.mount) {
      var hasTarget = event && event.detail && event.detail.target && true || false; // Create a fake event, specific show will limit the type to `solid`
      // only `float` type cares e.clientX e.clientY

      this.showTooltip({
        currentTarget: hasTarget && event.detail.target
      }, true);
    }
  };

  target.prototype.globalHide = function (event) {
    if (this.mount) {
      var hasTarget = event && event.detail && event.detail.target && true || false;
      this.hideTooltip({
        currentTarget: hasTarget && event.detail.target
      }, hasTarget);
    }
  };
}

/**
 * Events that should be bound to the window
 */
function windowListener (target) {
  target.prototype.bindWindowEvents = function (resizeHide) {
    // ReactTooltip.hide
    window.removeEventListener(CONSTANT.GLOBAL.HIDE, this.globalHide);
    window.addEventListener(CONSTANT.GLOBAL.HIDE, this.globalHide, false); // ReactTooltip.rebuild

    window.removeEventListener(CONSTANT.GLOBAL.REBUILD, this.globalRebuild);
    window.addEventListener(CONSTANT.GLOBAL.REBUILD, this.globalRebuild, false); // ReactTooltip.show

    window.removeEventListener(CONSTANT.GLOBAL.SHOW, this.globalShow);
    window.addEventListener(CONSTANT.GLOBAL.SHOW, this.globalShow, false); // Resize

    if (resizeHide) {
      window.removeEventListener('resize', this.onWindowResize);
      window.addEventListener('resize', this.onWindowResize, false);
    }
  };

  target.prototype.unbindWindowEvents = function () {
    window.removeEventListener(CONSTANT.GLOBAL.HIDE, this.globalHide);
    window.removeEventListener(CONSTANT.GLOBAL.REBUILD, this.globalRebuild);
    window.removeEventListener(CONSTANT.GLOBAL.SHOW, this.globalShow);
    window.removeEventListener('resize', this.onWindowResize);
  };
  /**
   * invoked by resize event of window
   */


  target.prototype.onWindowResize = function () {
    if (!this.mount) return;
    this.hideTooltip();
  };
}

/**
 * Custom events to control showing and hiding of tooltip
 *
 * @attributes
 * - `event` {String}
 * - `eventOff` {String}
 */
var checkStatus = function checkStatus(dataEventOff, e) {
  var show = this.state.show;
  var id = this.props.id;
  var isCapture = this.isCapture(e.currentTarget);
  var currentItem = e.currentTarget.getAttribute('currentItem');
  if (!isCapture) e.stopPropagation();

  if (show && currentItem === 'true') {
    if (!dataEventOff) this.hideTooltip(e);
  } else {
    e.currentTarget.setAttribute('currentItem', 'true');
    setUntargetItems(e.currentTarget, this.getTargetArray(id));
    this.showTooltip(e);
  }
};

var setUntargetItems = function setUntargetItems(currentTarget, targetArray) {
  for (var i = 0; i < targetArray.length; i++) {
    if (currentTarget !== targetArray[i]) {
      targetArray[i].setAttribute('currentItem', 'false');
    } else {
      targetArray[i].setAttribute('currentItem', 'true');
    }
  }
};

var customListeners = {
  id: '9b69f92e-d3fe-498b-b1b4-c5e63a51b0cf',
  set: function set(target, event, listener) {
    if (this.id in target) {
      var map = target[this.id];
      map[event] = listener;
    } else {
      // this is workaround for WeakMap, which is not supported in older browsers, such as IE
      Object.defineProperty(target, this.id, {
        configurable: true,
        value: _defineProperty({}, event, listener)
      });
    }
  },
  get: function get(target, event) {
    var map = target[this.id];

    if (map !== undefined) {
      return map[event];
    }
  }
};
function customEvent (target) {
  target.prototype.isCustomEvent = function (ele) {
    var event = this.state.event;
    return event || !!ele.getAttribute('data-event');
  };
  /* Bind listener for custom event */


  target.prototype.customBindListener = function (ele) {
    var _this = this;

    var _this$state = this.state,
        event = _this$state.event,
        eventOff = _this$state.eventOff;
    var dataEvent = ele.getAttribute('data-event') || event;
    var dataEventOff = ele.getAttribute('data-event-off') || eventOff;
    dataEvent.split(' ').forEach(function (event) {
      ele.removeEventListener(event, customListeners.get(ele, event));
      var customListener = checkStatus.bind(_this, dataEventOff);
      customListeners.set(ele, event, customListener);
      ele.addEventListener(event, customListener, false);
    });

    if (dataEventOff) {
      dataEventOff.split(' ').forEach(function (event) {
        ele.removeEventListener(event, _this.hideTooltip);
        ele.addEventListener(event, _this.hideTooltip, false);
      });
    }
  };
  /* Unbind listener for custom event */


  target.prototype.customUnbindListener = function (ele) {
    var _this$state2 = this.state,
        event = _this$state2.event,
        eventOff = _this$state2.eventOff;
    var dataEvent = event || ele.getAttribute('data-event');
    var dataEventOff = eventOff || ele.getAttribute('data-event-off');
    ele.removeEventListener(dataEvent, customListeners.get(ele, event));
    if (dataEventOff) ele.removeEventListener(dataEventOff, this.hideTooltip);
  };
}

/**
 * Util method to judge if it should follow capture model
 */
function isCapture (target) {
  target.prototype.isCapture = function (currentTarget) {
    return currentTarget && currentTarget.getAttribute('data-iscapture') === 'true' || this.props.isCapture || false;
  };
}

/**
 * Util method to get effect
 */
function getEffect (target) {
  target.prototype.getEffect = function (currentTarget) {
    var dataEffect = currentTarget.getAttribute('data-effect');
    return dataEffect || this.props.effect || 'float';
  };
}

/**
 * Util method to get effect
 */

var makeProxy = function makeProxy(e) {
  var proxy = {};

  for (var key in e) {
    if (typeof e[key] === 'function') {
      proxy[key] = e[key].bind(e);
    } else {
      proxy[key] = e[key];
    }
  }

  return proxy;
};

var bodyListener = function bodyListener(callback, options, e) {
  var _options$respectEffec = options.respectEffect,
      respectEffect = _options$respectEffec === void 0 ? false : _options$respectEffec,
      _options$customEvent = options.customEvent,
      customEvent = _options$customEvent === void 0 ? false : _options$customEvent;
  var id = this.props.id;
  var tip = e.target.getAttribute('data-tip') || null;
  var forId = e.target.getAttribute('data-for') || null;
  var target = e.target;

  if (this.isCustomEvent(target) && !customEvent) {
    return;
  }

  var isTargetBelongsToTooltip = id == null && forId == null || forId === id;

  if (tip != null && (!respectEffect || this.getEffect(target) === 'float') && isTargetBelongsToTooltip) {
    var proxy = makeProxy(e);
    proxy.currentTarget = target;
    callback(proxy);
  }
};

var findCustomEvents = function findCustomEvents(targetArray, dataAttribute) {
  var events = {};
  targetArray.forEach(function (target) {
    var event = target.getAttribute(dataAttribute);
    if (event) event.split(' ').forEach(function (event) {
      return events[event] = true;
    });
  });
  return events;
};

var getBody = function getBody() {
  return document.getElementsByTagName('body')[0];
};

function bodyMode (target) {
  target.prototype.isBodyMode = function () {
    return !!this.props.bodyMode;
  };

  target.prototype.bindBodyListener = function (targetArray) {
    var _this = this;

    var _this$state = this.state,
        event = _this$state.event,
        eventOff = _this$state.eventOff,
        possibleCustomEvents = _this$state.possibleCustomEvents,
        possibleCustomEventsOff = _this$state.possibleCustomEventsOff;
    var body = getBody();
    var customEvents = findCustomEvents(targetArray, 'data-event');
    var customEventsOff = findCustomEvents(targetArray, 'data-event-off');
    if (event != null) customEvents[event] = true;
    if (eventOff != null) customEventsOff[eventOff] = true;
    possibleCustomEvents.split(' ').forEach(function (event) {
      return customEvents[event] = true;
    });
    possibleCustomEventsOff.split(' ').forEach(function (event) {
      return customEventsOff[event] = true;
    });
    this.unbindBodyListener(body);
    var listeners = this.bodyModeListeners = {};

    if (event == null) {
      listeners.mouseover = bodyListener.bind(this, this.showTooltip, {});
      listeners.mousemove = bodyListener.bind(this, this.updateTooltip, {
        respectEffect: true
      });
      listeners.mouseout = bodyListener.bind(this, this.hideTooltip, {});
    }

    for (var _event in customEvents) {
      listeners[_event] = bodyListener.bind(this, function (e) {
        var targetEventOff = e.currentTarget.getAttribute('data-event-off') || eventOff;
        checkStatus.call(_this, targetEventOff, e);
      }, {
        customEvent: true
      });
    }

    for (var _event2 in customEventsOff) {
      listeners[_event2] = bodyListener.bind(this, this.hideTooltip, {
        customEvent: true
      });
    }

    for (var _event3 in listeners) {
      body.addEventListener(_event3, listeners[_event3]);
    }
  };

  target.prototype.unbindBodyListener = function (body) {
    body = body || getBody();
    var listeners = this.bodyModeListeners;

    for (var event in listeners) {
      body.removeEventListener(event, listeners[event]);
    }
  };
}

/**
 * Tracking target removing from DOM.
 * It's necessary to hide tooltip when it's target disappears.
 * Otherwise, the tooltip would be shown forever until another target
 * is triggered.
 *
 * If MutationObserver is not available, this feature just doesn't work.
 */
// https://hacks.mozilla.org/2012/05/dom-mutationobserver-reacting-to-dom-changes-without-killing-browser-performance/
var getMutationObserverClass = function getMutationObserverClass() {
  return window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver;
};

function trackRemoval (target) {
  target.prototype.bindRemovalTracker = function () {
    var _this = this;

    var MutationObserver = getMutationObserverClass();
    if (MutationObserver == null) return;
    var observer = new MutationObserver(function (mutations) {
      for (var m1 = 0; m1 < mutations.length; m1++) {
        var mutation = mutations[m1];

        for (var m2 = 0; m2 < mutation.removedNodes.length; m2++) {
          var element = mutation.removedNodes[m2];

          if (element === _this.state.currentTarget) {
            _this.hideTooltip();

            return;
          }
        }
      }
    });
    observer.observe(window.document, {
      childList: true,
      subtree: true
    });
    this.removalTracker = observer;
  };

  target.prototype.unbindRemovalTracker = function () {
    if (this.removalTracker) {
      this.removalTracker.disconnect();
      this.removalTracker = null;
    }
  };
}

/**
 * Calculate the position of tooltip
 *
 * @params
 * - `e` {Event} the event of current mouse
 * - `target` {Element} the currentTarget of the event
 * - `node` {DOM} the react-tooltip object
 * - `place` {String} top / right / bottom / left
 * - `effect` {String} float / solid
 * - `offset` {Object} the offset to default position
 *
 * @return {Object}
 * - `isNewState` {Bool} required
 * - `newState` {Object}
 * - `position` {Object} {left: {Number}, top: {Number}}
 */
function getPosition (e, target, node, place, desiredPlace, effect, offset) {
  var _getDimensions = getDimensions(node),
      tipWidth = _getDimensions.width,
      tipHeight = _getDimensions.height;

  var _getDimensions2 = getDimensions(target),
      targetWidth = _getDimensions2.width,
      targetHeight = _getDimensions2.height;

  var _getCurrentOffset = getCurrentOffset(e, target, effect),
      mouseX = _getCurrentOffset.mouseX,
      mouseY = _getCurrentOffset.mouseY;

  var defaultOffset = getDefaultPosition(effect, targetWidth, targetHeight, tipWidth, tipHeight);

  var _calculateOffset = calculateOffset(offset),
      extraOffsetX = _calculateOffset.extraOffsetX,
      extraOffsetY = _calculateOffset.extraOffsetY;

  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;

  var _getParent = getParent(node),
      parentTop = _getParent.parentTop,
      parentLeft = _getParent.parentLeft; // Get the edge offset of the tooltip


  var getTipOffsetLeft = function getTipOffsetLeft(place) {
    var offsetX = defaultOffset[place].l;
    return mouseX + offsetX + extraOffsetX;
  };

  var getTipOffsetRight = function getTipOffsetRight(place) {
    var offsetX = defaultOffset[place].r;
    return mouseX + offsetX + extraOffsetX;
  };

  var getTipOffsetTop = function getTipOffsetTop(place) {
    var offsetY = defaultOffset[place].t;
    return mouseY + offsetY + extraOffsetY;
  };

  var getTipOffsetBottom = function getTipOffsetBottom(place) {
    var offsetY = defaultOffset[place].b;
    return mouseY + offsetY + extraOffsetY;
  }; //
  // Functions to test whether the tooltip's sides are inside
  // the client window for a given orientation p
  //
  //  _____________
  // |             | <-- Right side
  // | p = 'left'  |\
  // |             |/  |\
  // |_____________|   |_\  <-- Mouse
  //      / \           |
  //       |
  //       |
  //  Bottom side
  //


  var outsideLeft = function outsideLeft(p) {
    return getTipOffsetLeft(p) < 0;
  };

  var outsideRight = function outsideRight(p) {
    return getTipOffsetRight(p) > windowWidth;
  };

  var outsideTop = function outsideTop(p) {
    return getTipOffsetTop(p) < 0;
  };

  var outsideBottom = function outsideBottom(p) {
    return getTipOffsetBottom(p) > windowHeight;
  }; // Check whether the tooltip with orientation p is completely inside the client window


  var outside = function outside(p) {
    return outsideLeft(p) || outsideRight(p) || outsideTop(p) || outsideBottom(p);
  };

  var inside = function inside(p) {
    return !outside(p);
  };

  var placesList = ['top', 'bottom', 'left', 'right'];
  var insideList = [];

  for (var i = 0; i < 4; i++) {
    var p = placesList[i];

    if (inside(p)) {
      insideList.push(p);
    }
  }

  var isNewState = false;
  var newPlace;
  var shouldUpdatePlace = desiredPlace !== place;

  if (inside(desiredPlace) && shouldUpdatePlace) {
    isNewState = true;
    newPlace = desiredPlace;
  } else if (insideList.length > 0 && outside(desiredPlace) && outside(place)) {
    isNewState = true;
    newPlace = insideList[0];
  }

  if (isNewState) {
    return {
      isNewState: true,
      newState: {
        place: newPlace
      }
    };
  }

  return {
    isNewState: false,
    position: {
      left: parseInt(getTipOffsetLeft(place) - parentLeft, 10),
      top: parseInt(getTipOffsetTop(place) - parentTop, 10)
    }
  };
}

var getDimensions = function getDimensions(node) {
  var _node$getBoundingClie = node.getBoundingClientRect(),
      height = _node$getBoundingClie.height,
      width = _node$getBoundingClie.width;

  return {
    height: parseInt(height, 10),
    width: parseInt(width, 10)
  };
}; // Get current mouse offset


var getCurrentOffset = function getCurrentOffset(e, currentTarget, effect) {
  var boundingClientRect = currentTarget.getBoundingClientRect();
  var targetTop = boundingClientRect.top;
  var targetLeft = boundingClientRect.left;

  var _getDimensions3 = getDimensions(currentTarget),
      targetWidth = _getDimensions3.width,
      targetHeight = _getDimensions3.height;

  if (effect === 'float') {
    return {
      mouseX: e.clientX,
      mouseY: e.clientY
    };
  }

  return {
    mouseX: targetLeft + targetWidth / 2,
    mouseY: targetTop + targetHeight / 2
  };
}; // List all possibility of tooltip final offset
// This is useful in judging if it is necessary for tooltip to switch position when out of window


var getDefaultPosition = function getDefaultPosition(effect, targetWidth, targetHeight, tipWidth, tipHeight) {
  var top;
  var right;
  var bottom;
  var left;
  var disToMouse = 3;
  var triangleHeight = 2;
  var cursorHeight = 12; // Optimize for float bottom only, cause the cursor will hide the tooltip

  if (effect === 'float') {
    top = {
      l: -(tipWidth / 2),
      r: tipWidth / 2,
      t: -(tipHeight + disToMouse + triangleHeight),
      b: -disToMouse
    };
    bottom = {
      l: -(tipWidth / 2),
      r: tipWidth / 2,
      t: disToMouse + cursorHeight,
      b: tipHeight + disToMouse + triangleHeight + cursorHeight
    };
    left = {
      l: -(tipWidth + disToMouse + triangleHeight),
      r: -disToMouse,
      t: -(tipHeight / 2),
      b: tipHeight / 2
    };
    right = {
      l: disToMouse,
      r: tipWidth + disToMouse + triangleHeight,
      t: -(tipHeight / 2),
      b: tipHeight / 2
    };
  } else if (effect === 'solid') {
    top = {
      l: -(tipWidth / 2),
      r: tipWidth / 2,
      t: -(targetHeight / 2 + tipHeight + triangleHeight),
      b: -(targetHeight / 2)
    };
    bottom = {
      l: -(tipWidth / 2),
      r: tipWidth / 2,
      t: targetHeight / 2,
      b: targetHeight / 2 + tipHeight + triangleHeight
    };
    left = {
      l: -(tipWidth + targetWidth / 2 + triangleHeight),
      r: -(targetWidth / 2),
      t: -(tipHeight / 2),
      b: tipHeight / 2
    };
    right = {
      l: targetWidth / 2,
      r: tipWidth + targetWidth / 2 + triangleHeight,
      t: -(tipHeight / 2),
      b: tipHeight / 2
    };
  }

  return {
    top: top,
    bottom: bottom,
    left: left,
    right: right
  };
}; // Consider additional offset into position calculation


var calculateOffset = function calculateOffset(offset) {
  var extraOffsetX = 0;
  var extraOffsetY = 0;

  if (Object.prototype.toString.apply(offset) === '[object String]') {
    offset = JSON.parse(offset.toString().replace(/'/g, '"'));
  }

  for (var key in offset) {
    if (key === 'top') {
      extraOffsetY -= parseInt(offset[key], 10);
    } else if (key === 'bottom') {
      extraOffsetY += parseInt(offset[key], 10);
    } else if (key === 'left') {
      extraOffsetX -= parseInt(offset[key], 10);
    } else if (key === 'right') {
      extraOffsetX += parseInt(offset[key], 10);
    }
  }

  return {
    extraOffsetX: extraOffsetX,
    extraOffsetY: extraOffsetY
  };
}; // Get the offset of the parent elements


var getParent = function getParent(currentTarget) {
  var currentParent = currentTarget;

  while (currentParent) {
    var computedStyle = window.getComputedStyle(currentParent); // transform and will-change: transform change the containing block
    // https://developer.mozilla.org/en-US/docs/Web/CSS/Containing_Block

    if (computedStyle.getPropertyValue('transform') !== 'none' || computedStyle.getPropertyValue('will-change') === 'transform') break;
    currentParent = currentParent.parentElement;
  }

  var parentTop = currentParent && currentParent.getBoundingClientRect().top || 0;
  var parentLeft = currentParent && currentParent.getBoundingClientRect().left || 0;
  return {
    parentTop: parentTop,
    parentLeft: parentLeft
  };
};

/**
 * To get the tooltip content
 * it may comes from data-tip or this.props.children
 * it should support multiline
 *
 * @params
 * - `tip` {String} value of data-tip
 * - `children` {ReactElement} this.props.children
 * - `multiline` {Any} could be Bool(true/false) or String('true'/'false')
 *
 * @return
 * - String or react component
 */
function getTipContent (tip, children, getContent, multiline) {
  if (children) return children;
  if (getContent !== undefined && getContent !== null) return getContent; // getContent can be 0, '', etc.

  if (getContent === null) return null; // Tip not exist and children is null or undefined

  var regexp = /<br\s*\/?>/;

  if (!multiline || multiline === 'false' || !regexp.test(tip)) {
    // No trim(), so that user can keep their input
    return tip;
  } // Multiline tooltip content


  return tip.split(regexp).map(function (d, i) {
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", {
      key: i,
      className: "multi-line"
    }, d);
  });
}

/**
 * Support aria- and role in ReactTooltip
 *
 * @params props {Object}
 * @return {Object}
 */
function parseAria(props) {
  var ariaObj = {};
  Object.keys(props).filter(function (prop) {
    // aria-xxx and role is acceptable
    return /(^aria-\w+$|^role$)/.test(prop);
  }).forEach(function (prop) {
    ariaObj[prop] = props[prop];
  });
  return ariaObj;
}

/**
 * Convert nodelist to array
 * @see https://github.com/facebook/fbjs/blob/e66ba20ad5be433eb54423f2b097d829324d9de6/packages/fbjs/src/core/createArrayFromMixed.js#L24
 * NodeLists are functions in Safari
 */
function nodeListToArray (nodeList) {
  var length = nodeList.length;

  if (nodeList.hasOwnProperty) {
    return Array.prototype.slice.call(nodeList);
  }

  return new Array(length).fill().map(function (index) {
    return nodeList[index];
  });
}

function generateUUID() {
  return 't' + (0,uuid__WEBPACK_IMPORTED_MODULE_1__["default"])();
}

var baseCss = ".__react_component_tooltip {\n  border-radius: 3px;\n  display: inline-block;\n  font-size: 13px;\n  left: -999em;\n  opacity: 0;\n  padding: 8px 21px;\n  position: fixed;\n  pointer-events: none;\n  transition: opacity 0.3s ease-out;\n  top: -999em;\n  visibility: hidden;\n  z-index: 999;\n}\n.__react_component_tooltip.allow_hover, .__react_component_tooltip.allow_click {\n  pointer-events: auto;\n}\n.__react_component_tooltip::before, .__react_component_tooltip::after {\n  content: \"\";\n  width: 0;\n  height: 0;\n  position: absolute;\n}\n.__react_component_tooltip.show {\n  opacity: 0.9;\n  margin-top: 0;\n  margin-left: 0;\n  visibility: visible;\n}\n.__react_component_tooltip.place-top::before {\n  border-left: 10px solid transparent;\n  border-right: 10px solid transparent;\n  bottom: -8px;\n  left: 50%;\n  margin-left: -10px;\n}\n.__react_component_tooltip.place-bottom::before {\n  border-left: 10px solid transparent;\n  border-right: 10px solid transparent;\n  top: -8px;\n  left: 50%;\n  margin-left: -10px;\n}\n.__react_component_tooltip.place-left::before {\n  border-top: 6px solid transparent;\n  border-bottom: 6px solid transparent;\n  right: -8px;\n  top: 50%;\n  margin-top: -5px;\n}\n.__react_component_tooltip.place-right::before {\n  border-top: 6px solid transparent;\n  border-bottom: 6px solid transparent;\n  left: -8px;\n  top: 50%;\n  margin-top: -5px;\n}\n.__react_component_tooltip .multi-line {\n  display: block;\n  padding: 2px 0;\n  text-align: center;\n}";

/**
 * Default pop-up style values (text color, background color).
 */
var defaultColors = {
  dark: {
    text: '#fff',
    background: '#222',
    border: 'transparent',
    arrow: '#222'
  },
  success: {
    text: '#fff',
    background: '#8DC572',
    border: 'transparent',
    arrow: '#8DC572'
  },
  warning: {
    text: '#fff',
    background: '#F0AD4E',
    border: 'transparent',
    arrow: '#F0AD4E'
  },
  error: {
    text: '#fff',
    background: '#BE6464',
    border: 'transparent',
    arrow: '#BE6464'
  },
  info: {
    text: '#fff',
    background: '#337AB7',
    border: 'transparent',
    arrow: '#337AB7'
  },
  light: {
    text: '#222',
    background: '#fff',
    border: 'transparent',
    arrow: '#fff'
  }
};
function getDefaultPopupColors(type) {
  return defaultColors[type] ? _objectSpread2({}, defaultColors[type]) : undefined;
}

/**
 * Generates the specific tooltip style for use on render.
 */

function generateTooltipStyle(uuid, customColors, type, hasBorder) {
  return generateStyle(uuid, getPopupColors(customColors, type, hasBorder));
}
/**
 * Generates the tooltip style rules based on the element-specified "data-type" property.
 */

function generateStyle(uuid, colors) {
  var textColor = colors.text;
  var backgroundColor = colors.background;
  var borderColor = colors.border;
  var arrowColor = colors.arrow;
  return "\n  \t.".concat(uuid, " {\n\t    color: ").concat(textColor, ";\n\t    background: ").concat(backgroundColor, ";\n\t    border: 1px solid ").concat(borderColor, ";\n  \t}\n\n  \t.").concat(uuid, ".place-top {\n        margin-top: -10px;\n    }\n    .").concat(uuid, ".place-top::before {\n        border-top: 8px solid ").concat(borderColor, ";\n    }\n    .").concat(uuid, ".place-top::after {\n        border-left: 8px solid transparent;\n        border-right: 8px solid transparent;\n        bottom: -6px;\n        left: 50%;\n        margin-left: -8px;\n        border-top-color: ").concat(arrowColor, ";\n        border-top-style: solid;\n        border-top-width: 6px;\n    }\n\n    .").concat(uuid, ".place-bottom {\n        margin-top: 10px;\n    }\n    .").concat(uuid, ".place-bottom::before {\n        border-bottom: 8px solid ").concat(borderColor, ";\n    }\n    .").concat(uuid, ".place-bottom::after {\n        border-left: 8px solid transparent;\n        border-right: 8px solid transparent;\n        top: -6px;\n        left: 50%;\n        margin-left: -8px;\n        border-bottom-color: ").concat(arrowColor, ";\n        border-bottom-style: solid;\n        border-bottom-width: 6px;\n    }\n\n    .").concat(uuid, ".place-left {\n        margin-left: -10px;\n    }\n    .").concat(uuid, ".place-left::before {\n        border-left: 8px solid ").concat(borderColor, ";\n    }\n    .").concat(uuid, ".place-left::after {\n        border-top: 5px solid transparent;\n        border-bottom: 5px solid transparent;\n        right: -6px;\n        top: 50%;\n        margin-top: -4px;\n        border-left-color: ").concat(arrowColor, ";\n        border-left-style: solid;\n        border-left-width: 6px;\n    }\n\n    .").concat(uuid, ".place-right {\n        margin-left: 10px;\n    }\n    .").concat(uuid, ".place-right::before {\n        border-right: 8px solid ").concat(borderColor, ";\n    }\n    .").concat(uuid, ".place-right::after {\n        border-top: 5px solid transparent;\n        border-bottom: 5px solid transparent;\n        left: -6px;\n        top: 50%;\n        margin-top: -4px;\n        border-right-color: ").concat(arrowColor, ";\n        border-right-style: solid;\n        border-right-width: 6px;\n    }\n  ");
}

function getPopupColors(customColors, type, hasBorder) {
  var textColor = customColors.text;
  var backgroundColor = customColors.background;
  var borderColor = customColors.border;
  var arrowColor = customColors.arrow ? customColors.arrow : customColors.background;
  var colors = getDefaultPopupColors(type);

  if (textColor) {
    colors.text = textColor;
  }

  if (backgroundColor) {
    colors.background = backgroundColor;
  }

  if (hasBorder) {
    if (borderColor) {
      colors.border = borderColor;
    } else {
      colors.border = type === 'light' ? 'black' : 'white';
    }
  }

  if (arrowColor) {
    colors.arrow = arrowColor;
  }

  return colors;
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof __webpack_require__.g !== 'undefined' ? __webpack_require__.g : typeof self !== 'undefined' ? self : {};

function createCommonjsModule(fn, module) {
	return module = { exports: {} }, fn(module, module.exports), module.exports;
}

var check = function (it) {
  return it && it.Math == Math && it;
};

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
var global_1 =
  // eslint-disable-next-line es/no-global-this -- safe
  check(typeof globalThis == 'object' && globalThis) ||
  check(typeof window == 'object' && window) ||
  // eslint-disable-next-line no-restricted-globals -- safe
  check(typeof self == 'object' && self) ||
  check(typeof commonjsGlobal == 'object' && commonjsGlobal) ||
  // eslint-disable-next-line no-new-func -- fallback
  (function () { return this; })() || Function('return this')();

var fails = function (exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};

// Detect IE8's incomplete defineProperty implementation
var descriptors = !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty({}, 1, { get: function () { return 7; } })[1] != 7;
});

var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({ 1: 2 }, 1);

// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
var f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;

var objectPropertyIsEnumerable = {
	f: f
};

var createPropertyDescriptor = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

var toString = {}.toString;

var classofRaw = function (it) {
  return toString.call(it).slice(8, -1);
};

var split = ''.split;

// fallback for non-array-like ES3 and non-enumerable old V8 strings
var indexedObject = fails(function () {
  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
  // eslint-disable-next-line no-prototype-builtins -- safe
  return !Object('z').propertyIsEnumerable(0);
}) ? function (it) {
  return classofRaw(it) == 'String' ? split.call(it, '') : Object(it);
} : Object;

// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
var requireObjectCoercible = function (it) {
  if (it == undefined) throw TypeError("Can't call method on " + it);
  return it;
};

// toObject with fallback for non-array-like ES3 strings



var toIndexedObject = function (it) {
  return indexedObject(requireObjectCoercible(it));
};

var isObject = function (it) {
  return typeof it === 'object' ? it !== null : typeof it === 'function';
};

// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
// instead of the ES6 spec version, we didn't implement @@toPrimitive case
// and the second argument - flag - preferred type is a string
var toPrimitive = function (input, PREFERRED_STRING) {
  if (!isObject(input)) return input;
  var fn, val;
  if (PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
  if (typeof (fn = input.valueOf) == 'function' && !isObject(val = fn.call(input))) return val;
  if (!PREFERRED_STRING && typeof (fn = input.toString) == 'function' && !isObject(val = fn.call(input))) return val;
  throw TypeError("Can't convert object to primitive value");
};

// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
var toObject = function (argument) {
  return Object(requireObjectCoercible(argument));
};

var hasOwnProperty = {}.hasOwnProperty;

var has = function hasOwn(it, key) {
  return hasOwnProperty.call(toObject(it), key);
};

var document$1 = global_1.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document$1) && isObject(document$1.createElement);

var documentCreateElement = function (it) {
  return EXISTS ? document$1.createElement(it) : {};
};

// Thank's IE8 for his funny defineProperty
var ie8DomDefine = !descriptors && !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- requied for testing
  return Object.defineProperty(documentCreateElement('div'), 'a', {
    get: function () { return 7; }
  }).a != 7;
});

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
var f$1 = descriptors ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPrimitive(P, true);
  if (ie8DomDefine) try {
    return $getOwnPropertyDescriptor(O, P);
  } catch (error) { /* empty */ }
  if (has(O, P)) return createPropertyDescriptor(!objectPropertyIsEnumerable.f.call(O, P), O[P]);
};

var objectGetOwnPropertyDescriptor = {
	f: f$1
};

var anObject = function (it) {
  if (!isObject(it)) {
    throw TypeError(String(it) + ' is not an object');
  } return it;
};

// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;

// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
var f$2 = descriptors ? $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPrimitive(P, true);
  anObject(Attributes);
  if (ie8DomDefine) try {
    return $defineProperty(O, P, Attributes);
  } catch (error) { /* empty */ }
  if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

var objectDefineProperty = {
	f: f$2
};

var createNonEnumerableProperty = descriptors ? function (object, key, value) {
  return objectDefineProperty.f(object, key, createPropertyDescriptor(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

var setGlobal = function (key, value) {
  try {
    createNonEnumerableProperty(global_1, key, value);
  } catch (error) {
    global_1[key] = value;
  } return value;
};

var SHARED = '__core-js_shared__';
var store = global_1[SHARED] || setGlobal(SHARED, {});

var sharedStore = store;

var functionToString = Function.toString;

// this helper broken in `3.4.1-3.4.4`, so we can't use `shared` helper
if (typeof sharedStore.inspectSource != 'function') {
  sharedStore.inspectSource = function (it) {
    return functionToString.call(it);
  };
}

var inspectSource = sharedStore.inspectSource;

var WeakMap = global_1.WeakMap;

var nativeWeakMap = typeof WeakMap === 'function' && /native code/.test(inspectSource(WeakMap));

var shared = createCommonjsModule(function (module) {
(module.exports = function (key, value) {
  return sharedStore[key] || (sharedStore[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: '3.12.1',
  mode:  'global',
  copyright: '© 2021 Denis Pushkarev (zloirock.ru)'
});
});

var id = 0;
var postfix = Math.random();

var uid = function (key) {
  return 'Symbol(' + String(key === undefined ? '' : key) + ')_' + (++id + postfix).toString(36);
};

var keys = shared('keys');

var sharedKey = function (key) {
  return keys[key] || (keys[key] = uid(key));
};

var hiddenKeys = {};

var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
var WeakMap$1 = global_1.WeakMap;
var set, get, has$1;

var enforce = function (it) {
  return has$1(it) ? get(it) : set(it, {});
};

var getterFor = function (TYPE) {
  return function (it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
    } return state;
  };
};

if (nativeWeakMap || sharedStore.state) {
  var store$1 = sharedStore.state || (sharedStore.state = new WeakMap$1());
  var wmget = store$1.get;
  var wmhas = store$1.has;
  var wmset = store$1.set;
  set = function (it, metadata) {
    if (wmhas.call(store$1, it)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    wmset.call(store$1, it, metadata);
    return metadata;
  };
  get = function (it) {
    return wmget.call(store$1, it) || {};
  };
  has$1 = function (it) {
    return wmhas.call(store$1, it);
  };
} else {
  var STATE = sharedKey('state');
  hiddenKeys[STATE] = true;
  set = function (it, metadata) {
    if (has(it, STATE)) throw new TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function (it) {
    return has(it, STATE) ? it[STATE] : {};
  };
  has$1 = function (it) {
    return has(it, STATE);
  };
}

var internalState = {
  set: set,
  get: get,
  has: has$1,
  enforce: enforce,
  getterFor: getterFor
};

var redefine = createCommonjsModule(function (module) {
var getInternalState = internalState.get;
var enforceInternalState = internalState.enforce;
var TEMPLATE = String(String).split('String');

(module.exports = function (O, key, value, options) {
  var unsafe = options ? !!options.unsafe : false;
  var simple = options ? !!options.enumerable : false;
  var noTargetGet = options ? !!options.noTargetGet : false;
  var state;
  if (typeof value == 'function') {
    if (typeof key == 'string' && !has(value, 'name')) {
      createNonEnumerableProperty(value, 'name', key);
    }
    state = enforceInternalState(value);
    if (!state.source) {
      state.source = TEMPLATE.join(typeof key == 'string' ? key : '');
    }
  }
  if (O === global_1) {
    if (simple) O[key] = value;
    else setGlobal(key, value);
    return;
  } else if (!unsafe) {
    delete O[key];
  } else if (!noTargetGet && O[key]) {
    simple = true;
  }
  if (simple) O[key] = value;
  else createNonEnumerableProperty(O, key, value);
// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
})(Function.prototype, 'toString', function toString() {
  return typeof this == 'function' && getInternalState(this).source || inspectSource(this);
});
});

var path = global_1;

var aFunction = function (variable) {
  return typeof variable == 'function' ? variable : undefined;
};

var getBuiltIn = function (namespace, method) {
  return arguments.length < 2 ? aFunction(path[namespace]) || aFunction(global_1[namespace])
    : path[namespace] && path[namespace][method] || global_1[namespace] && global_1[namespace][method];
};

var ceil = Math.ceil;
var floor = Math.floor;

// `ToInteger` abstract operation
// https://tc39.es/ecma262/#sec-tointeger
var toInteger = function (argument) {
  return isNaN(argument = +argument) ? 0 : (argument > 0 ? floor : ceil)(argument);
};

var min = Math.min;

// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
var toLength = function (argument) {
  return argument > 0 ? min(toInteger(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};

var max = Math.max;
var min$1 = Math.min;

// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
var toAbsoluteIndex = function (index, length) {
  var integer = toInteger(index);
  return integer < 0 ? max(integer + length, 0) : min$1(integer, length);
};

// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = toLength(O.length);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare -- NaN check
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare -- NaN check
      if (value != value) return true;
    // Array#indexOf ignores holes, Array#includes - not
    } else for (;length > index; index++) {
      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
    } return !IS_INCLUDES && -1;
  };
};

var arrayIncludes = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: createMethod(true),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: createMethod(false)
};

var indexOf = arrayIncludes.indexOf;


var objectKeysInternal = function (object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) !has(hiddenKeys, key) && has(O, key) && result.push(key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (has(O, key = names[i++])) {
    ~indexOf(result, key) || result.push(key);
  }
  return result;
};

// IE8- don't enum bug keys
var enumBugKeys = [
  'constructor',
  'hasOwnProperty',
  'isPrototypeOf',
  'propertyIsEnumerable',
  'toLocaleString',
  'toString',
  'valueOf'
];

var hiddenKeys$1 = enumBugKeys.concat('length', 'prototype');

// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
var f$3 = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return objectKeysInternal(O, hiddenKeys$1);
};

var objectGetOwnPropertyNames = {
	f: f$3
};

// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
var f$4 = Object.getOwnPropertySymbols;

var objectGetOwnPropertySymbols = {
	f: f$4
};

// all object keys, includes non-enumerable and symbols
var ownKeys$1 = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
  var keys = objectGetOwnPropertyNames.f(anObject(it));
  var getOwnPropertySymbols = objectGetOwnPropertySymbols.f;
  return getOwnPropertySymbols ? keys.concat(getOwnPropertySymbols(it)) : keys;
};

var copyConstructorProperties = function (target, source) {
  var keys = ownKeys$1(source);
  var defineProperty = objectDefineProperty.f;
  var getOwnPropertyDescriptor = objectGetOwnPropertyDescriptor.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!has(target, key)) defineProperty(target, key, getOwnPropertyDescriptor(source, key));
  }
};

var replacement = /#|\.prototype\./;

var isForced = function (feature, detection) {
  var value = data[normalize(feature)];
  return value == POLYFILL ? true
    : value == NATIVE ? false
    : typeof detection == 'function' ? fails(detection)
    : !!detection;
};

var normalize = isForced.normalize = function (string) {
  return String(string).replace(replacement, '.').toLowerCase();
};

var data = isForced.data = {};
var NATIVE = isForced.NATIVE = 'N';
var POLYFILL = isForced.POLYFILL = 'P';

var isForced_1 = isForced;

var getOwnPropertyDescriptor$1 = objectGetOwnPropertyDescriptor.f;






/*
  options.target      - name of the target object
  options.global      - target is the global object
  options.stat        - export as static methods of target
  options.proto       - export as prototype methods of target
  options.real        - real prototype method for the `pure` version
  options.forced      - export even if the native feature is available
  options.bind        - bind methods to the target, required for the `pure` version
  options.wrap        - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe      - use the simple assignment of property instead of delete + defineProperty
  options.sham        - add a flag to not completely full polyfills
  options.enumerable  - export as enumerable property
  options.noTargetGet - prevent calling a getter on target
*/
var _export = function (options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = global_1;
  } else if (STATIC) {
    target = global_1[TARGET] || setGlobal(TARGET, {});
  } else {
    target = (global_1[TARGET] || {}).prototype;
  }
  if (target) for (key in source) {
    sourceProperty = source[key];
    if (options.noTargetGet) {
      descriptor = getOwnPropertyDescriptor$1(target, key);
      targetProperty = descriptor && descriptor.value;
    } else targetProperty = target[key];
    FORCED = isForced_1(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
    // contained in target
    if (!FORCED && targetProperty !== undefined) {
      if (typeof sourceProperty === typeof targetProperty) continue;
      copyConstructorProperties(sourceProperty, targetProperty);
    }
    // add a flag to not completely full polyfills
    if (options.sham || (targetProperty && targetProperty.sham)) {
      createNonEnumerableProperty(sourceProperty, 'sham', true);
    }
    // extend global
    redefine(target, key, sourceProperty, options);
  }
};

var aFunction$1 = function (it) {
  if (typeof it != 'function') {
    throw TypeError(String(it) + ' is not a function');
  } return it;
};

// optional / simple context binding
var functionBindContext = function (fn, that, length) {
  aFunction$1(fn);
  if (that === undefined) return fn;
  switch (length) {
    case 0: return function () {
      return fn.call(that);
    };
    case 1: return function (a) {
      return fn.call(that, a);
    };
    case 2: return function (a, b) {
      return fn.call(that, a, b);
    };
    case 3: return function (a, b, c) {
      return fn.call(that, a, b, c);
    };
  }
  return function (/* ...args */) {
    return fn.apply(that, arguments);
  };
};

// `IsArray` abstract operation
// https://tc39.es/ecma262/#sec-isarray
// eslint-disable-next-line es/no-array-isarray -- safe
var isArray = Array.isArray || function isArray(arg) {
  return classofRaw(arg) == 'Array';
};

var engineUserAgent = getBuiltIn('navigator', 'userAgent') || '';

var process = global_1.process;
var versions = process && process.versions;
var v8 = versions && versions.v8;
var match, version;

if (v8) {
  match = v8.split('.');
  version = match[0] < 4 ? 1 : match[0] + match[1];
} else if (engineUserAgent) {
  match = engineUserAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = engineUserAgent.match(/Chrome\/(\d+)/);
    if (match) version = match[1];
  }
}

var engineV8Version = version && +version;

/* eslint-disable es/no-symbol -- required for testing */



// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
var nativeSymbol = !!Object.getOwnPropertySymbols && !fails(function () {
  return !String(Symbol()) ||
    // Chrome 38 Symbol has incorrect toString conversion
    // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
    !Symbol.sham && engineV8Version && engineV8Version < 41;
});

/* eslint-disable es/no-symbol -- required for testing */


var useSymbolAsUid = nativeSymbol
  && !Symbol.sham
  && typeof Symbol.iterator == 'symbol';

var WellKnownSymbolsStore = shared('wks');
var Symbol$1 = global_1.Symbol;
var createWellKnownSymbol = useSymbolAsUid ? Symbol$1 : Symbol$1 && Symbol$1.withoutSetter || uid;

var wellKnownSymbol = function (name) {
  if (!has(WellKnownSymbolsStore, name) || !(nativeSymbol || typeof WellKnownSymbolsStore[name] == 'string')) {
    if (nativeSymbol && has(Symbol$1, name)) {
      WellKnownSymbolsStore[name] = Symbol$1[name];
    } else {
      WellKnownSymbolsStore[name] = createWellKnownSymbol('Symbol.' + name);
    }
  } return WellKnownSymbolsStore[name];
};

var SPECIES = wellKnownSymbol('species');

// `ArraySpeciesCreate` abstract operation
// https://tc39.es/ecma262/#sec-arrayspeciescreate
var arraySpeciesCreate = function (originalArray, length) {
  var C;
  if (isArray(originalArray)) {
    C = originalArray.constructor;
    // cross-realm fallback
    if (typeof C == 'function' && (C === Array || isArray(C.prototype))) C = undefined;
    else if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  } return new (C === undefined ? Array : C)(length === 0 ? 0 : length);
};

var push = [].push;

// `Array.prototype.{ forEach, map, filter, some, every, find, findIndex, filterOut }` methods implementation
var createMethod$1 = function (TYPE) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var IS_FILTER_OUT = TYPE == 7;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  return function ($this, callbackfn, that, specificCreate) {
    var O = toObject($this);
    var self = indexedObject(O);
    var boundFunction = functionBindContext(callbackfn, that, 3);
    var length = toLength(self.length);
    var index = 0;
    var create = specificCreate || arraySpeciesCreate;
    var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_OUT ? create($this, 0) : undefined;
    var value, result;
    for (;length > index; index++) if (NO_HOLES || index in self) {
      value = self[index];
      result = boundFunction(value, index, O);
      if (TYPE) {
        if (IS_MAP) target[index] = result; // map
        else if (result) switch (TYPE) {
          case 3: return true;              // some
          case 5: return value;             // find
          case 6: return index;             // findIndex
          case 2: push.call(target, value); // filter
        } else switch (TYPE) {
          case 4: return false;             // every
          case 7: push.call(target, value); // filterOut
        }
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
  };
};

var arrayIteration = {
  // `Array.prototype.forEach` method
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  forEach: createMethod$1(0),
  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  map: createMethod$1(1),
  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  filter: createMethod$1(2),
  // `Array.prototype.some` method
  // https://tc39.es/ecma262/#sec-array.prototype.some
  some: createMethod$1(3),
  // `Array.prototype.every` method
  // https://tc39.es/ecma262/#sec-array.prototype.every
  every: createMethod$1(4),
  // `Array.prototype.find` method
  // https://tc39.es/ecma262/#sec-array.prototype.find
  find: createMethod$1(5),
  // `Array.prototype.findIndex` method
  // https://tc39.es/ecma262/#sec-array.prototype.findIndex
  findIndex: createMethod$1(6),
  // `Array.prototype.filterOut` method
  // https://github.com/tc39/proposal-array-filtering
  filterOut: createMethod$1(7)
};

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
// eslint-disable-next-line es/no-object-keys -- safe
var objectKeys = Object.keys || function keys(O) {
  return objectKeysInternal(O, enumBugKeys);
};

// `Object.defineProperties` method
// https://tc39.es/ecma262/#sec-object.defineproperties
// eslint-disable-next-line es/no-object-defineproperties -- safe
var objectDefineProperties = descriptors ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index) objectDefineProperty.f(O, key = keys[index++], Properties[key]);
  return O;
};

var html = getBuiltIn('document', 'documentElement');

var GT = '>';
var LT = '<';
var PROTOTYPE = 'prototype';
var SCRIPT = 'script';
var IE_PROTO = sharedKey('IE_PROTO');

var EmptyConstructor = function () { /* empty */ };

var scriptTag = function (content) {
  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
};

// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
var NullProtoObjectViaActiveX = function (activeXDocument) {
  activeXDocument.write(scriptTag(''));
  activeXDocument.close();
  var temp = activeXDocument.parentWindow.Object;
  activeXDocument = null; // avoid memory leak
  return temp;
};

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var NullProtoObjectViaIFrame = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = documentCreateElement('iframe');
  var JS = 'java' + SCRIPT + ':';
  var iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  // https://github.com/zloirock/core-js/issues/475
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag('document.F=Object'));
  iframeDocument.close();
  return iframeDocument.F;
};

// Check for document.domain and active x support
// No need to use active x approach when document.domain is not set
// see https://github.com/es-shims/es5-shim/issues/150
// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
// avoid IE GC bug
var activeXDocument;
var NullProtoObject = function () {
  try {
    /* global ActiveXObject -- old IE */
    activeXDocument = document.domain && new ActiveXObject('htmlfile');
  } catch (error) { /* ignore */ }
  NullProtoObject = activeXDocument ? NullProtoObjectViaActiveX(activeXDocument) : NullProtoObjectViaIFrame();
  var length = enumBugKeys.length;
  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};

hiddenKeys[IE_PROTO] = true;

// `Object.create` method
// https://tc39.es/ecma262/#sec-object.create
var objectCreate = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = NullProtoObject();
  return Properties === undefined ? result : objectDefineProperties(result, Properties);
};

var UNSCOPABLES = wellKnownSymbol('unscopables');
var ArrayPrototype = Array.prototype;

// Array.prototype[@@unscopables]
// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
if (ArrayPrototype[UNSCOPABLES] == undefined) {
  objectDefineProperty.f(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: objectCreate(null)
  });
}

// add a key to Array.prototype[@@unscopables]
var addToUnscopables = function (key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};

var $find = arrayIteration.find;


var FIND = 'find';
var SKIPS_HOLES = true;

// Shouldn't skip holes
if (FIND in []) Array(1)[FIND](function () { SKIPS_HOLES = false; });

// `Array.prototype.find` method
// https://tc39.es/ecma262/#sec-array.prototype.find
_export({ target: 'Array', proto: true, forced: SKIPS_HOLES }, {
  find: function find(callbackfn /* , that = undefined */) {
    return $find(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables(FIND);

var _class, _class2, _temp;

var ReactTooltip = staticMethods(_class = windowListener(_class = customEvent(_class = isCapture(_class = getEffect(_class = bodyMode(_class = trackRemoval(_class = (_temp = _class2 =
/*#__PURE__*/
function (_React$Component) {
  _inherits(ReactTooltip, _React$Component);

  _createClass(ReactTooltip, null, [{
    key: "propTypes",
    get: function get() {
      return {
        uuid: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        children: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().any),
        place: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        type: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        effect: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        offset: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().object),
        multiline: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        border: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        textColor: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        backgroundColor: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        borderColor: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        arrowColor: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        insecure: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        "class": (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        className: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        id: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        html: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        delayHide: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().number),
        delayUpdate: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().number),
        delayShow: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().number),
        event: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        eventOff: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        isCapture: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        globalEventOff: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        getContent: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().any),
        afterShow: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
        afterHide: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
        overridePosition: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().func),
        disable: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        scrollHide: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        resizeHide: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        wrapper: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        bodyMode: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool),
        possibleCustomEvents: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        possibleCustomEventsOff: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string),
        clickable: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().bool)
      };
    }
  }]);

  function ReactTooltip(props) {
    var _this;

    _classCallCheck(this, ReactTooltip);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(ReactTooltip).call(this, props));
    _this.state = {
      uuid: props.uuid || generateUUID(),
      place: props.place || 'top',
      // Direction of tooltip
      desiredPlace: props.place || 'top',
      type: 'dark',
      // Color theme of tooltip
      effect: 'float',
      // float or fixed
      show: false,
      border: false,
      customColors: {},
      offset: {},
      extraClass: '',
      html: false,
      delayHide: 0,
      delayShow: 0,
      event: props.event || null,
      eventOff: props.eventOff || null,
      currentEvent: null,
      // Current mouse event
      currentTarget: null,
      // Current target of mouse event
      ariaProps: parseAria(props),
      // aria- and role attributes
      isEmptyTip: false,
      disable: false,
      possibleCustomEvents: props.possibleCustomEvents || '',
      possibleCustomEventsOff: props.possibleCustomEventsOff || '',
      originTooltip: null,
      isMultiline: false
    };

    _this.bind(['showTooltip', 'updateTooltip', 'hideTooltip', 'hideTooltipOnScroll', 'getTooltipContent', 'globalRebuild', 'globalShow', 'globalHide', 'onWindowResize', 'mouseOnToolTip']);

    _this.mount = true;
    _this.delayShowLoop = null;
    _this.delayHideLoop = null;
    _this.delayReshow = null;
    _this.intervalUpdateContent = null;
    return _this;
  }
  /**
   * For unify the bind and unbind listener
   */


  _createClass(ReactTooltip, [{
    key: "bind",
    value: function bind(methodArray) {
      var _this2 = this;

      methodArray.forEach(function (method) {
        _this2[method] = _this2[method].bind(_this2);
      });
    }
  }, {
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this$props = this.props,
          insecure = _this$props.insecure,
          resizeHide = _this$props.resizeHide;
      this.bindListener(); // Bind listener for tooltip

      this.bindWindowEvents(resizeHide); // Bind global event for static method

      this.injectStyles(); // Inject styles for each DOM root having tooltip.
    }
  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      this.mount = false;
      this.clearTimer();
      this.unbindListener();
      this.removeScrollListener(this.state.currentTarget);
      this.unbindWindowEvents();
    }
    /* Look for the closest DOM root having tooltip and inject styles. */

  }, {
    key: "injectStyles",
    value: function injectStyles() {
      var tooltipRef = this.tooltipRef;

      if (!tooltipRef) {
        return;
      }

      var parentNode = tooltipRef.parentNode;

      while (parentNode.parentNode) {
        parentNode = parentNode.parentNode;
      }

      var domRoot;

      switch (parentNode.constructor.name) {
        case 'Document':
        case 'HTMLDocument':
        case undefined:
          domRoot = parentNode.head;
          break;

        case 'ShadowRoot':
        default:
          domRoot = parentNode;
          break;
      } // Prevent styles duplication.


      if (!domRoot.querySelector('style[data-react-tooltip]')) {
        var style = document.createElement('style');
        style.textContent = baseCss;
        style.setAttribute('data-react-tooltip', 'true');
        domRoot.appendChild(style);
      }
    }
    /**
     * Return if the mouse is on the tooltip.
     * @returns {boolean} true - mouse is on the tooltip
     */

  }, {
    key: "mouseOnToolTip",
    value: function mouseOnToolTip() {
      var show = this.state.show;

      if (show && this.tooltipRef) {
        /* old IE or Firefox work around */
        if (!this.tooltipRef.matches) {
          /* old IE work around */
          if (this.tooltipRef.msMatchesSelector) {
            this.tooltipRef.matches = this.tooltipRef.msMatchesSelector;
          } else {
            /* old Firefox work around */
            this.tooltipRef.matches = this.tooltipRef.mozMatchesSelector;
          }
        }

        return this.tooltipRef.matches(':hover');
      }

      return false;
    }
    /**
     * Pick out corresponded target elements
     */

  }, {
    key: "getTargetArray",
    value: function getTargetArray(id) {
      var targetArray = [];
      var selector;

      if (!id) {
        selector = '[data-tip]:not([data-for])';
      } else {
        var escaped = id.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
        selector = "[data-tip][data-for=\"".concat(escaped, "\"]");
      } // Scan document for shadow DOM elements


      nodeListToArray(document.getElementsByTagName('*')).filter(function (element) {
        return element.shadowRoot;
      }).forEach(function (element) {
        targetArray = targetArray.concat(nodeListToArray(element.shadowRoot.querySelectorAll(selector)));
      });
      return targetArray.concat(nodeListToArray(document.querySelectorAll(selector)));
    }
    /**
     * Bind listener to the target elements
     * These listeners used to trigger showing or hiding the tooltip
     */

  }, {
    key: "bindListener",
    value: function bindListener() {
      var _this3 = this;

      var _this$props2 = this.props,
          id = _this$props2.id,
          globalEventOff = _this$props2.globalEventOff,
          isCapture = _this$props2.isCapture;
      var targetArray = this.getTargetArray(id);
      targetArray.forEach(function (target) {
        if (target.getAttribute('currentItem') === null) {
          target.setAttribute('currentItem', 'false');
        }

        _this3.unbindBasicListener(target);

        if (_this3.isCustomEvent(target)) {
          _this3.customUnbindListener(target);
        }
      });

      if (this.isBodyMode()) {
        this.bindBodyListener(targetArray);
      } else {
        targetArray.forEach(function (target) {
          var isCaptureMode = _this3.isCapture(target);

          var effect = _this3.getEffect(target);

          if (_this3.isCustomEvent(target)) {
            _this3.customBindListener(target);

            return;
          }

          target.addEventListener('mouseenter', _this3.showTooltip, isCaptureMode);
          target.addEventListener('focus', _this3.showTooltip, isCaptureMode);

          if (effect === 'float') {
            target.addEventListener('mousemove', _this3.updateTooltip, isCaptureMode);
          }

          target.addEventListener('mouseleave', _this3.hideTooltip, isCaptureMode);
          target.addEventListener('blur', _this3.hideTooltip, isCaptureMode);
        });
      } // Global event to hide tooltip


      if (globalEventOff) {
        window.removeEventListener(globalEventOff, this.hideTooltip);
        window.addEventListener(globalEventOff, this.hideTooltip, isCapture);
      } // Track removal of targetArray elements from DOM


      this.bindRemovalTracker();
    }
    /**
     * Unbind listeners on target elements
     */

  }, {
    key: "unbindListener",
    value: function unbindListener() {
      var _this4 = this;

      var _this$props3 = this.props,
          id = _this$props3.id,
          globalEventOff = _this$props3.globalEventOff;

      if (this.isBodyMode()) {
        this.unbindBodyListener();
      } else {
        var targetArray = this.getTargetArray(id);
        targetArray.forEach(function (target) {
          _this4.unbindBasicListener(target);

          if (_this4.isCustomEvent(target)) _this4.customUnbindListener(target);
        });
      }

      if (globalEventOff) window.removeEventListener(globalEventOff, this.hideTooltip);
      this.unbindRemovalTracker();
    }
    /**
     * Invoke this before bind listener and unmount the component
     * it is necessary to invoke this even when binding custom event
     * so that the tooltip can switch between custom and default listener
     */

  }, {
    key: "unbindBasicListener",
    value: function unbindBasicListener(target) {
      var isCaptureMode = this.isCapture(target);
      target.removeEventListener('mouseenter', this.showTooltip, isCaptureMode);
      target.removeEventListener('mousemove', this.updateTooltip, isCaptureMode);
      target.removeEventListener('mouseleave', this.hideTooltip, isCaptureMode);
    }
  }, {
    key: "getTooltipContent",
    value: function getTooltipContent() {
      var _this$props4 = this.props,
          getContent = _this$props4.getContent,
          children = _this$props4.children; // Generate tooltip content

      var content;

      if (getContent) {
        if (Array.isArray(getContent)) {
          content = getContent[0] && getContent[0](this.state.originTooltip);
        } else {
          content = getContent(this.state.originTooltip);
        }
      }

      return getTipContent(this.state.originTooltip, children, content, this.state.isMultiline);
    }
  }, {
    key: "isEmptyTip",
    value: function isEmptyTip(placeholder) {
      return typeof placeholder === 'string' && placeholder === '' || placeholder === null;
    }
    /**
     * When mouse enter, show the tooltip
     */

  }, {
    key: "showTooltip",
    value: function showTooltip(e, isGlobalCall) {
      if (!this.tooltipRef) {
        return;
      }

      if (isGlobalCall) {
        // Don't trigger other elements belongs to other ReactTooltip
        var targetArray = this.getTargetArray(this.props.id);
        var isMyElement = targetArray.some(function (ele) {
          return ele === e.currentTarget;
        });
        if (!isMyElement) return;
      } // Get the tooltip content
      // calculate in this phrase so that tip width height can be detected


      var _this$props5 = this.props,
          multiline = _this$props5.multiline,
          getContent = _this$props5.getContent;
      var originTooltip = e.currentTarget.getAttribute('data-tip');
      var isMultiline = e.currentTarget.getAttribute('data-multiline') || multiline || false; // If it is focus event or called by ReactTooltip.show, switch to `solid` effect

      var switchToSolid = e instanceof window.FocusEvent || isGlobalCall; // if it needs to skip adding hide listener to scroll

      var scrollHide = true;

      if (e.currentTarget.getAttribute('data-scroll-hide')) {
        scrollHide = e.currentTarget.getAttribute('data-scroll-hide') === 'true';
      } else if (this.props.scrollHide != null) {
        scrollHide = this.props.scrollHide;
      } // adding aria-describedby to target to make tooltips read by screen readers


      if (e && e.currentTarget && e.currentTarget.setAttribute) {
        e.currentTarget.setAttribute('aria-describedby', this.state.uuid);
      } // Make sure the correct place is set


      var desiredPlace = e.currentTarget.getAttribute('data-place') || this.props.place || 'top';
      var effect = switchToSolid && 'solid' || this.getEffect(e.currentTarget);
      var offset = e.currentTarget.getAttribute('data-offset') || this.props.offset || {};
      var result = getPosition(e, e.currentTarget, this.tooltipRef, desiredPlace, desiredPlace, effect, offset);

      if (result.position && this.props.overridePosition) {
        result.position = this.props.overridePosition(result.position, e, e.currentTarget, this.tooltipRef, desiredPlace, desiredPlace, effect, offset);
      }

      var place = result.isNewState ? result.newState.place : desiredPlace; // To prevent previously created timers from triggering

      this.clearTimer();
      var target = e.currentTarget;
      var reshowDelay = this.state.show ? target.getAttribute('data-delay-update') || this.props.delayUpdate : 0;
      var self = this;

      var updateState = function updateState() {
        self.setState({
          originTooltip: originTooltip,
          isMultiline: isMultiline,
          desiredPlace: desiredPlace,
          place: place,
          type: target.getAttribute('data-type') || self.props.type || 'dark',
          customColors: {
            text: target.getAttribute('data-text-color') || self.props.textColor || null,
            background: target.getAttribute('data-background-color') || self.props.backgroundColor || null,
            border: target.getAttribute('data-border-color') || self.props.borderColor || null,
            arrow: target.getAttribute('data-arrow-color') || self.props.arrowColor || null
          },
          effect: effect,
          offset: offset,
          html: (target.getAttribute('data-html') ? target.getAttribute('data-html') === 'true' : self.props.html) || false,
          delayShow: target.getAttribute('data-delay-show') || self.props.delayShow || 0,
          delayHide: target.getAttribute('data-delay-hide') || self.props.delayHide || 0,
          delayUpdate: target.getAttribute('data-delay-update') || self.props.delayUpdate || 0,
          border: (target.getAttribute('data-border') ? target.getAttribute('data-border') === 'true' : self.props.border) || false,
          extraClass: target.getAttribute('data-class') || self.props["class"] || self.props.className || '',
          disable: (target.getAttribute('data-tip-disable') ? target.getAttribute('data-tip-disable') === 'true' : self.props.disable) || false,
          currentTarget: target
        }, function () {
          if (scrollHide) {
            self.addScrollListener(self.state.currentTarget);
          }

          self.updateTooltip(e);

          if (getContent && Array.isArray(getContent)) {
            self.intervalUpdateContent = setInterval(function () {
              if (self.mount) {
                var _getContent = self.props.getContent;
                var placeholder = getTipContent(originTooltip, '', _getContent[0](), isMultiline);
                var isEmptyTip = self.isEmptyTip(placeholder);
                self.setState({
                  isEmptyTip: isEmptyTip
                });
                self.updatePosition();
              }
            }, getContent[1]);
          }
        });
      }; // If there is no delay call immediately, don't allow events to get in first.


      if (reshowDelay) {
        this.delayReshow = setTimeout(updateState, reshowDelay);
      } else {
        updateState();
      }
    }
    /**
     * When mouse hover, update tool tip
     */

  }, {
    key: "updateTooltip",
    value: function updateTooltip(e) {
      var _this5 = this;

      var _this$state = this.state,
          delayShow = _this$state.delayShow,
          disable = _this$state.disable;
      var afterShow = this.props.afterShow;
      var placeholder = this.getTooltipContent();
      var eventTarget = e.currentTarget || e.target; // Check if the mouse is actually over the tooltip, if so don't hide the tooltip

      if (this.mouseOnToolTip()) {
        return;
      } // if the tooltip is empty, disable the tooltip


      if (this.isEmptyTip(placeholder) || disable) {
        return;
      }

      var delayTime = !this.state.show ? parseInt(delayShow, 10) : 0;

      var updateState = function updateState() {
        if (Array.isArray(placeholder) && placeholder.length > 0 || placeholder) {
          var isInvisible = !_this5.state.show;

          _this5.setState({
            currentEvent: e,
            currentTarget: eventTarget,
            show: true
          }, function () {
            _this5.updatePosition();

            if (isInvisible && afterShow) {
              afterShow(e);
            }
          });
        }
      };

      clearTimeout(this.delayShowLoop);

      if (delayTime) {
        this.delayShowLoop = setTimeout(updateState, delayTime);
      } else {
        updateState();
      }
    }
    /*
     * If we're mousing over the tooltip remove it when we leave.
     */

  }, {
    key: "listenForTooltipExit",
    value: function listenForTooltipExit() {
      var show = this.state.show;

      if (show && this.tooltipRef) {
        this.tooltipRef.addEventListener('mouseleave', this.hideTooltip);
      }
    }
  }, {
    key: "removeListenerForTooltipExit",
    value: function removeListenerForTooltipExit() {
      var show = this.state.show;

      if (show && this.tooltipRef) {
        this.tooltipRef.removeEventListener('mouseleave', this.hideTooltip);
      }
    }
    /**
     * When mouse leave, hide tooltip
     */

  }, {
    key: "hideTooltip",
    value: function hideTooltip(e, hasTarget) {
      var _this6 = this;

      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
        isScroll: false
      };
      var disable = this.state.disable;
      var isScroll = options.isScroll;
      var delayHide = isScroll ? 0 : this.state.delayHide;
      var afterHide = this.props.afterHide;
      var placeholder = this.getTooltipContent();
      if (!this.mount) return;
      if (this.isEmptyTip(placeholder) || disable) return; // if the tooltip is empty, disable the tooltip

      if (hasTarget) {
        // Don't trigger other elements belongs to other ReactTooltip
        var targetArray = this.getTargetArray(this.props.id);
        var isMyElement = targetArray.some(function (ele) {
          return ele === e.currentTarget;
        });
        if (!isMyElement || !this.state.show) return;
      } // clean up aria-describedby when hiding tooltip


      if (e && e.currentTarget && e.currentTarget.removeAttribute) {
        e.currentTarget.removeAttribute('aria-describedby');
      }

      var resetState = function resetState() {
        var isVisible = _this6.state.show; // Check if the mouse is actually over the tooltip, if so don't hide the tooltip

        if (_this6.mouseOnToolTip()) {
          _this6.listenForTooltipExit();

          return;
        }

        _this6.removeListenerForTooltipExit();

        _this6.setState({
          show: false
        }, function () {
          _this6.removeScrollListener(_this6.state.currentTarget);

          if (isVisible && afterHide) {
            afterHide(e);
          }
        });
      };

      this.clearTimer();

      if (delayHide) {
        this.delayHideLoop = setTimeout(resetState, parseInt(delayHide, 10));
      } else {
        resetState();
      }
    }
    /**
     * When scroll, hide tooltip
     */

  }, {
    key: "hideTooltipOnScroll",
    value: function hideTooltipOnScroll(event, hasTarget) {
      this.hideTooltip(event, hasTarget, {
        isScroll: true
      });
    }
    /**
     * Add scroll event listener when tooltip show
     * automatically hide the tooltip when scrolling
     */

  }, {
    key: "addScrollListener",
    value: function addScrollListener(currentTarget) {
      var isCaptureMode = this.isCapture(currentTarget);
      window.addEventListener('scroll', this.hideTooltipOnScroll, isCaptureMode);
    }
  }, {
    key: "removeScrollListener",
    value: function removeScrollListener(currentTarget) {
      var isCaptureMode = this.isCapture(currentTarget);
      window.removeEventListener('scroll', this.hideTooltipOnScroll, isCaptureMode);
    } // Calculation the position

  }, {
    key: "updatePosition",
    value: function updatePosition() {
      var _this7 = this;

      var _this$state2 = this.state,
          currentEvent = _this$state2.currentEvent,
          currentTarget = _this$state2.currentTarget,
          place = _this$state2.place,
          desiredPlace = _this$state2.desiredPlace,
          effect = _this$state2.effect,
          offset = _this$state2.offset;
      var node = this.tooltipRef;
      var result = getPosition(currentEvent, currentTarget, node, place, desiredPlace, effect, offset);

      if (result.position && this.props.overridePosition) {
        result.position = this.props.overridePosition(result.position, currentEvent, currentTarget, node, place, desiredPlace, effect, offset);
      }

      if (result.isNewState) {
        // Switch to reverse placement
        return this.setState(result.newState, function () {
          _this7.updatePosition();
        });
      } // Set tooltip position


      node.style.left = result.position.left + 'px';
      node.style.top = result.position.top + 'px';
    }
    /**
     * CLear all kinds of timeout of interval
     */

  }, {
    key: "clearTimer",
    value: function clearTimer() {
      clearTimeout(this.delayShowLoop);
      clearTimeout(this.delayHideLoop);
      clearTimeout(this.delayReshow);
      clearInterval(this.intervalUpdateContent);
    }
  }, {
    key: "hasCustomColors",
    value: function hasCustomColors() {
      var _this8 = this;

      return Boolean(Object.keys(this.state.customColors).find(function (color) {
        return color !== 'border' && _this8.state.customColors[color];
      }) || this.state.border && this.state.customColors['border']);
    }
  }, {
    key: "render",
    value: function render() {
      var _this9 = this;

      var _this$state3 = this.state,
          extraClass = _this$state3.extraClass,
          html = _this$state3.html,
          ariaProps = _this$state3.ariaProps,
          disable = _this$state3.disable,
          uuid = _this$state3.uuid;
      var content = this.getTooltipContent();
      var isEmptyTip = this.isEmptyTip(content);
      var style = generateTooltipStyle(this.state.uuid, this.state.customColors, this.state.type, this.state.border);
      var tooltipClass = '__react_component_tooltip' + " ".concat(this.state.uuid) + (this.state.show && !disable && !isEmptyTip ? ' show' : '') + (this.state.border ? ' border' : '') + " place-".concat(this.state.place) + // top, bottom, left, right
      " type-".concat(this.hasCustomColors() ? 'custom' : this.state.type) + ( // dark, success, warning, error, info, light, custom
      this.props.delayUpdate ? ' allow_hover' : '') + (this.props.clickable ? ' allow_click' : '');
      var Wrapper = this.props.wrapper;

      if (ReactTooltip.supportedWrappers.indexOf(Wrapper) < 0) {
        Wrapper = ReactTooltip.defaultProps.wrapper;
      }

      var wrapperClassName = [tooltipClass, extraClass].filter(Boolean).join(' ');

      if (html) {
        var htmlContent = "".concat(content, "\n<style aria-hidden=\"true\">").concat(style, "</style>");
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Wrapper, _extends({
          className: "".concat(wrapperClassName),
          id: this.props.id || uuid,
          ref: function ref(_ref) {
            return _this9.tooltipRef = _ref;
          }
        }, ariaProps, {
          "data-id": "tooltip",
          dangerouslySetInnerHTML: {
            __html: htmlContent
          }
        }));
      } else {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Wrapper, _extends({
          className: "".concat(wrapperClassName),
          id: this.props.id || uuid
        }, ariaProps, {
          ref: function ref(_ref2) {
            return _this9.tooltipRef = _ref2;
          },
          "data-id": "tooltip"
        }), react__WEBPACK_IMPORTED_MODULE_0___default().createElement("style", {
          dangerouslySetInnerHTML: {
            __html: style
          },
          "aria-hidden": "true"
        }), content);
      }
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(nextProps, prevState) {
      var ariaProps = prevState.ariaProps;
      var newAriaProps = parseAria(nextProps);
      var isChanged = Object.keys(newAriaProps).some(function (props) {
        return newAriaProps[props] !== ariaProps[props];
      });

      if (!isChanged) {
        return null;
      }

      return _objectSpread2({}, prevState, {
        ariaProps: newAriaProps
      });
    }
  }]);

  return ReactTooltip;
}((react__WEBPACK_IMPORTED_MODULE_0___default().Component)), _defineProperty(_class2, "defaultProps", {
  insecure: true,
  resizeHide: true,
  wrapper: 'div',
  clickable: false
}), _defineProperty(_class2, "supportedWrappers", ['div', 'span']), _defineProperty(_class2, "displayName", 'ReactTooltip'), _temp)) || _class) || _class) || _class) || _class) || _class) || _class) || _class;

/* harmony default export */ __webpack_exports__["default"] = (ReactTooltip);
//# sourceMappingURL=index.es.js.map


/***/ }),

/***/ "./node_modules/style-to-js/cjs/index.js":
/*!***********************************************!*\
  !*** ./node_modules/style-to-js/cjs/index.js ***!
  \***********************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
exports.__esModule = true;
var style_to_object_1 = __importDefault(__webpack_require__(/*! style-to-object */ "./node_modules/style-to-object/index.js"));
var utilities_1 = __webpack_require__(/*! ./utilities */ "./node_modules/style-to-js/cjs/utilities.js");
function StyleToJS(style, options) {
    var output = {};
    if (!style || typeof style !== 'string') {
        return output;
    }
    style_to_object_1["default"](style, function (property, value) {
        if (property && value) {
            output[utilities_1.camelCase(property, options)] = value;
        }
    });
    return output;
}
exports["default"] = StyleToJS;


/***/ }),

/***/ "./node_modules/style-to-js/cjs/utilities.js":
/*!***************************************************!*\
  !*** ./node_modules/style-to-js/cjs/utilities.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports) {

"use strict";

exports.__esModule = true;
exports.camelCase = void 0;
var CUSTOM_PROPERTY_REGEX = /^--[a-zA-Z0-9-]+$/;
var HYPHEN_REGEX = /-([a-z])/g;
var NO_HYPHEN_REGEX = /^[^-]+$/;
var VENDOR_PREFIX_REGEX = /^-(webkit|moz|ms|o|khtml)-/;
var skipCamelCase = function (property) {
    return !property ||
        NO_HYPHEN_REGEX.test(property) ||
        CUSTOM_PROPERTY_REGEX.test(property);
};
var capitalize = function (match, character) {
    return character.toUpperCase();
};
var trimHyphen = function (match, prefix) { return prefix + "-"; };
var camelCase = function (property, options) {
    if (options === void 0) { options = {}; }
    if (skipCamelCase(property)) {
        return property;
    }
    property = property.toLowerCase();
    if (!options.reactCompat) {
        property = property.replace(VENDOR_PREFIX_REGEX, trimHyphen);
    }
    return property.replace(HYPHEN_REGEX, capitalize);
};
exports.camelCase = camelCase;


/***/ }),

/***/ "./node_modules/style-to-object/index.js":
/*!***********************************************!*\
  !*** ./node_modules/style-to-object/index.js ***!
  \***********************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var parse = __webpack_require__(/*! inline-style-parser */ "./node_modules/inline-style-parser/index.js");

/**
 * Parses inline style to object.
 *
 * @example
 * // returns { 'line-height': '42' }
 * StyleToObject('line-height: 42;');
 *
 * @param  {String}      style      - The inline style.
 * @param  {Function}    [iterator] - The iterator function.
 * @return {null|Object}
 */
function StyleToObject(style, iterator) {
  var output = null;
  if (!style || typeof style !== 'string') {
    return output;
  }

  var declaration;
  var declarations = parse(style);
  var hasIterator = typeof iterator === 'function';
  var property;
  var value;

  for (var i = 0, len = declarations.length; i < len; i++) {
    declaration = declarations[i];
    property = declaration.property;
    value = declaration.value;

    if (hasIterator) {
      iterator(property, value, declaration);
    } else if (value) {
      output || (output = {});
      output[property] = value;
    }
  }

  return output;
}

module.exports = StyleToObject;


/***/ }),

/***/ "./node_modules/umbrellajs/umbrella.min.js":
/*!*************************************************!*\
  !*** ./node_modules/umbrellajs/umbrella.min.js ***!
  \*************************************************/
/***/ (function(module) {

/* Umbrella JS 3.3.0 umbrellajs.com */

var u=function(t,e){return this instanceof u?t instanceof u?t:((t="string"==typeof t?this.select(t,e):t)&&t.nodeName&&(t=[t]),void(this.nodes=this.slice(t))):new u(t,e)};u.prototype={get length(){return this.nodes.length}},u.prototype.nodes=[],u.prototype.addClass=function(){return this.eacharg(arguments,function(t,e){t.classList.add(e)})},u.prototype.adjacent=function(o,t,i){return"number"==typeof t&&(t=0===t?[]:new Array(t).join().split(",").map(Number.call,Number)),this.each(function(n,r){var e=document.createDocumentFragment();u(t||{}).map(function(t,e){e="function"==typeof o?o.call(this,t,e,n,r):o;return"string"==typeof e?this.generate(e):u(e)}).each(function(t){this.isInPage(t)?e.appendChild(u(t).clone().first()):e.appendChild(t)}),i.call(this,n,e)})},u.prototype.after=function(t,e){return this.adjacent(t,e,function(t,e){t.parentNode.insertBefore(e,t.nextSibling)})},u.prototype.append=function(t,e){return this.adjacent(t,e,function(t,e){t.appendChild(e)})},u.prototype.args=function(t,e,n){return(t="string"!=typeof(t="function"==typeof t?t(e,n):t)?this.slice(t).map(this.str(e,n)):t).toString().split(/[\s,]+/).filter(function(t){return t.length})},u.prototype.array=function(o){var i=this;return this.nodes.reduce(function(t,e,n){var r;return o?(r="string"==typeof(r=(r=o.call(i,e,n))||!1)?u(r):r)instanceof u&&(r=r.nodes):r=e.innerHTML,t.concat(!1!==r?r:[])},[])},u.prototype.attr=function(t,e,r){return r=r?"data-":"",this.pairs(t,e,function(t,e){return t.getAttribute(r+e)},function(t,e,n){n?t.setAttribute(r+e,n):t.removeAttribute(r+e)})},u.prototype.before=function(t,e){return this.adjacent(t,e,function(t,e){t.parentNode.insertBefore(e,t)})},u.prototype.children=function(t){return this.map(function(t){return this.slice(t.children)}).filter(t)},u.prototype.clone=function(){return this.map(function(t,e){var n=t.cloneNode(!0),r=this.getAll(n);return this.getAll(t).each(function(t,e){for(var n in this.mirror)this.mirror[n]&&this.mirror[n](t,r.nodes[e])}),n})},u.prototype.getAll=function(t){return u([t].concat(u("*",t).nodes))},u.prototype.mirror={},u.prototype.mirror.events=function(t,e){if(t._e)for(var n in t._e)t._e[n].forEach(function(t){u(e).on(n,t.callback)})},u.prototype.mirror.select=function(t,e){u(t).is("select")&&(e.value=t.value)},u.prototype.mirror.textarea=function(t,e){u(t).is("textarea")&&(e.value=t.value)},u.prototype.closest=function(e){return this.map(function(t){do{if(u(t).is(e))return t}while((t=t.parentNode)&&t!==document)})},u.prototype.data=function(t,e){return this.attr(t,e,!0)},u.prototype.each=function(t){return this.nodes.forEach(t.bind(this)),this},u.prototype.eacharg=function(n,r){return this.each(function(e,t){this.args(n,e,t).forEach(function(t){r.call(this,e,t)},this)})},u.prototype.empty=function(){return this.each(function(t){for(;t.firstChild;)t.removeChild(t.firstChild)})},u.prototype.filter=function(e){var t=e instanceof u?function(t){return-1!==e.nodes.indexOf(t)}:"function"==typeof e?e:function(t){return t.matches=t.matches||t.msMatchesSelector||t.webkitMatchesSelector,t.matches(e||"*")};return u(this.nodes.filter(t))},u.prototype.find=function(e){return this.map(function(t){return u(e||"*",t)})},u.prototype.first=function(){return this.nodes[0]||!1},u.prototype.generate=function(t){return/^\s*<tr[> ]/.test(t)?u(document.createElement("table")).html(t).children().children().nodes:/^\s*<t(h|d)[> ]/.test(t)?u(document.createElement("table")).html(t).children().children().children().nodes:/^\s*</.test(t)?u(document.createElement("div")).html(t).children().nodes:document.createTextNode(t)},u.prototype.handle=function(){var t=this.slice(arguments).map(function(e){return"function"==typeof e?function(t){t.preventDefault(),e.apply(this,arguments)}:e},this);return this.on.apply(this,t)},u.prototype.hasClass=function(){return this.is("."+this.args(arguments).join("."))},u.prototype.html=function(e){return void 0===e?this.first().innerHTML||"":this.each(function(t){t.innerHTML=e})},u.prototype.is=function(t){return 0<this.filter(t).length},u.prototype.isInPage=function(t){return t!==document.body&&document.body.contains(t)},u.prototype.last=function(){return this.nodes[this.length-1]||!1},u.prototype.map=function(t){return t?u(this.array(t)).unique():this},u.prototype.not=function(e){return this.filter(function(t){return!u(t).is(e||!0)})},u.prototype.off=function(t,e,n){var r=null==e&&null==n,o=null,i=e;return"string"==typeof e&&(o=e,i=n),this.eacharg(t,function(e,n){u(e._e?e._e[n]:[]).each(function(t){(r||t.orig_callback===i&&t.selector===o)&&e.removeEventListener(n,t.callback)})})},u.prototype.on=function(t,e,o){function i(t,e){try{Object.defineProperty(t,"currentTarget",{value:e,configurable:!0})}catch(t){}}var c=null,n=e;"string"==typeof e&&(c=e,n=o,e=function(n){var r=arguments;u(n.currentTarget).find(c).each(function(t){var e;t.contains(n.target)&&(e=n.currentTarget,i(n,t),o.apply(t,r),i(n,e))})});function r(t){return e.apply(this,[t].concat(t.detail||[]))}return this.eacharg(t,function(t,e){t.addEventListener(e,r),t._e=t._e||{},t._e[e]=t._e[e]||[],t._e[e].push({callback:r,orig_callback:n,selector:c})})},u.prototype.pairs=function(r,t,e,o){var n;return void 0!==t&&(n=r,(r={})[n]=t),"object"==typeof r?this.each(function(t,e){for(var n in r)"function"==typeof r[n]?o(t,n,r[n](t,e)):o(t,n,r[n])}):this.length?e(this.first(),r):""},u.prototype.param=function(e){return Object.keys(e).map(function(t){return this.uri(t)+"="+this.uri(e[t])}.bind(this)).join("&")},u.prototype.parent=function(t){return this.map(function(t){return t.parentNode}).filter(t)},u.prototype.prepend=function(t,e){return this.adjacent(t,e,function(t,e){t.insertBefore(e,t.firstChild)})},u.prototype.remove=function(){return this.each(function(t){t.parentNode&&t.parentNode.removeChild(t)})},u.prototype.removeClass=function(){return this.eacharg(arguments,function(t,e){t.classList.remove(e)})},u.prototype.replace=function(t,e){var n=[];return this.adjacent(t,e,function(t,e){n=n.concat(this.slice(e.children)),t.parentNode.replaceChild(e,t)}),u(n)},u.prototype.scroll=function(){return this.first().scrollIntoView({behavior:"smooth"}),this},u.prototype.select=function(t,e){return t=t.replace(/^\s*/,"").replace(/\s*$/,""),/^</.test(t)?u().generate(t):(e||document).querySelectorAll(t)},u.prototype.serialize=function(){var r=this;return this.slice(this.first().elements).reduce(function(e,n){return!n.name||n.disabled||"file"===n.type||/(checkbox|radio)/.test(n.type)&&!n.checked?e:"select-multiple"===n.type?(u(n.options).each(function(t){t.selected&&(e+="&"+r.uri(n.name)+"="+r.uri(t.value))}),e):e+"&"+r.uri(n.name)+"="+r.uri(n.value)},"").slice(1)},u.prototype.siblings=function(t){return this.parent().children(t).not(this)},u.prototype.size=function(){return this.first().getBoundingClientRect()},u.prototype.slice=function(t){return t&&0!==t.length&&"string"!=typeof t&&"[object Function]"!==t.toString()?t.length?[].slice.call(t.nodes||t):[t]:[]},u.prototype.str=function(e,n){return function(t){return"function"==typeof t?t.call(this,e,n):t.toString()}},u.prototype.text=function(e){return void 0===e?this.first().textContent||"":this.each(function(t){t.textContent=e})},u.prototype.toggleClass=function(t,e){return!!e===e?this[e?"addClass":"removeClass"](t):this.eacharg(t,function(t,e){t.classList.toggle(e)})},u.prototype.trigger=function(t){var o=this.slice(arguments).slice(1);return this.eacharg(t,function(t,e){var n,r={bubbles:!0,cancelable:!0,detail:o};try{n=new window.CustomEvent(e,r)}catch(t){(n=document.createEvent("CustomEvent")).initCustomEvent(e,!0,!0,o)}t.dispatchEvent(n)})},u.prototype.unique=function(){return u(this.nodes.reduce(function(t,e){return null!=e&&!1!==e&&-1===t.indexOf(e)?t.concat(e):t},[]))},u.prototype.uri=function(t){return encodeURIComponent(t).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A").replace(/%20/g,"+")},u.prototype.wrap=function(t){return this.map(function(e){return u(t).each(function(t){!function(t){for(;t.firstElementChild;)t=t.firstElementChild;return u(t)}(t).append(e.cloneNode(!0)),e.parentNode.replaceChild(t,e)})})}, true&&module.exports&&(module.exports=u,module.exports.u=u);

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/bytesToUuid.js":
/*!***********************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/bytesToUuid.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Convert array of 16 byte values to UUID string format of the form:
 * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
 */
var byteToHex = [];

for (var i = 0; i < 256; ++i) {
  byteToHex[i] = (i + 0x100).toString(16).substr(1);
}

function bytesToUuid(buf, offset) {
  var i = offset || 0;
  var bth = byteToHex; // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4

  return [bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], '-', bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]], bth[buf[i++]]].join('');
}

/* harmony default export */ __webpack_exports__["default"] = (bytesToUuid);

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/rng.js":
/*!***************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/rng.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ rng; }
/* harmony export */ });
// Unique ID creation requires a high quality random # generator. In the browser we therefore
// require the crypto API and do not support built-in fallback to lower quality random number
// generators (like Math.random()).
// getRandomValues needs to be invoked in a context where "this" is a Crypto implementation. Also,
// find the complete implementation of crypto (msCrypto) on IE11.
var getRandomValues = typeof crypto != 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto) || typeof msCrypto != 'undefined' && typeof msCrypto.getRandomValues == 'function' && msCrypto.getRandomValues.bind(msCrypto);
var rnds8 = new Uint8Array(16); // eslint-disable-line no-undef

function rng() {
  if (!getRandomValues) {
    throw new Error('crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported');
  }

  return getRandomValues(rnds8);
}

/***/ }),

/***/ "./node_modules/uuid/dist/esm-browser/v4.js":
/*!**************************************************!*\
  !*** ./node_modules/uuid/dist/esm-browser/v4.js ***!
  \**************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _rng_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rng.js */ "./node_modules/uuid/dist/esm-browser/rng.js");
/* harmony import */ var _bytesToUuid_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./bytesToUuid.js */ "./node_modules/uuid/dist/esm-browser/bytesToUuid.js");



function v4(options, buf, offset) {
  var i = buf && offset || 0;

  if (typeof options == 'string') {
    buf = options === 'binary' ? new Array(16) : null;
    options = null;
  }

  options = options || {};
  var rnds = options.random || (options.rng || _rng_js__WEBPACK_IMPORTED_MODULE_0__["default"])(); // Per 4.4, set bits for version and `clock_seq_hi_and_reserved`

  rnds[6] = rnds[6] & 0x0f | 0x40;
  rnds[8] = rnds[8] & 0x3f | 0x80; // Copy bytes to buffer, if provided

  if (buf) {
    for (var ii = 0; ii < 16; ++ii) {
      buf[i + ii] = rnds[ii];
    }
  }

  return buf || (0,_bytesToUuid_js__WEBPACK_IMPORTED_MODULE_1__["default"])(rnds);
}

/* harmony default export */ __webpack_exports__["default"] = (v4);

/***/ }),

/***/ "../node_modules/classnames/index.js":
/*!*******************************************!*\
  !*** ../node_modules/classnames/index.js ***!
  \*******************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
/* global define */

(function () {
	'use strict';

	var hasOwn = {}.hasOwnProperty;
	var nativeCodeString = '[native code]';

	function classNames() {
		var classes = [];

		for (var i = 0; i < arguments.length; i++) {
			var arg = arguments[i];
			if (!arg) continue;

			var argType = typeof arg;

			if (argType === 'string' || argType === 'number') {
				classes.push(arg);
			} else if (Array.isArray(arg)) {
				if (arg.length) {
					var inner = classNames.apply(null, arg);
					if (inner) {
						classes.push(inner);
					}
				}
			} else if (argType === 'object') {
				if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes('[native code]')) {
					classes.push(arg.toString());
					continue;
				}

				for (var key in arg) {
					if (hasOwn.call(arg, key) && arg[key]) {
						classes.push(key);
					}
				}
			}
		}

		return classes.join(' ');
	}

	if ( true && module.exports) {
		classNames.default = classNames;
		module.exports = classNames;
	} else if (true) {
		// register as 'classnames', consistent with npm package name
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return classNames;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else {}
}());


/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ (function(module) {

"use strict";
module.exports = window["React"];

/***/ }),

/***/ "react-dom":
/*!***************************!*\
  !*** external "ReactDOM" ***!
  \***************************/
/***/ (function(module) {

"use strict";
module.exports = window["ReactDOM"];

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ (function(module) {

"use strict";
module.exports = window["lodash"];

/***/ }),

/***/ "@babel/runtime/regenerator":
/*!*************************************!*\
  !*** external "regeneratorRuntime" ***!
  \*************************************/
/***/ (function(module) {

"use strict";
module.exports = window["regeneratorRuntime"];

/***/ }),

/***/ "@wordpress/api-fetch":
/*!**********************************!*\
  !*** external ["wp","apiFetch"] ***!
  \**********************************/
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["apiFetch"];

/***/ }),

/***/ "@wordpress/hooks":
/*!*******************************!*\
  !*** external ["wp","hooks"] ***!
  \*******************************/
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["hooks"];

/***/ }),

/***/ "@wordpress/i18n":
/*!******************************!*\
  !*** external ["wp","i18n"] ***!
  \******************************/
/***/ (function(module) {

"use strict";
module.exports = window["wp"]["i18n"];

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _arrayLikeToArray; }
/* harmony export */ });
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _arrayWithHoles; }
/* harmony export */ });
function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _arrayWithoutHoles; }
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arr);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _asyncToGenerator; }
/* harmony export */ });
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/defineProperty.js ***!
  \*******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _defineProperty; }
/* harmony export */ });
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/extends.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/extends.js ***!
  \************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _extends; }
/* harmony export */ });
function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/iterableToArray.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _iterableToArray; }
/* harmony export */ });
function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _iterableToArrayLimit; }
/* harmony export */ });
function _iterableToArrayLimit(arr, i) {
  var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];

  if (_i == null) return;
  var _arr = [];
  var _n = true;
  var _d = false;

  var _s, _e;

  try {
    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js":
/*!********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js ***!
  \********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _nonIterableRest; }
/* harmony export */ });
function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _nonIterableSpread; }
/* harmony export */ });
function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js ***!
  \******************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _slicedToArray; }
/* harmony export */ });
/* harmony import */ var _arrayWithHoles_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithHoles.js */ "./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js");
/* harmony import */ var _iterableToArrayLimit_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArrayLimit.js */ "./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js");
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");
/* harmony import */ var _nonIterableRest_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nonIterableRest.js */ "./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js");




function _slicedToArray(arr, i) {
  return (0,_arrayWithHoles_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arr) || (0,_iterableToArrayLimit_js__WEBPACK_IMPORTED_MODULE_1__["default"])(arr, i) || (0,_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(arr, i) || (0,_nonIterableRest_js__WEBPACK_IMPORTED_MODULE_3__["default"])();
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js ***!
  \**********************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _toConsumableArray; }
/* harmony export */ });
/* harmony import */ var _arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/esm/arrayWithoutHoles.js");
/* harmony import */ var _iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/iterableToArray.js");
/* harmony import */ var _unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js");
/* harmony import */ var _nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/esm/nonIterableSpread.js");




function _toConsumableArray(arr) {
  return (0,_arrayWithoutHoles_js__WEBPACK_IMPORTED_MODULE_0__["default"])(arr) || (0,_iterableToArray_js__WEBPACK_IMPORTED_MODULE_1__["default"])(arr) || (0,_unsupportedIterableToArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(arr) || (0,_nonIterableSpread_js__WEBPACK_IMPORTED_MODULE_3__["default"])();
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js":
/*!*******************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ _unsupportedIterableToArray; }
/* harmony export */ });
/* harmony import */ var _arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return (0,_arrayLikeToArray_js__WEBPACK_IMPORTED_MODULE_0__["default"])(o, minLen);
}

/***/ }),

/***/ "./node_modules/compare-versions/index.mjs":
/*!*************************************************!*\
  !*** ./node_modules/compare-versions/index.mjs ***!
  \*************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "compare": function() { return /* binding */ compare; },
/* harmony export */   "default": function() { return /* binding */ compareVersions; },
/* harmony export */   "satisfies": function() { return /* binding */ satisfies; },
/* harmony export */   "validate": function() { return /* binding */ validate; }
/* harmony export */ });
function compareVersions(v1, v2) {
  // validate input and split into segments
  const n1 = validateAndParse(v1);
  const n2 = validateAndParse(v2);

  // pop off the patch
  const p1 = n1.pop();
  const p2 = n2.pop();

  // validate numbers
  const r = compareSegments(n1, n2);
  if (r !== 0) return r;

  // validate pre-release
  if (p1 && p2) {
    return compareSegments(p1.split('.'), p2.split('.'));
  } else if (p1 || p2) {
    return p1 ? -1 : 1;
  }

  return 0;
}

const validate = (v) =>
  typeof v === 'string' && /^[v\d]/.test(v) && semver.test(v);

const compare = (v1, v2, operator) => {
  // validate input operator
  assertValidOperator(operator);

  // since result of compareVersions can only be -1 or 0 or 1
  // a simple map can be used to replace switch
  const res = compareVersions(v1, v2);

  return operatorResMap[operator].includes(res);
};

const satisfies = (v, r) => {
  // if no range operator then "="
  const m = r.match(/^([<>=~^]+)/);
  const op = m ? m[1] : '=';

  // if gt/lt/eq then operator compare
  if (op !== '^' && op !== '~') return compare(v, r, op);

  // else range of either "~" or "^" is assumed
  const [v1, v2, v3] = validateAndParse(v);
  const [r1, r2, r3] = validateAndParse(r);
  if (compareStrings(v1, r1) !== 0) return false;
  if (op === '^') {
    return compareSegments([v2, v3], [r2, r3]) >= 0;
  }
  if (compareStrings(v2, r2) !== 0) return false;
  return compareStrings(v3, r3) >= 0;
};

// export CJS style for parity
compareVersions.validate = validate;
compareVersions.compare = compare;
compareVersions.sastisfies = satisfies;

const semver =
  /^[v^~<>=]*?(\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+)(?:\.([x*]|\d+))?(?:-([\da-z\-]+(?:\.[\da-z\-]+)*))?(?:\+[\da-z\-]+(?:\.[\da-z\-]+)*)?)?)?$/i;

const validateAndParse = (v) => {
  if (typeof v !== 'string') {
    throw new TypeError('Invalid argument expected string');
  }
  const match = v.match(semver);
  if (!match) {
    throw new Error(`Invalid argument not valid semver ('${v}' received)`);
  }
  match.shift();
  return match;
};

const isWildcard = (s) => s === '*' || s === 'x' || s === 'X';

const tryParse = (v) => {
  const n = parseInt(v, 10);
  return isNaN(n) ? v : n;
};

const forceType = (a, b) =>
  typeof a !== typeof b ? [String(a), String(b)] : [a, b];

const compareStrings = (a, b) => {
  if (isWildcard(a) || isWildcard(b)) return 0;
  const [ap, bp] = forceType(tryParse(a), tryParse(b));
  if (ap > bp) return 1;
  if (ap < bp) return -1;
  return 0;
};

const compareSegments = (a, b) => {
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const r = compareStrings(a[i] || 0, b[i] || 0);
    if (r !== 0) return r;
  }
  return 0;
};

const operatorResMap = {
  '>': [1],
  '>=': [0, 1],
  '=': [0],
  '<=': [-1, 0],
  '<': [-1],
};

const allowedOperators = Object.keys(operatorResMap);

const assertValidOperator = (op) => {
  if (typeof op !== 'string') {
    throw new TypeError(
      `Invalid operator type, expected string but got ${typeof op}`
    );
  }
  if (allowedOperators.indexOf(op) === -1) {
    throw new Error(
      `Invalid operator, expected one of ${allowedOperators.join('|')}`
    );
  }
};


/***/ }),

/***/ "./node_modules/html-react-parser/index.mjs":
/*!**************************************************!*\
  !*** ./node_modules/html-react-parser/index.mjs ***!
  \**************************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Element": function() { return /* binding */ Element; },
/* harmony export */   "attributesToProps": function() { return /* binding */ attributesToProps; },
/* harmony export */   "domToReact": function() { return /* binding */ domToReact; },
/* harmony export */   "htmlToDOM": function() { return /* binding */ htmlToDOM; }
/* harmony export */ });
/* harmony import */ var _index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.js */ "./node_modules/html-react-parser/index.js");


var domToReact = _index_js__WEBPACK_IMPORTED_MODULE_0__.domToReact;
var htmlToDOM = _index_js__WEBPACK_IMPORTED_MODULE_0__.htmlToDOM;
var attributesToProps = _index_js__WEBPACK_IMPORTED_MODULE_0__.attributesToProps;
var Element = _index_js__WEBPACK_IMPORTED_MODULE_0__.Element;

/* harmony default export */ __webpack_exports__["default"] = (_index_js__WEBPACK_IMPORTED_MODULE_0__);


/***/ }),

/***/ "./node_modules/axios/package.json":
/*!*****************************************!*\
  !*** ./node_modules/axios/package.json ***!
  \*****************************************/
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('{"_from":"axios@^0.21.1","_id":"axios@0.21.4","_inBundle":false,"_integrity":"sha512-ut5vewkiu8jjGBdqpM44XxjuCjq9LAKeHVmoVfHVzy8eHgxxq8SbAVQNovDA8mVi05kP0Ea/n/UzcSHcTJQfNg==","_location":"/axios","_phantomChildren":{},"_requested":{"type":"range","registry":true,"raw":"axios@^0.21.1","name":"axios","escapedName":"axios","rawSpec":"^0.21.1","saveSpec":null,"fetchSpec":"^0.21.1"},"_requiredBy":["/wait-on"],"_resolved":"https://registry.npmjs.org/axios/-/axios-0.21.4.tgz","_shasum":"c67b90dc0568e5c1cf2b0b858c43ba28e2eda575","_spec":"axios@^0.21.1","_where":"/Users/ananda/Documents/jegtheme/jnews/build-react/node_modules/wait-on","author":{"name":"Matt Zabriskie"},"browser":{"./lib/adapters/http.js":"./lib/adapters/xhr.js"},"bugs":{"url":"https://github.com/axios/axios/issues"},"bundleDependencies":false,"bundlesize":[{"path":"./dist/axios.min.js","threshold":"5kB"}],"dependencies":{"follow-redirects":"^1.14.0"},"deprecated":false,"description":"Promise based HTTP client for the browser and node.js","devDependencies":{"coveralls":"^3.0.0","es6-promise":"^4.2.4","grunt":"^1.3.0","grunt-banner":"^0.6.0","grunt-cli":"^1.2.0","grunt-contrib-clean":"^1.1.0","grunt-contrib-watch":"^1.0.0","grunt-eslint":"^23.0.0","grunt-karma":"^4.0.0","grunt-mocha-test":"^0.13.3","grunt-ts":"^6.0.0-beta.19","grunt-webpack":"^4.0.2","istanbul-instrumenter-loader":"^1.0.0","jasmine-core":"^2.4.1","karma":"^6.3.2","karma-chrome-launcher":"^3.1.0","karma-firefox-launcher":"^2.1.0","karma-jasmine":"^1.1.1","karma-jasmine-ajax":"^0.1.13","karma-safari-launcher":"^1.0.0","karma-sauce-launcher":"^4.3.6","karma-sinon":"^1.0.5","karma-sourcemap-loader":"^0.3.8","karma-webpack":"^4.0.2","load-grunt-tasks":"^3.5.2","minimist":"^1.2.0","mocha":"^8.2.1","sinon":"^4.5.0","terser-webpack-plugin":"^4.2.3","typescript":"^4.0.5","url-search-params":"^0.10.0","webpack":"^4.44.2","webpack-dev-server":"^3.11.0"},"homepage":"https://axios-http.com","jsdelivr":"dist/axios.min.js","keywords":["xhr","http","ajax","promise","node"],"license":"MIT","main":"index.js","name":"axios","repository":{"type":"git","url":"git+https://github.com/axios/axios.git"},"scripts":{"build":"NODE_ENV=production grunt build","coveralls":"cat coverage/lcov.info | ./node_modules/coveralls/bin/coveralls.js","examples":"node ./examples/server.js","fix":"eslint --fix lib/**/*.js","postversion":"git push && git push --tags","preversion":"npm test","start":"node ./sandbox/server.js","test":"grunt test","version":"npm run build && grunt version && git add -A dist && git add CHANGELOG.md bower.json package.json"},"typings":"./index.d.ts","unpkg":"dist/axios.min.js","version":"0.21.4"}');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	!function() {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = function(module) {
/******/ 			var getter = module && module.__esModule ?
/******/ 				function() { return module['default']; } :
/******/ 				function() { return module; };
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	!function() {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = function(exports, definition) {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	!function() {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	!function() {
/******/ 		__webpack_require__.o = function(obj, prop) { return Object.prototype.hasOwnProperty.call(obj, prop); }
/******/ 	}();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	!function() {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = function(exports) {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	}();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
!function() {
"use strict";
/*!****************************!*\
  !*** ./src/jnews/index.js ***!
  \****************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _assets_scss_index_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./assets/scss/index.scss */ "./src/jnews/assets/scss/index.scss");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_util_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./src/util/library */ "./src/jnews/src/util/library.js");
/* harmony import */ var _src_dashboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/dashboard */ "./src/jnews/src/dashboard.js");





var renderDashboard = function renderDashboard() {
  (0,_src_util_library__WEBPACK_IMPORTED_MODULE_2__.docReady)(function () {
    var wpbody_content = document.getElementById('wpbody-content');

    if (wpbody_content) {
      var jnews_dashboard = wpbody_content.querySelector('#jnews-dashboard');

      if (jnews_dashboard) {
        (0,react_dom__WEBPACK_IMPORTED_MODULE_1__.render)( /*#__PURE__*/React.createElement(_src_dashboard__WEBPACK_IMPORTED_MODULE_3__["default"], null), jnews_dashboard);
      } else {
        var last_clear = wpbody_content.querySelector('#wpbody-content > .clear');

        if (last_clear) {
          jnews_dashboard = document.createElement('div');
          jnews_dashboard.setAttribute('id', 'jnews-dashboard');
          wpbody_content.insertBefore(jnews_dashboard, last_clear);
          renderDashboard();
        }
      }
    }
  });
};

renderDashboard();
}();
/******/ })()
;
//# sourceMappingURL=jnews.js.map